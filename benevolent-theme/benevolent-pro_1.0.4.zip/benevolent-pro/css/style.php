<?php
/**
 * Dynamic Styles
 *
 * @package Benevolent_Pro
 */

function benevolent_pro_dynamic_css(){
    
    $body_font      = get_theme_mod( 'benevolent_pro_body_font', array('font-family'=>'Raleway', 'variant'=>'regular') );    
    $body_fonts     = benevolent_pro_get_fonts( $body_font['font-family'], $body_font['variant'] );
    $body_font_size = get_theme_mod( 'benevolent_pro_body_font_size', '18' );
    $body_line_ht   = get_theme_mod( 'benevolent_pro_body_line_height', '28' );
    $body_color     = get_theme_mod( 'benevolent_pro_body_color', '#777777' );
    
    $hps_title_font      = get_theme_mod( 'benevolent_pro_hps_title_font', array('font-family'=>'Raleway', 'variant'=>'700') );
    $hps_title_fonts     = benevolent_pro_get_fonts( $hps_title_font['font-family'], $hps_title_font['variant'] );
    $hps_title_font_size = get_theme_mod( 'benevolent_pro_hps_title_font_size', '40' );
    $hps_title_line_ht   = get_theme_mod( 'benevolent_pro_hps_title_line_height', '48' );
    
    $page_title_font      = get_theme_mod( 'benevolent_pro_page_title_font', array('font-family'=>'Raleway', 'variant'=>'regular') );
    $page_title_fonts     = benevolent_pro_get_fonts( $page_title_font['font-family'], $page_title_font['variant'] );
    $page_title_font_size = get_theme_mod( 'benevolent_pro_page_title_font_size', '38' );
    $page_title_line_ht   = get_theme_mod( 'benevolent_pro_page_title_line_height', '48' );
    $page_title_color     = get_theme_mod( 'benevolent_pro_page_title_color', '#000000' );
    
    $post_title_font      = get_theme_mod( 'benevolent_pro_post_title_font', array('font-family'=>'Raleway', 'variant'=>'regular') );
    $post_title_fonts     = benevolent_pro_get_fonts( $post_title_font['font-family'], $post_title_font['variant'] );
    $post_title_font_size = get_theme_mod( 'benevolent_pro_post_title_font_size', '30' );
    $post_title_line_ht   = get_theme_mod( 'benevolent_pro_post_title_line_height', '36' );
    $post_title_color     = get_theme_mod( 'benevolent_pro_post_title_color', '#121212' );
    
    $h1_font      = get_theme_mod( 'benevolent_pro_h1_font', array('font-family'=>'Raleway', 'variant'=>'700') );
    $h1_fonts     = benevolent_pro_get_fonts( $h1_font['font-family'], $h1_font['variant'] );
    $h1_font_size = get_theme_mod( 'benevolent_pro_h1_font_size', '48' );
    $h1_line_ht   = get_theme_mod( 'benevolent_pro_h1_line_height', '57' );
    $h1_color     = get_theme_mod( 'benevolent_pro_h1_color', '#121212' );
    
    $h2_font      = get_theme_mod( 'benevolent_pro_h2_font', array('font-family'=>'Raleway', 'variant'=>'700') );
    $h2_fonts     = benevolent_pro_get_fonts( $h2_font['font-family'], $h2_font['variant'] );
    $h2_font_size = get_theme_mod( 'benevolent_pro_h2_font_size', '40' );
    $h2_line_ht   = get_theme_mod( 'benevolent_pro_h2_line_height', '48' );
    $h2_color     = get_theme_mod( 'benevolent_pro_h2_color', '#121212' );
    
    $h3_font      = get_theme_mod( 'benevolent_pro_h3_font', array('font-family'=>'Raleway', 'variant'=>'700') );
    $h3_fonts     = benevolent_pro_get_fonts( $h3_font['font-family'], $h3_font['variant'] );
    $h3_font_size = get_theme_mod( 'benevolent_pro_h3_font_size', '30' );
    $h3_line_ht   = get_theme_mod( 'benevolent_pro_h3_line_height', '36' );
    $h3_color     = get_theme_mod( 'benevolent_pro_h3_color', '#121212' );
    
    $h4_font      = get_theme_mod( 'benevolent_pro_h4_font', array('font-family'=>'Raleway', 'variant'=>'700') );
    $h4_fonts     = benevolent_pro_get_fonts( $h4_font['font-family'], $h4_font['variant'] );
    $h4_font_size = get_theme_mod( 'benevolent_pro_h4_font_size', '24' );
    $h4_line_ht   = get_theme_mod( 'benevolent_pro_h4_line_height', '28' );
    $h4_color     = get_theme_mod( 'benevolent_pro_h4_color', '#121212' );
    
    $h5_font      = get_theme_mod( 'benevolent_pro_h5_font', array('font-family'=>'Raleway', 'variant'=>'700') );
    $h5_fonts     = benevolent_pro_get_fonts( $h5_font['font-family'], $h5_font['variant'] );
    $h5_font_size = get_theme_mod( 'benevolent_pro_h5_font_size', '20' );
    $h5_line_ht   = get_theme_mod( 'benevolent_pro_h5_line_height', '24' );
    $h5_color     = get_theme_mod( 'benevolent_pro_h5_color', '#121212' );
    
    $h6_font      = get_theme_mod( 'benevolent_pro_h6_font', array('font-family'=>'Raleway', 'variant'=>'700') );
    $h6_fonts     = benevolent_pro_get_fonts( $h6_font['font-family'], $h6_font['variant'] );
    $h6_font_size = get_theme_mod( 'benevolent_pro_h6_font_size', '18' );
    $h6_line_ht   = get_theme_mod( 'benevolent_pro_h6_line_height', '22' );
    $h6_color     = get_theme_mod( 'benevolent_pro_h6_color', '#121212' );
    
    $widget_title_font      = get_theme_mod( 'benevolent_pro_widget_title_font', array('font-family'=>'Raleway', 'variant'=>'700') );
    $widget_title_fonts     = benevolent_pro_get_fonts( $widget_title_font['font-family'], $widget_title_font['variant'] );    
    $widget_title_font_size = get_theme_mod( 'benevolent_pro_widget_title_font_size', '20' );
    $widget_title_line_ht   = get_theme_mod( 'benevolent_pro_widget_title_line_height', '35' );
    
    $color_scheme    = get_theme_mod( 'benevolent_pro_color_scheme', '#45c267' );
    $s_color_scheme  = get_theme_mod( 'benevolent_pro_secondary_color_scheme', '#F8B016' );
    $bg_color        = get_theme_mod( 'benevolent_pro_bg_color', '#FFFFFF' );
    $body_bg         = get_theme_mod( 'benevolent_pro_body_bg', 'image' );
    $bg_image        = get_theme_mod( 'benevolent_pro_bg_image' );
    $bg_pattern      = get_theme_mod( 'benevolent_pro_bg_pattern', 'nobg' );
    $ed_auth_comment = get_theme_mod( 'benevolent_pro_ed_auth_comments' );
    $comunity_bg     = get_theme_mod( 'benevolent_pro_community_bg', '#0f907f' ); 
    $give_bg         = get_theme_mod( 'benevolent_pro_give_bg', '#0f907f' );
    
    $image = '';
    if( $body_bg == 'image' && $bg_image ){
        $image = $bg_image;    
    }elseif( $body_bg == 'pattern' && $bg_pattern != 'nobg' ){
        $image = get_template_directory_uri() . '/images/patterns/' . $bg_pattern . '.png';
    }

    echo "<style type='text/css' media='all'>"; ?>
    
    body{
    	font-size: <?php echo absint( $body_font_size ); ?>px;
    	line-height: <?php echo absint( $body_line_ht ); ?>px;
    	color: <?php echo benevolent_pro_sanitize_hex_color( $body_color ); ?>;
    	font-family: <?php echo $body_fonts['font']; ?>;
        font-weight: <?php echo esc_attr( $body_fonts['weight'] ); ?>;
        font-style: <?php echo esc_attr( $body_fonts['style'] ); ?>;
        background: url(<?php echo esc_url( $image ); ?>) <?php echo benevolent_pro_sanitize_hex_color( $bg_color ); ?>;
    }
    
    a {
        color: <?php echo benevolent_pro_sanitize_hex_color( $color_scheme ); ?>;
    }

    a:hover,
    a:focus {
        color: <?php echo benevolent_pro_sanitize_hex_color( $color_scheme ); ?>;
    }

    body,
    button,
    input,
    select,
    textarea{
        font-family: <?php echo $body_fonts['font']; ?>;
    }

    .site-header .site-branding .site-title a{
        color: <?php echo benevolent_pro_sanitize_hex_color( $s_color_scheme ); ?>;
    }

    .site-header .site-branding .site-description{
        font-family: <?php echo $body_fonts['font']; ?>; 
    }

    .main-navigation a:hover,
    .main-navigation ul li:hover > a,
    .main-navigation ul .current-menu-item > a{
        color: <?php echo benevolent_pro_sanitize_hex_color( $s_color_scheme ); ?>;
    }

    /* home page section title style */
    
    .intro .header .main-title,
    .blog-section .header .main-title,
    .our-community .header .main-title,
    .give-section .main-title,
    .donors .heading .main-title,
    .promotional-block .widget_benevolent_pro_cta_widget .widget-title  {
        font-size: <?php echo absint( $hps_title_font_size ); ?>px;
    	line-height: <?php echo absint( $hps_title_line_ht ); ?>px;
    	color: <?php echo benevolent_pro_sanitize_hex_color( $body_color ); ?>;
    	font-family: <?php echo $hps_title_fonts['font']; ?>;
        font-weight: <?php echo esc_attr( $hps_title_fonts['weight'] ); ?>;
        font-style: <?php echo esc_attr( $hps_title_fonts['style'] ); ?>;        
    }
    
    .give-section .main-title,
    .our-community .header .main-title {
        color: #fff;
    }
    
    .promotional-block .widget_benevolent_pro_cta_widget .widget-title {
        color: #fff;
    }

    .our-community .community-holder .hover-state .title{
        color: <?php echo benevolent_pro_sanitize_hex_color( $s_color_scheme ); ?>;
    }

    .give-section .give-holder .post .text-holder .entry-title a:hover,
    .give-section .give-holder .post .text-holder .entry-title a:focus{
        color: <?php echo benevolent_pro_sanitize_hex_color( $color_scheme ); ?>;
    }

    .give-section .give-holder .post .text-holder .btn-donate{
        background: <?php echo benevolent_pro_sanitize_hex_color( $s_color_scheme ); ?>;
    }

    .blog-section .blog-holder .post .entry-title a:hover,
    .blog-section .blog-holder .post .entry-title a:focus{
        color: <?php echo benevolent_pro_sanitize_hex_color( $s_color_scheme ); ?>;
    }

    .blog-section .blog-holder .post .readmore:hover,
    .blog-section .blog-holder .post .readmore:focus{
        color: <?php echo benevolent_pro_sanitize_hex_color( $s_color_scheme ); ?>;
    }

    .promotional-block .widget_benevolent_pro_cta_widget .btn-donate:hover,
    .promotional-block .widget_benevolent_pro_cta_widget .btn-donate:focus{
        background: <?php echo benevolent_pro_sanitize_hex_color( $s_color_scheme ); ?>;
    }
    
    /*inner pages title style*/
    .about-us .main-title,
    .page-template-template-about .our-works .heading .main-title,
    .page-template-template-about .our-believe .heading .main-title,
    .page-template-template-about .current-project .heading .main-title,
    .page-template-template-service .services-intro .main-title,
    .page-template-template-service .our-works .heading .main-title,
    .page-template-template-team .main-title,
    .page-template-template-testimonial .main-title {
        font-size: <?php echo absint( $page_title_font_size ); ?>px;
    	line-height: <?php echo absint( $page_title_line_ht ); ?>px;
    	color: <?php echo benevolent_pro_sanitize_hex_color( $page_title_color ); ?>;
    	font-family: <?php echo $page_title_fonts['font']; ?>;
        font-weight: <?php echo esc_attr( $page_title_fonts['weight'] ); ?>;
        font-style: <?php echo esc_attr( $page_title_fonts['style'] ); ?>;
    }
    
    /*page entry-title*/
    #primary .page .entry-header .entry-title {
        color: #000;
        font-size: 38px;
        font-weight: 400;
        line-height: 48px;
    }
    
    /*blog post title*/
    #primary .post .entry-header .entry-title {
        font-size: <?php echo absint( $post_title_font_size ); ?>px;
    	line-height: <?php echo absint( $post_title_line_ht ); ?>px;
    	color: <?php echo benevolent_pro_sanitize_hex_color( $post_title_color ); ?>;
    	font-family: <?php echo $post_title_fonts['font']; ?>;
        font-weight: <?php echo esc_attr( $post_title_fonts['weight'] ); ?>;
        font-style: <?php echo esc_attr( $post_title_fonts['style'] ); ?>;        
    }
    
    /*sidebar widget title*/
    #secondary .widget-title {
        font-size: <?php echo absint( $widget_title_font_size ); ?>px;
    	line-height: <?php echo absint( $widget_title_line_ht ); ?>px;
    	color: <?php echo benevolent_pro_sanitize_hex_color( $body_color ); ?>;
    	font-family: <?php echo $widget_title_fonts['font']; ?>;
        font-weight: <?php echo esc_attr( $widget_title_fonts['weight'] ); ?>;
        font-style: <?php echo esc_attr( $widget_title_fonts['style'] ); ?>;
    }
    
    /*sidebar ul font*/
    #secondary .widget ul {
        font-size: 16px;
    }
    
    /*footer widget title*/
    .site-footer .widget .widget-title {
        font-size: 18px;
        font-weight: 700;
        line-height: 36px;
    }
    
    /* H1 content */
    .post .entry-content h1,
    .page .entry-content h1{
        font-family: <?php echo $h1_fonts['font']; ?>;
        font-size: <?php echo absint( $h1_font_size ); ?>px;
        font-weight: <?php echo esc_attr( $h1_fonts['weight'] ); ?>;
        font-style: <?php echo esc_attr( $h1_fonts['style'] ); ?>;
        line-height: <?php echo absint( $h1_line_ht ); ?>px;
        color: <?php echo benevolent_pro_sanitize_hex_color( $h1_color ); ?>;
    }
    
    /* H2 content */
    .post .entry-content h2,
    .page .entry-content h2{
        font-family: <?php echo $h2_fonts['font']; ?>;
        font-size: <?php echo absint( $h2_font_size ); ?>px;
        font-weight: <?php echo esc_attr( $h2_fonts['weight'] ); ?>;
        font-style: <?php echo esc_attr( $h2_fonts['style'] ); ?>;
        line-height: <?php echo absint( $h2_line_ht ); ?>px;
        color: <?php echo benevolent_pro_sanitize_hex_color( $h2_color ); ?>;
    }
    
    /* H3 content */
    .post .entry-content h3,
    .page .entry-content h3{
        font-family: <?php echo $h3_fonts['font']; ?>;
        font-size: <?php echo absint( $h3_font_size ); ?>px;
        font-weight: <?php echo esc_attr( $h3_fonts['weight'] ); ?>;
        font-style: <?php echo esc_attr( $h3_fonts['style'] ); ?>;
        line-height: <?php echo absint( $h3_line_ht ); ?>px;
        color: <?php echo benevolent_pro_sanitize_hex_color( $h3_color ); ?>;
    }
    
    /* H4 content */
    .post .entry-content h4,
    .page .entry-content h4{
        font-family: <?php echo $h4_fonts['font']; ?>;
        font-size: <?php echo absint( $h4_font_size ); ?>px;
        font-weight: <?php echo esc_attr( $h4_fonts['weight'] ); ?>;
        font-style: <?php echo esc_attr( $h4_fonts['style'] ); ?>;
        line-height: <?php echo absint( $h4_line_ht ); ?>px;
        color: <?php echo benevolent_pro_sanitize_hex_color( $h4_color ); ?>;
    }
    
    /* H5 content */
    .post .entry-content h5,
    .page .entry-content h5{
        font-family: <?php echo $h5_fonts['font']; ?>;
        font-size: <?php echo absint( $h5_font_size ); ?>px;
        font-weight: <?php echo esc_attr( $h5_fonts['weight'] ); ?>;
        font-style: <?php echo esc_attr( $h5_fonts['style'] ); ?>;
        line-height: <?php echo absint( $h5_line_ht ); ?>px;
        color: <?php echo benevolent_pro_sanitize_hex_color( $h5_color ); ?>;
    }
    
    /* H6 content */
    .post .entry-content h6,
    .page .entry-content h6{
        font-family: <?php echo $h6_fonts['font']; ?>;
        font-size: <?php echo absint( $h6_font_size ); ?>px;
        font-weight: <?php echo esc_attr( $h6_fonts['weight'] ); ?>;
        font-style: <?php echo esc_attr( $h6_fonts['style'] ); ?>;
        line-height: <?php echo absint( $h6_line_ht ); ?>px;
        color: <?php echo benevolent_pro_sanitize_hex_color( $h6_color ); ?>;
    }

    /* color scheme other style */
    .intro .columns-3 .text-holder .btn,
    .blog-section .blog-holder .post .entry-meta a,
    .blog-section .blog-holder .post .entry-meta .fa,
    .donors .lSAction > .lSNext:hover,
    .donors .lSAction > .lSNext:focus,
    .donors .lSAction > .lSPrev:hover,
    .donors .lSAction > .lSPrev:focus,
    .widget.widget_benevolent_pro_recent_post .entry-header .entry-meta a,
    .widget.widget_benevolent_pro_popular_post .entry-header .entry-meta a,
    .widget.widget_benevolent_pro_category_post .entry-header .entry-meta a,
    .widget.widget_benevolent_pro_author_post .entry-header .entry-meta a,
    #crumbs a:hover,
    #crumbs a:focus,
    .page-template-template-about .our-believe ul li:before,
    .page-template-template-about .current-project .post .entry-header .entry-title a:hover,
    .page-template-template-about .current-project .post .entry-header .entry-title a:focus,
    #primary .post .entry-meta a,
    #primary .post .entry-footer .readmore,
    #secondary .widget ul li a:hover,
    .widget.widget_benevolent_pro_contact .tel-link:hover,
    .widget.widget_benevolent_pro_contact .tel-link:focus,
    #secondary .widget.widget_benevolent_pro_twitter_feeds_widget ul li a,
    #secondary .widget.widget_rss ul li a,
    #primary .entry-content .social-shortcode a:hover,
    #primary .entry-content .social-shortcode a:focus,
    .comment-list .comment-metadata a{
        color: <?php echo benevolent_pro_sanitize_hex_color( $color_scheme ); ?>; 
    }

    .widget.widget_calendar .calendar_wrap caption,
    .widget.widget_benevolent_pro_instagram_widget p a:hover,
    .widget.widget_benevolent_pro_instagram_widget p a:focus,
    .page-template-template-about .current-project .post .entry-footer .btn-readmore a,
    button,
    input[type="button"],
    input[type="reset"],
    input[type="submit"],
    .comment-form input[type="submit"],
    .widget.widget_tag_cloud .tagcloud a:hover,
    .widget.widget_tag_cloud .tagcloud a:focus{
        background: <?php echo benevolent_pro_sanitize_hex_color( $color_scheme ); ?>;
    }

    .widget.widget_benevolent_pro_instagram_widget p a:hover,
    .widget.widget_benevolent_pro_instagram_widget p a:focus{
        border: 1px solid <?php echo benevolent_pro_sanitize_hex_color( $color_scheme ); ?>;
    }

    .widget.widget_benevolent_pro_contact .social-networks li a:hover,
    .widget.widget_benevolent_pro_contact .social-networks li a:focus,
    #secondary .widget.widget_benevolent_pro_contact .social-networks li a:hover,
    #secondary .widget.widget_benevolent_pro_contact .social-networks li a:focus{
        background: <?php echo benevolent_pro_sanitize_hex_color( $color_scheme ); ?>;
        border: 1px solid <?php echo benevolent_pro_sanitize_hex_color( $color_scheme ); ?>;
    }

    .site-header .btn-donate{
        border-color: <?php echo benevolent_pro_sanitize_hex_color( $s_color_scheme ); ?>;
        background: <?php echo benevolent_pro_sanitize_hex_color( $s_color_scheme ); ?>;
        
    }

    .site-header .btn-donate:hover,
    .site-header .btn-donate:focus{
        color: #fff;
    }

    .banner .text .btn-more{
        background: <?php echo benevolent_pro_sanitize_hex_color( $s_color_scheme ); ?>;
        border-color: <?php echo benevolent_pro_sanitize_hex_color( $s_color_scheme ); ?>;
    }

    .banner .text .btn-more:hover,
    .banner .text .btn-more:focus{
        color: <?php echo benevolent_pro_sanitize_hex_color( $s_color_scheme ); ?>;
    }

    .site-footer .widget.widget_benevolent_pro_recent_post .entry-header .entry-title a:hover,
    .site-footer .widget.widget_benevolent_pro_recent_post .entry-header .entry-title a:focus,
    .site-footer .widget.widget_benevolent_pro_popular_post .entry-header .entry-title a:hover,
    .site-footer .widget.widget_benevolent_pro_popular_post .entry-header .entry-title a:focus,
    .site-footer .widget.widget_benevolent_pro_category_post .entry-header .entry-title a:hover,
    .site-footer .widget.widget_benevolent_pro_category_post .entry-header .entry-title a:focus,
    .site-footer .widget.widget_benevolent_pro_author_post .entry-header .entry-title a:hover,
    .site-footer .widget.widget_benevolent_pro_author_post .entry-header .entry-title a:focus{
        color: <?php echo benevolent_pro_sanitize_hex_color( $s_color_scheme ); ?>;
    }

    .widget.widget_benevolent_pro_recent_post .entry-header .entry-meta a:hover,
    .widget.widget_benevolent_pro_recent_post .entry-header .entry-meta a:focus,
    .widget.widget_benevolent_pro_popular_post .entry-header .entry-meta a:hover,
    .widget.widget_benevolent_pro_popular_post .entry-header .entry-meta a:focus,
    .widget.widget_benevolent_pro_category_post .entry-header .entry-meta a:hover,
    .widget.widget_benevolent_pro_category_post .entry-header .entry-meta a:focus,
    .widget.widget_benevolent_pro_author_post .entry-header .entry-meta a:hover,
    .widget.widget_benevolent_pro_author_post .entry-header .entry-meta a:focus{
        color: <?php echo benevolent_pro_sanitize_hex_color( $s_color_scheme ); ?>;
    }

    .site-footer .widget ul li a:hover,
    .site-footer .widget ul li a:focus{
        color: <?php echo benevolent_pro_sanitize_hex_color( $s_color_scheme ); ?>;
    }

    .site-footer .widget.widget_benevolent_pro_twitter_feeds_widget ul li a{
        color: <?php echo benevolent_pro_sanitize_hex_color( $s_color_scheme ); ?>;
    }

    .site-footer .widget.widget_benevolent_pro_contact .tel-link:hover,
    .site-footer .widget.widget_benevolent_pro_contact .tel-link:focus,
    .site-footer .widget.widget_benevolent_pro_contact .email-link{
        color: <?php echo benevolent_pro_sanitize_hex_color( $s_color_scheme ); ?>;
    }

    .site-footer .widget.widget_benevolent_pro_contact .social-networks li a:hover,
    .site-footer .widget.widget_benevolent_pro_contact .social-networks li a:focus{
        background: <?php echo benevolent_pro_sanitize_hex_color( $s_color_scheme ); ?>;
        border-color: <?php echo benevolent_pro_sanitize_hex_color( $s_color_scheme ); ?>;
    }

    #primary .post .entry-header .entry-title a:hover,
    #primary .page .entry-header .entry-title a:hover,
    #primary .post .entry-header .entry-title a:focus,
    #primary .page .entry-header .entry-title a:focus{
        color: <?php echo benevolent_pro_sanitize_hex_color( $s_color_scheme ); ?>;
    }

    #primary .post .entry-meta a:hover,
    #primary .post .entry-meta a:focus{
        color: <?php echo benevolent_pro_sanitize_hex_color( $s_color_scheme ); ?>;
    }

    #primary .post .entry-footer .readmore:hover,
    #primary .post .entry-footer .readmore:focus{
        color: <?php echo benevolent_pro_sanitize_hex_color( $s_color_scheme ); ?>;
    }

    #primary .entry-content .rara_call_to_action_button{
        background: <?php echo benevolent_pro_sanitize_hex_color( $s_color_scheme ); ?>;
    }

    .rara_toggle .rara_toggle_title{
        background: <?php echo benevolent_pro_sanitize_hex_color( $s_color_scheme ); ?>;
    }

    .rara_toggle{
        border-color: <?php echo benevolent_pro_sanitize_hex_color( $s_color_scheme ); ?>;
    }

    #primary .entry-content .rara_tab_wrap .rara_tab_group .tab-title.active,
    #primary .entry-content .rara_tab_wrap .rara_tab_group .tab-title:hover,
    #primary .entry-content .rara_tab_wrap .rara_tab_group .tab-title:focus{
        background: <?php echo benevolent_pro_sanitize_hex_color( $s_color_scheme ); ?>;
    }

    #primary .entry-content .rara_tab_wrap .rara_tab_group .tab-title{
        border-color: <?php echo benevolent_pro_sanitize_hex_color( $s_color_scheme ); ?>;
    }

    #primary .post .entry-content .rara_accordian .rara_accordian_title,
    #primary .page .entry-content .rara_accordian .rara_accordian_title{
        background: <?php echo benevolent_pro_sanitize_hex_color( $s_color_scheme ); ?>;
    }

    #primary .post .entry-content .rara_accordian,
    #primary .page .entry-content .rara_accordian{
        border-color: <?php echo benevolent_pro_sanitize_hex_color( $s_color_scheme ); ?>;
    }

    .comment-list .comment-metadata a:hover{
        color: <?php echo benevolent_pro_sanitize_hex_color( $s_color_scheme ); ?>;
    }

    .comment-list .reply a:hover,
    .comment-list .reply a:focus{
        color: <?php echo benevolent_pro_sanitize_hex_color( $s_color_scheme ); ?>;
    }

    .site-info a:hover,
    .site-info a:focus{
        color: <?php echo benevolent_pro_sanitize_hex_color( $s_color_scheme ); ?>;
    }

    .give-donation-level-btn.give-btn{
        background: <?php echo benevolent_pro_sanitize_hex_color( $s_color_scheme ); ?> !important;
        border-color:  <?php echo benevolent_pro_sanitize_hex_color( $s_color_scheme ); ?> !important;
    }

    .give-donation-level-btn.give-btn:hover,
    .give-donation-level-btn.give-btn:focus{
        color: #fff !important;
        opacity: 0.8;
    }

    #secondary .widget.widget_give_forms_widget .give-btn{
        background: <?php echo benevolent_pro_sanitize_hex_color( $s_color_scheme ); ?> !important;
        border-color:  <?php echo benevolent_pro_sanitize_hex_color( $s_color_scheme ); ?> !important; 
    }

    #secondary .widget.widget_give_forms_widget .give-btn:hover{
        color: #fff !important; 
        opacity: 0.8;
    }

    .our-community .header::after{
        border-top-color: <?php echo benevolent_pro_sanitize_hex_color( $comunity_bg ); ?>;
    }
    .our-community .header{
        background: <?php echo benevolent_pro_sanitize_hex_color( $comunity_bg ); ?>;
    }
    .give-section{
        background: <?php echo benevolent_pro_sanitize_hex_color( $give_bg ); ?>;
    }

    <?php if( $ed_auth_comment ){ ?>
        /* Author Comment Style */
        .comment-list .bypostauthor .comment-body{
            background: #f4f4f4;
            border-radius: 3px;
            padding: 10px;
        }
    <?php } ?>
    
    <?php if( is_woocommerce_activated() ) { ?>
    /* Woo Commerce Style */
    .woocommerce span.onsale{
        background: <?php echo benevolent_pro_sanitize_hex_color( $color_scheme ); ?>;
    }

    .woocommerce #respond input#submit,
    .woocommerce a.button,
    .woocommerce button.button,
    .woocommerce input.button,
    .woocommerce a.added_to_cart{
        background: <?php echo benevolent_pro_sanitize_hex_color( $s_color_scheme ); ?>;
    }

    .woocommerce a.button:hover,
    .woocommerce a.button:focus,
    .woocommerce #respond input#submit:hover,
    .woocommerce #respond input#submit:focus,
    .woocommerce button.button:hover,
    .woocommerce button.button:focus,
    .woocommerce input.button:hover,
    .woocommerce input.button:focus,
    .woocommerce a.added_to_cart:hover,
    .woocommerce a.added_to_cart:focus{
        background: <?php echo benevolent_pro_sanitize_hex_color( $s_color_scheme ); ?>;
    }

    .woocommerce #respond input#submit.alt,
    .woocommerce a.button.alt,
    .woocommerce button.button.alt,
    .woocommerce input.button.alt{
        background: <?php echo benevolent_pro_sanitize_hex_color( $s_color_scheme ); ?>;
    }

    .woocommerce #respond input#submit.alt:hover,
    .woocommerce a.button.alt:hover,
    .woocommerce button.button.alt:hover,
    .woocommerce input.button.alt:hover,
    .woocommerce #respond input#submit.alt:focus,
    .woocommerce a.button.alt:focus,
    .woocommerce button.button.alt:focus,
    .woocommerce input.button.alt:focus{
        background: <?php echo benevolent_pro_sanitize_hex_color( $s_color_scheme ); ?>;
    }

    
    <?php } ?>

    <?php echo "</style>";  
}

/**
 * Function for sanitizing Hex color 
 */
function benevolent_pro_sanitize_hex_color( $color ){
	if ( '' === $color )
		return '';

    // 3 or 6 hex digits, or the empty string.
	if ( preg_match('|^#([A-Fa-f0-9]{3}){1,2}$|', $color ) )
		return $color;
}