=== Benevolent Pro ===
Author: Rara Theme (http://raratheme.com)

Tags: Blog, two-columns, right-sidebar, footer-widgets, education, custom-background, custom-menu, featured-image-header, featured-images, post-formats, threaded-comments, translation-ready, full-width-template, theme-options

Requires at least: 4.6
Tested up to: 4.7.3
Stable tag: 1.0.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==

Benevolent Pro is an easy to use, clean modern and  flexible multipurpose theme.   Although the theme was designed with nonprofit organizations in mind , the theme is very versatile and can be used by any business websites, digital agency, consultancy, corporate business, freelancers, and bloggers. The theme is SEO friendly with optimized codes, which  make it easy for your site to rank on Google and other search engines. Benevolent Pro comes with several features to make user-friendly, interactive and visually stunning website. Such features include custom menu with Call to Action Button, advance full width slider,  community section, Stats counter,  Client Section, Banner with Call to Action Button  (CTA),  and social media. It has four footer area and a right sidebar and includes  four custom widgets for the recent posts, popular posts, social media and the featured post. The theme is rigorously tested and optimized for speed and faster page load time and has a secure and clean code. The theme is also translation ready. Designed with visitor engagement in mind, Benevolent Pro helps you to easily and intuitively create professional and appealing websites. You can get free support in http://raratheme.com/support-forum/, Documentation: http://raratheme.com/documentation/benevolent-pro and check the demo at http://raratheme.com/preview/benevolent-pro/


== Installation ==
        
1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Copyrights and License ==

Unless otherwise specified, all the theme files, scripts and images are licensed under GPLv2 or later


External resources linked to the theme.
* Raleway Font by through Google Font 
https://www.google.com/fonts/specimen/Raleway
*Font Awesome
https://fortawesome.github.io/Font-Awesome/

# Images
All images are under Creative Commons Public Domain deed CC0.

https://pixabay.com/en/boys-poor-person-children-happy-60680/

Other images are self taken or self created and are GPL compatible.

# JS
All the JS are licensed under GPLv2 or later
https://jqueryui.com/tabs/
http://flexslider.woothemes.com/
https://www.berriart.com/sidr/
https://github.com/bfintal/Counter-Up/blob/master/LICENSE
https://github.com/imakewebthings/waypoints/blob/master/licenses.txt

* Based on Underscores http://underscores.me/, (C) 2012-2015 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)


* normalize.css http://necolas.github.io/normalize.css/, (C) 2012-2015 Nicolas Gallagher and Jonathan Neal, [MIT](http://opensource.org/licenses/MIT)


All other resources and theme elements are licensed under the GPLv2 or later


Benevolent WordPress Theme, Copyright Rara Theme 2015, Raratheme.com
Benevolent WordPress Theme is distributed under the terms of the GPLv2 or later


*  This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   
== Changelog ==
    1.0.4
    * New: Made theme WPML and Polylang compatible.
    * Updated "Rara One Click Demo Import" plugin.
    * Added snippet to migrate custom css to core custom css for WP ver > 4.7.
    * Fixed js error in infinite scroll.
    * Fixed unbalanced tags.
    * Fixed default value issue for contatiner option in facebook widget.
    * Fixed grey area in responsive header.
    
    1.0.3
    * New: Demo Import is implemented through "Rara One Click Demo Import".
    * Fixed random no. of post in default recent post widget.
    
    1.0.2
    * Added pages in dropdown menu of Community section of home page settings.
    * Added background color option for Community and Give section of home page settings.
    
    1.0.1
    * Fix + sign issue in google plus link.
    * Added Import Demo in Customizer.
            
    1.0.0
    * Initial Release