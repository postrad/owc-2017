jQuery(document).ready(function($){

    /** Responsive Menu */
   $('#responsive-menu-button').sidr({
      name: 'sidr-main',
      source: '#site-navigation',
      side: 'right'
    });

   $('#responsive-secondary-menu-button').sidr({
      name: 'sidr-main2',
      source: '#top-navigation',
      side: 'left'
    });
       
   /** Variables from Customizer for Slider settings */
    if( benevolent_pro_data.auto == '1' ){
        var slider_auto = true;
    }else{
        slider_auto = false;
    }
    
    if( benevolent_pro_data.loop == '1' ){
        var slider_loop = true;
    }else{
        var slider_loop = false;
    }
    
    if( benevolent_pro_data.pager == '1' ){
        var slider_control = true;
    }else{
        slider_control = false;
    }
        
    if( benevolent_pro_data.rtl == '1' ){
        var rtl = true;
    }else{
        var rtl = false;
    }
    
    /** Home Page Slider */
    $('#banner-slider').lightSlider({
        item        : 1,
        slideMargin : 0,
        mode        : benevolent_pro_data.mode,
        speed       : benevolent_pro_data.speed, //ms'
        auto        : slider_auto,
        loop        : slider_loop,
        pause       : benevolent_pro_data.pause,
        controls    : false,
        pager       : slider_control,
        enableDrag  : false,
        rtl         : rtl,
    });
   
    /** Stat Counter */
    $('.number').counterUp({
        delay: 10,
        time: 1000
    });   
   
    /* Masonry for Team Page Template*/
    if( $('.page-template-template-team').length > 0 ){        
        $('.team-holder').imagesLoaded(function(){ 
            $('.team-holder').masonry({
                itemSelector: '.col'
            }); 
        });
    }
    
    if( $('.page-template-template-about').length > 0 || $('.page-template-template-service').length > 0 ){
        $('.our-works .row').imagesLoaded(function(){
           $('.our-works .row').masonry({
                itemSelector: '.widget'
           }); 
        });
    }
    
    $("#donor-slider").lightSlider({
        item        : 5,
        slideMove   : 1, // slidemove will be 1 if loop is true
        slideMargin : 5,
        rtl         : rtl,
        pager       : false,
        gallery     : false, 
        enableDrag  :false,
        responsive  : [
        	{
        		breakpoint: 1200,
        		settings: {
        			item: 4,
        		}
        	},
        	{
        		breakpoint: 992,
        		settings: {
        			item: 3,
        		}
        	},
        	{
        		breakpoint: 768,
        		settings: {
        			item: 1,
        		}
        	},
        ],
    });
    
    // Script for back to top
    $(window).scroll(function(){
        if($(this).scrollTop() > 300){
          $('#rara-top').fadeIn();
        }else{
          $('#rara-top').fadeOut();
        }
    });
    
    $("#rara-top").click(function(){
        $('html,body').animate({scrollTop:0},600);
    });
    
    /* Fits embed video according to container */
    $("#content").fitVids();
    $(".video-holder").fitVids();
    
    /** Lightbox */
    if( benevolent_pro_data.lightbox == '1' ){
        
        $('.entry-content').find('.gallery-columns-1').find('.gallery-icon > a').attr( 'rel', 'group1' );
        $('.entry-content').find('.gallery-columns-2').find('.gallery-icon > a').attr( 'rel', 'group2' );
        $('.entry-content').find('.gallery-columns-3').find('.gallery-icon > a').attr( 'rel', 'group3' );
        $('.entry-content').find('.gallery-columns-4').find('.gallery-icon > a').attr( 'rel', 'group4' );
        $('.entry-content').find('.gallery-columns-5').find('.gallery-icon > a').attr( 'rel', 'group5' );
        $('.entry-content').find('.gallery-columns-6').find('.gallery-icon > a').attr( 'rel', 'group6' );
        $('.entry-content').find('.gallery-columns-7').find('.gallery-icon > a').attr( 'rel', 'group7' );
        $('.entry-content').find('.gallery-columns-8').find('.gallery-icon > a').attr( 'rel', 'group8' );
        $('.entry-content').find('.gallery-columns-9').find('.gallery-icon > a').attr( 'rel', 'group9' );
        
        $("a[href$='.jpg'],a[href$='.jpeg'],a[href$='.png'],a[href$='.gif']").fancybox();
        
    }
    
    /** For Header Three */
    var windowWidth = $(window).width();
	if(windowWidth > 767){
		var logoWidth = $('.site-branding').width();
		var headerWidth = $('.site-header').width();
		var logoHeight = $('.site-header.header-three .header-holder').height();
		$('.site-header.header-three .header-holder').css('width', headerWidth - logoWidth - 41);
		$('.site-header.header-three .site-branding').css('height', logoHeight);
	}
    
    /* Sticky Menu */    
    if( benevolent_pro_data.sticky == '1' && windowWidth >= 992 ){
        var mns = "sticky-menu";
        hdr = $('.site-header').height();
        
        if( 
		   benevolent_pro_data.header == 'one' || 
		   benevolent_pro_data.header == 'two' || 
		   benevolent_pro_data.header == 'four' || 
		   benevolent_pro_data.header == 'five')
		{
            mn = $(".site-header .header-bottom");
        }
		else if( benevolent_pro_data.header == 'three' )
		{
            mn = $(".site-header");
        }   
        
        $(window).scroll(function() {
            if( $(this).scrollTop() > hdr ) {
                mn.addClass(mns);
                    } else {
                mn.removeClass(mns);
            }
        });
    }
    /* Sticky Menu Ends */	
    
    /* For Search Form in header*/
	$('html').click(function() {
		$('.form-holder').slideUp(); 
	});

	$('.search').click(function(e){
		e.stopPropagation();
	});
	$(".fa-search").click(function(){
		$(".form-holder").slideToggle();
			return false;
	});
    
    /** Give Slider */
    $('.give-slider').lightSlider({
        item        : 3,
        slideMargin : 20,
        pager       : false,
        enableDrag  : false,
        prevHtml    : '<span class="fa fa-angle-left"></span>',
        nextHtml    : '<span class="fa fa-angle-right"></span>',

        responsive  : [
            {
                breakpoint: 992,
                settings: {
                    item: 2,
                }
            },
            {
                breakpoint: 768,
                settings: {
                    item: 1,
                }
            },
        ],
    });
    
    /* Give Section Equal Height */
    $('.give-section .give-holder .post .text-holder').matchHeight({
        byRow: true,
        property: 'height',
        target: null,
        remove: false
    }); 
    
    /****SHORTCODE***/
    $('.shortcode-slider .slides').lightSlider({
        mode        : "slide",
        item        : 1,
        slideMargin : 0,
        pager       : false,
        enableDrag  :false,
        rtl         : rtl,
    });    
    
    $('.rara_accordian .rara_accordian_content').hide(); /**Need to be CSS*/
    $('.rara_accordian:first').children('.rara_accordian_content').show();
    $('.rara_accordian:first').children('.rara_accordian_title').addClass('active');
    $('.rara_accordian_title').click(function(){
    if($(this).hasClass('active')){
    }
    else{
      $(this).parent('.rara_accordian').siblings().find('.rara_accordian_content').slideUp();
      $(this).next('.rara_accordian_content').slideToggle();
      $(this).parent('.rara_accordian').siblings().find('.rara_accordian_title').removeClass('active')
      $(this).toggleClass('active')
    }
    });
    
    $('.rara_toggle.close .rara_toggle_content').hide(); /**Need to be CSS*/
    $('.rara_toggle.open .rara_toggle_title').addClass('active');
    $('.rara_toggle_title').click(function(){
      $(this).next('.rara_toggle_content').slideToggle();
      $(this).toggleClass('active')
    });
    
    $('.rara_tab').hide();/**Need to be CSS*/
    $('.rara_tab_wrap').prepend('<div class="rara_tab_group clearfix"></div>');

    $('.rara_tab_wrap').each(function(){
        $(this).children('.rara_tab').find('.tab-title').prependTo($(this).find('.rara_tab_group'));
        $(this).children('.rara_tab').wrapAll( "<div class='rara_tab_content clearfix' />");
    });

    $('#page').each(function(){
        $(this).find('.rara_tab:first-child').show();
        $(this).find('.tab-title:first-child').addClass('active')
    });
 
    $('.rara_tab_group .tab-title').click(function(){
        $(this).siblings().removeClass('active');
        $(this).addClass('active');
        $(this).parent('.rara_tab_group ').next('.rara_tab_content').find('.rara_tab').hide();
        var ap_id = $(this).attr('id');
        $(this).parent('.rara_tab_group ').next('.rara_tab_content').find('.'+ap_id).show();
    });    
    /****SHORTCODE***/ 
});