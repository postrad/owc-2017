<?php
/**
 * Demo Import Options
 *
 * @package Benevolent
 */

function benevolent_pro_customize_register_demo( $wp_customize ) {

    /** 1. Demo Import */
    $wp_customize->add_section(
        'demo_data_import_setting',
        array(
            'title'       => __('Demo Import', 'benevolent-pro' ),
            'capability'  => 'edit_theme_options',
            'priority'    => '2',            
        )
    );

    $wp_customize->add_setting(
        'demo_data_import',
        array(
            'default' => '',
            'sanitize_callback' => 'wp_kses_post',
        )
    );
  
    if( is_rocdi_activated() ){
        $descritpion = sprintf( __( 'Demo Import setting is moved to addon plugin, "Rara One Click Demo Import" which is bundled with this theme. Please import demo content from %1$shere%2$s.', 'benevolent-pro' ), '<a href="' . admin_url( 'themes.php?page=rara-one-click-demo-import' ) . '" target="_blank">', '</a>' );
    }else{
        $descritpion = sprintf( __( 'Demo Import setting is moved to addon plugin, "Rara One Click Demo Import" which is bundled with this theme. Please install the plugin via %1$sinstaller%2$s and import demo content.', 'benevolent-pro' ), '<a href="' . admin_url( 'themes.php?page=tgmpa-install-plugins' ) . '" target="_blank">', '</a>' );
    }
  
    $wp_customize->add_control( new Theme_Info_Custom_Control(
        $wp_customize,
            'demo_data_import',
        array(
            'section'     => 'demo_data_import_setting',
            'label'       => __( 'Demo Import', 'benevolent-pro' ),
            'description' => $descritpion
        ))
    );
    /** Demo Import Ends */
}
add_action( 'customize_register', 'benevolent_pro_customize_register_demo' );

if( class_exists( 'WP_Customize_control' ) ){

	class Theme_Info_Custom_Control extends WP_Customize_Control
	{
    	/**
       	* Render the content on the theme customizer page
      	*/
       	public function render_content()
       	{
       		?>
       		<label>
      			<strong class="customize-text_editor"><?php echo esc_html( $this->label ); ?></strong>
       			<br />
       			<span class="customize-text_editor_desc">
       				<?php echo wp_kses_post( $this->description ); ?>
       			</span>
       		</label>
      		<?php
       	}
    }//editor close
}//class close