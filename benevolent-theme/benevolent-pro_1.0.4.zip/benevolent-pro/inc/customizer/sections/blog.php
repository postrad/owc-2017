<?php
/**
 * Blog/Archive Options
 *
 * @package Benevolent
 */

function benevolent_pro_customize_register_blog( $wp_customize ) {

    /* Option list of all categories */
    $args = array(
	   'type'                     => 'post',
	   'orderby'                  => 'name',
	   'order'                    => 'ASC',
	   'hide_empty'               => 1,
	   'hierarchical'             => 1,
	   'taxonomy'                 => 'category'
    ); 
    $option_categories = array();
    $category_lists = get_categories( $args );
    foreach( $category_lists as $category ){
        $option_categories[$category->term_id] = $category->name;
    }
    
    Kirki::add_section( 'benevolent_pro_blog_page_settings', array(
        'priority'   => 27,
        'capability' => 'edit_theme_options',
        'title'      => __( 'Blog Page Settings', 'benevolent-pro' ),
    ) );
    
    Kirki::add_field( 'benevolent_pro', array(
        'settings' => 'benevolent_pro_blog_layout',
        'label'    => __( 'Blog Page Layout', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_blog_page_settings',
        'type'     => 'radio',
        'default'  => 'default',
        'choices'  => array(
            'default' => __( 'Default', 'benevolent-pro' ),
            'square'  => __( 'Square Image', 'benevolent-pro' ),
            'round'   => __( 'Round Image', 'benevolent-pro' ),
        )
    ) );
    
    Kirki::add_field( 'benevolent_pro', array(
        'settings'    => 'benevolent_pro_exclude_categories',
        'label'       => __( 'Exclude Categories', 'benevolent-pro' ),
        'description' => __( 'Check multiple categories to exclude from blog and archive page.', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_blog_page_settings',
        'type'        => 'multicheck',
        'choices'     => $option_categories
    ) ); 
    
}
add_action( 'customize_register', 'benevolent_pro_customize_register_blog' );