<?php
/**
 * Social Options
 *
 * @package Benevolent_Pro
 */

function benevolent_pro_customize_register_social( $wp_customize ) {
    
    Kirki::add_section( 'benevolent_pro_social_settings', array(
        'title'      => __( 'Social Settings', 'benevolent-pro' ),
        'priority'   => 35,
        'capability' => 'edit_theme_options',
    ) );
    
    /** Enable/Disable Social in Header */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'toggle',
        'settings'    => 'benevolent_pro_ed_social_header',
        'label'       => __( 'Enable Social Links in Header', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_social_settings',
        'default'     => '',
    ) );
    
    Kirki::add_field( 'benevolent_pro', array(
        'label'     => __( 'Social Icons in Contact Widget', 'benevolent-pro' ),
        'section'   => 'benevolent_pro_social_settings',
        'settings'  => 'benevolent_pro_social_contact',
        'help'      => __( 'You can rearrange the order you want.', 'benevolent-pro' ),
        'type'      => 'select',
        'multiple'    => 5,
        'default'   => array( 'facebook', 'twitter', 'linkedin', 'google-plus', 'pinterest' ),
        'choices'   => benevolent_pro_social_icons()
    ) );
    
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'repeater',
        'settings'    => 'benevolent_pro_social',
        'label'       => __( 'Add Social Links', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_social_settings',
        'default'     => array(
    		array(
    			'icon' => 'facebook',
    			'link' => 'https://facebook.com',
    		),
    		array(
    			'icon' => 'twitter',
    			'link' => 'https://twitter.com',
    		),
        ),
        'fields'     => array(
            'icon'     => array(
                'type'     => 'select',
                'label'    => __( 'Social Icon', 'benevolent-pro' ),
                'choices'  => benevolent_pro_social_icons(),
                'default'  => 'dribbble'
            ),
            'link'     => array(
                'type'  => 'url',
                'label' => __( 'Link', 'benevolent-pro' ),
                'description'  => __( 'Leave blank if you do not want to show.', 'benevolent-pro' ),
            )
        ),
        'row_label' => array(
            'type' => 'field',
            'value' => __( 'link', 'benevolent-pro' ),
            'field' => 'icon'
        ),               
    ) );

}
add_action( 'customize_register', 'benevolent_pro_customize_register_social' );