<?php
/**
 * Post Meta Options
 *
 * @package Benevolent
 */

function benevolent_pro_customize_register_postmeta( $wp_customize ) {

    Kirki::add_section( 'benevolent_pro_post_meta_settings', array(
        'title' => __( 'Post Meta Settings', 'benevolent-pro' ),
        'priority' => 29,
        'capability' => 'edit_theme_options',
    ));
    
    /** Post Meta */
    Kirki::add_field( 'benevolent_pro', array(
        'label'     => __( 'Post Meta', 'benevolent-pro' ),
        'section'   => 'benevolent_pro_post_meta_settings',
        'settings'  => 'benevolent_pro_post_meta',
        'help'      => __( 'You can rearrange the order you want.', 'benevolent-pro' ),
        'type'      => 'select',
        'multiple'    => 3,
        'default'   => array( 'date', 'author', 'comment' ),
        'choices'   => array(
            'date'    => __( 'Date', 'benevolent-pro' ),
            'author'  => __( 'Author', 'benevolent-pro' ),
            'comment' => __( 'Comment', 'benevolent-pro' ),
        ),
        
    ) );
    
    /** Categories and Tags */
    Kirki::add_field( 'benevolent_pro', array(
        'label'     => __( 'Categories and Tags', 'benevolent-pro' ),
        'section'   => 'benevolent_pro_post_meta_settings',
        'settings'  => 'benevolent_pro_cat_tag',
        'help'      => __( 'You can rearrange the order you want.', 'benevolent-pro' ),
        'type'      => 'select',
        'multiple'    => 2,
        'default'   => array( 'cat', 'tag' ),
        'choices'   => array(
            'cat'   => __( 'Categories', 'benevolent-pro' ),
            'tag'   => __( 'Tags', 'benevolent-pro' ),
        ),
        
    ) );
    
    /** No. of Character */
    Kirki::add_field( 'benevolent_pro', array(
        'label'     => __( 'No. of Character of Post Excerpt', 'benevolent-pro' ),
        'section'   => 'benevolent_pro_post_meta_settings',
        'settings'  => 'benevolent_pro_post_no_of_char',
        'type'      => 'slider',
        'default'   => 200,
        'choices'   => array(
            'min'   => 50,
            'max'   => 500,
            'step'  => 10
        ),
    ) );
    
    /** Read More Text */
    Kirki::add_field( 'benevolent_pro', array(
        'label'     => __( 'Post Read More Text', 'benevolent-pro' ),
        'section'   => 'benevolent_pro_post_meta_settings',
        'settings'  => 'benevolent_pro_post_read_more',
        'type'      => 'text',
        'default'   => __( 'Read More', 'benevolent-pro' ),
    ) );
}
add_action( 'customize_register', 'benevolent_pro_customize_register_postmeta' );