<?php
/**
 * Post Page Options
 *
 * @package Benevolent
 */

function benevolent_pro_customize_register_postpage( $wp_customize ) {

    Kirki::add_section( 'benevolent_pro_post_page_settings', array(
        'priority'   => 28,
        'capability' => 'edit_theme_options',
        'title'      => __( 'Post Page Settings', 'benevolent-pro' ),
    ) );
    
    /** Featured Image */
    Kirki::add_field( 'benevolent_pro', array(
        'label'     => __( 'Show Featured Image', 'benevolent-pro' ),
        'section'   => 'benevolent_pro_post_page_settings',
        'settings'  => 'benevolent_pro_ed_featured_image',
        'type'      => 'toggle',
        'default'   => '1',
    ) );
    
    /** Comments */
    Kirki::add_field( 'benevolent_pro', array(
        'label'     => __( 'Show Comments', 'benevolent-pro' ),
        'section'   => 'benevolent_pro_post_page_settings',
        'settings'  => 'benevolent_pro_ed_comments',
        'type'      => 'toggle',
        'default'   => '1',
    ) );
    
    /** Highlight Author Comment */
    Kirki::add_field( 'benevolent_pro', array(
        'label'     => __( 'Highlight Author Comment', 'benevolent-pro' ),
        'section'   => 'benevolent_pro_post_page_settings',
        'settings'  => 'benevolent_pro_ed_auth_comments',
        'type'      => 'toggle',
        'default'   => '',
    ) ); 
}
add_action( 'customize_register', 'benevolent_pro_customize_register_postpage' );