<?php
/**
 * Google Map Options
 *
 * @package Benevolent
 */

function benevolent_pro_customize_register_google( $wp_customize ) {
    
    /** Zoom Level */
    $zoom = array();
    for($z = 1; $z < 20; $z++){
        $zoom[$z] = $z;    
    }
    
    /** Google Map Settings */
    Kirki::add_section( 'benevolent_pro_google_map_section', array(
        'title'      => __( 'Google Map Settings', 'benevolent-pro' ),
        'description'=> __( 'Google Map can be displayed in the contact page. Make sure you have created a page with Contact Form template for the map to be displayed in it.', 'benevolent-pro' ),
        'priority'   => 30,
        'capability' => 'edit_theme_options',
    ) );
    
    /** Enable/Disable Google map */
    Kirki::add_field( 'benevolent_pro', array(
        'settings' => 'benevolent_pro_ed_google_map',
        'label'    => __( 'Enable/Disable Google map', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_google_map_section',
        'type'     => 'toggle',
        'default'  => ''
    ) );
    
    /** Enable/Disable Scrolling Wheel */
    Kirki::add_field( 'benevolent_pro', array(
        'settings' => 'benevolent_pro_ed_map_scroll',
        'label'    => __( 'Enable/Disable Scrolling Wheel', 'benevolent-pro' ),
        'help'     => __( 'Zoom map on Scrolling', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_google_map_section',
        'type'     => 'toggle',
        'default'  => '1'
    ) );
    
    /** Enable/Disable Map Controls */
    Kirki::add_field( 'benevolent_pro', array(
        'settings' => 'benevolent_pro_ed_map_controls',
        'label'    => __( 'Enable/Disable Map Controls', 'benevolent-pro' ),
        'help'     => __( 'Controls icons that appears above Map', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_google_map_section',
        'type'     => 'toggle',
        'default'  => '1'
    ) );
    
    /** Enable/Disable Map Marker */
    Kirki::add_field( 'benevolent_pro', array(
        'settings' => 'benevolent_pro_ed_map_marker',
        'label'    => __( 'Enable/Disable Map Marker', 'benevolent-pro' ),
        'help'     => __( 'Marker icons that appears above Map', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_google_map_section',
        'type'     => 'toggle',
        'default'  => ''
    ) );
    
    /** Marker Title */ 
    Kirki::add_field( 'benevolent_pro', array(
        'settings' => 'benevolent_pro_marker_title',
        'label'    => __( 'Marker Title', 'benevolent-pro' ),
        'help'     => __( 'Enter the Marker Title', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_google_map_section',
        'type'     => 'text',
        'default'  => '',
        'active_callback' => array(
        	array(
        		'setting'  => 'benevolent_pro_ed_map_marker',
        		'operator' => '==',
        		'value'    => 1,
        	),
         )
    ) );
    
    /** API Key */ 
    Kirki::add_field( 'benevolent_pro', array(
        'settings' => 'benevolent_pro_map_api',
        'label'    => __( 'Google Map API Key', 'benevolent-pro' ),
        'help'     => __( 'Enter the Google Map API Key', 'benevolent-pro' ),
        'description' => __( 'You can get API key from here https://developers.google.com/maps/documentation/javascript/get-api-key', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_google_map_section',
        'type'     => 'text',
        'default'  => ''
    ) );
    
    /** Latitude */ 
    Kirki::add_field( 'benevolent_pro', array(
        'settings' => 'benevolent_pro_lattitude',
        'label'    => __( 'Latitude', 'benevolent-pro' ),
        'help'     => __( 'Enter the Latitude of your Location', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_google_map_section',
        'type'     => 'number',
        'default'  => 27.7304135
    ) );
    
    /** Longitude */ 
    Kirki::add_field( 'benevolent_pro', array(
        'settings' => 'benevolent_pro_longitude',
        'label'    => __( 'Longitude', 'benevolent-pro' ),
        'help'     => __( 'Enter the Longitude of your Location', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_google_map_section',
        'type'     => 'number',
        'default'  => 85.3304937
    ) );
   
    /** Map Height */ 
    Kirki::add_field( 'benevolent_pro', array(
        'settings' => 'benevolent_pro_map_height',
        'label'    => __( 'Map Height', 'benevolent-pro' ),
        'help'     => __( 'Enter the height of map for example: 300', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_google_map_section',
        'type'     => 'number',
        'default'  => 500
    ) );
    
    /** Zoom Level */
    Kirki::add_field( 'benevolent_pro', array(
        'settings' => 'benevolent_pro_map_zoom',
        'label'    => __( 'Zoom Level', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_google_map_section',
        'type'     => 'select',
        'default'  => '17',
        'choices'  => $zoom
    ) );
    
    /** Map Type */
    Kirki::add_field( 'benevolent_pro', array(
        'settings' => 'benevolent_pro_map_type',
        'label'    => __( 'Map Type', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_google_map_section',
        'type'     => 'select',
        'default'  => 'ROADMAP',
        'choices'  => array(
            'ROADMAP'   => __( 'ROADMAP', 'benevolent-pro' ),
            'SATELLITE' => __( 'SATELLITE', 'benevolent-pro' ),
            'HYBRID'    => __( 'HYBRID', 'benevolent-pro' ),
            'TERRAIN'   => __( 'TERRAIN', 'benevolent-pro' )
        )
    ) );
    
}
add_action( 'customize_register', 'benevolent_pro_customize_register_google' );