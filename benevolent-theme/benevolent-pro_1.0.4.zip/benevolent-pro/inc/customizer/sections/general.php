<?php
/**
 * General Options
 *
 * @package Benevolent_Pro
 */

function benevolent_pro_customize_register_general( $wp_customize ) {
	
    $wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';
    
    Kirki::add_config( 'benevolent_pro', array(
        'capability'    => 'edit_theme_options',
        'option_type'   => 'theme_mod',
        'disable_output'=> true,
    ) );
    
    Kirki::add_section( 'benevolent_pro_general_settings', array(
        'priority'   => 22,
        'capability' => 'edit_theme_options',
        'title'      => __( 'General Settings', 'benevolent-pro' ),
    ) );
    
    /** Admin Bar */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'toggle',
        'settings'    => 'benevolent_pro_ed_adminbar',
        'label'       => __( 'Disable Admin Bar', 'benevolent-pro' ),
        'help'        => __( 'Enable to disable Admin Bar in frontend when logged in.', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_general_settings',
        'default'     => '',
    ) );
        
    /** Lightbox */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'toggle',
        'settings'    => 'benevolent_pro_ed_lightbox',
        'label'       => __( 'Enable Lightbox', 'benevolent-pro' ),
        'help'        => __( 'A lightbox is a stylized pop-up that allows your visitors to view larger versions of images without leaving the current page. You can enable or disable the lightbox here.', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_general_settings',
        'default'     => '',
    ) );
    
    /** Ajax Quick Search */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'toggle',
        'settings'    => 'benevolent_pro_ed_ajax_search',
        'label'       => __( 'Enable Ajax Quick Search', 'benevolent-pro' ),
        'help'        => __( 'Enable to display search results appearing instantly below the search form.', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_general_settings',
        'default'     => '',
    ) );
    
    /** Pagination Type */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'radio',
        'settings'    => 'benevolent_pro_pagination_type',
        'label'       => __( 'Pagination Type', 'benevolent-pro' ),
        'help'        => __( 'Select pagination type.', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_general_settings',
        'default'     => 'default',
        'choices'     => array(
            'default'         => __( 'Default (Next / Previous)', 'benevolent-pro' ),
            'numbered'        => __( 'Numbered (1 2 3 4...)', 'benevolent-pro' ),
            'load_more'       => __( 'AJAX (Load More Button)', 'benevolent-pro' ),
            'infinite_scroll' => __( 'AJAX (Auto Infinite Scroll)', 'benevolent-pro' ),
        )  
    ) );
    
}
add_action( 'customize_register', 'benevolent_pro_customize_register_general' );