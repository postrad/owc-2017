<?php
/**
 * Styling Options
 *
 * @package Benevolent
 */

function benevolent_pro_customize_register_styling( $wp_customize ) {

    Kirki::add_section( 'benevolent_pro_styling_settings', array(
        'priority'   => 32,
        'capability' => 'edit_theme_options',
        'title'      => __( 'Styling Settings', 'benevolent-pro' ),
    ) );
    
    /** Layout Style */
    Kirki::add_field( 'benevolent_pro', array(
        'label'     => __( 'Layout Style', 'benevolent-pro' ),
        'help'      => __( 'Choose the default sidebar position for your site. The position of the sidebar for individual posts can be set in the post editor.', 'benevolent-pro' ),
        'section'   => 'benevolent_pro_styling_settings',
        'settings'  => 'benevolent_pro_layout_style',
        'type'      => 'radio-image',
        'default'   => 'right-sidebar',
        'choices'   => array(
            'left-sidebar' => get_template_directory_uri() . '/images/left-sidebar.png',
            'right-sidebar' => get_template_directory_uri() . '/images/right-sidebar.png',
        )
    ) );
    
    /** Color Scheme */
    Kirki::add_field( 'benevolent_pro', array(
        'label'     => __( 'Color Scheme', 'benevolent-pro' ),
        'help'      => __( 'The theme comes with unlimited color schemes for your theme styling.', 'benevolent-pro' ),
        'section'   => 'benevolent_pro_styling_settings',
        'settings'  => 'benevolent_pro_color_scheme',
        'type'      => 'color',
        'default'   => '#45c267',
    ) );
    
    /** Secondary Color Scheme */
    Kirki::add_field( 'benevolent_pro', array(
        'label'     => __( 'Secondary Color Scheme', 'benevolent-pro' ),
        'help'      => __( 'Secondary color scheme for your theme styling. Please choose dark based color.', 'benevolent-pro' ),
        'section'   => 'benevolent_pro_styling_settings',
        'settings'  => 'benevolent_pro_secondary_color_scheme',
        'type'      => 'color',
        'default'   => '#F8B016',
    ) );
    
    /** Background Color */
    Kirki::add_field( 'benevolent_pro', array(
        'label'     => __( 'Background Color', 'benevolent-pro' ),
        'help'      => __( 'Pick a color for site background.', 'benevolent-pro' ),
        'section'   => 'benevolent_pro_styling_settings',
        'settings'  => 'benevolent_pro_bg_color',
        'type'      => 'color',
        'default'   => '#FFFFFF',
    ) );
    
    /** Body Background */
    Kirki::add_field( 'benevolent_pro', array(
        'label'     => __( 'Body Background', 'benevolent-pro' ),
        'help'      => __( 'Choose body background as image or pattern.', 'benevolent-pro' ),
        'section'   => 'benevolent_pro_styling_settings',
        'settings'  => 'benevolent_pro_body_bg',
        'type'      => 'radio-buttonset',
        'default'   => 'image',
        'choices'     => array(
            'image'   => __( 'Image', 'benevolent-pro' ),
            'pattern' => __( 'Pattern', 'benevolent-pro' ),
        ),
    ) );
    
    /** Background Image */
    Kirki::add_field( 'benevolent_pro', array(
        'label'     => __( 'Background Image', 'benevolent-pro' ),
        'help'      => __( 'Upload your own custom background image or pattern.', 'benevolent-pro' ),
        'section'   => 'benevolent_pro_styling_settings',
        'settings'  => 'benevolent_pro_bg_image',
        'type'      => 'image',
        'default'   => '',
        'active_callback'  => array(
            array(
                'setting'  => 'benevolent_pro_body_bg',
                'operator' => '==',
                'value'    => 'image',
            )
        )
    ) );
    
    /** Background Pattern */
    Kirki::add_field( 'benevolent_pro', array(
        'label'     => __( 'Background Pattern', 'benevolent-pro' ),
        'help'      => __( 'Choose from any of 63 awesome background patterns for your site background.', 'benevolent-pro' ),
        'section'   => 'benevolent_pro_styling_settings',
        'settings'  => 'benevolent_pro_bg_pattern',
        'type'      => 'radio-image',
        'default'   => 'nobg',
        'choices'   => benevolent_pro_get_patterns(),
        'active_callback'  => array(
            array(
                'setting'  => 'benevolent_pro_body_bg',
                'operator' => '==',
                'value'    => 'pattern',
            )
        )
    ) );
}
add_action( 'customize_register', 'benevolent_pro_customize_register_styling' );