<?php
/**
 * BreadCrumb Options
 *
 * @package Benevolent_Pro
 */

function benevolent_pro_customize_register_breadcrumb( $wp_customize ) {

    Kirki::add_section( 'benevolent_pro_breadcrumb_settings', array(
        'priority'   => 31,
        'capability' => 'edit_theme_options',
        'title'      => __( 'BreadCrumb Settings', 'benevolent-pro' ),
    ) );
    
    /** Enable/Disable BreadCrumb */
    Kirki::add_field( 'benevolent_pro', array(
        'label'     => __( 'Enable Breadcrumb', 'benevolent-pro' ),
        'section'   => 'benevolent_pro_breadcrumb_settings',
        'settings'  => 'benevolent_pro_ed_breadcrumb',
        'type'      => 'toggle',
        'default'   => '',
    ) );
    
    /** Show/Hide Current */
    Kirki::add_field( 'benevolent_pro', array(
        'label'     => __( 'Show Current', 'benevolent-pro' ),
        'section'   => 'benevolent_pro_breadcrumb_settings',
        'settings'  => 'benevolent_pro_ed_current',
        'type'      => 'toggle',
        'default'   => '1',
    ) );
    
    /** Home Text */
    Kirki::add_field( 'benevolent_pro', array(
        'label'     => __( 'Breadcrumb Home Text', 'benevolent-pro' ),
        'section'   => 'benevolent_pro_breadcrumb_settings',
        'settings'  => 'benevolent_pro_breadcrumb_home_text',
        'type'      => 'text',
        'default'   => __( 'Home', 'benevolent-pro' ),
    ) );
    
    /** Breadcrumb Separator */
    Kirki::add_field( 'benevolent_pro', array(
        'label'     => __( 'Breadcrumb Separator', 'benevolent-pro' ),
        'section'   => 'benevolent_pro_breadcrumb_settings',
        'settings'  => 'benevolent_pro_breadcrumb_separator',
        'type'      => 'text',
        'default'   => __( '>', 'benevolent-pro' ),
        'sanitize_callback' => 'wp_kses_post',
    ) );

}
add_action( 'customize_register', 'benevolent_pro_customize_register_breadcrumb' );