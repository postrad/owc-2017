<?php
/**
 * Footer Options
 *
 * @package Benevolent
 */

function benevolent_pro_customize_register_footer( $wp_customize ) {

    Kirki::add_section( 'benevolent_pro_footer_settings', array(
        'title' => __( 'Footer Settings', 'benevolent-pro' ),
        'priority' => 122,
        'capability' => 'edit_theme_options',
    ) );
    
    /** Footer Copyright*/
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'text',
        'settings'    => 'benevolent_pro_footer_copyright',
        'label'       => __( 'Footer Copyright', 'benevolent-pro' ),
        'help'        => __( 'You can change footer copyright and use your own custom text from here.', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_footer_settings',
        'default'     => '',
        'sanitize_callback' => 'wp_kses_post',
    ) );
    
    /** Hide Author Link */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'toggle',
        'settings'    => 'benevolent_pro_ed_author_link',
        'label'       => __( 'Hide Author Link', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_footer_settings',
        'default'     => '',
    ) );
    
    /** Hide WordPress Link */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'toggle',
        'settings'    => 'benevolent_pro_ed_wp_link',
        'label'       => __( 'Hide WordPress Link', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_footer_settings',
        'default'     => '',
    ) );
}
add_action( 'customize_register', 'benevolent_pro_customize_register_footer' );