<?php
/**
 * Custom Options
 *
 * @package Benevolent_Pro
 */

function benevolent_pro_customize_register_custom( $wp_customize ) {
    
    if ( version_compare( $GLOBALS['wp_version'], '4.7', '<' ) ) {
        
        Kirki::add_section( 'benevolent_pro_custom_settings', array(
            'title'      => __( 'Custom Codes', 'benevolent-pro' ),
            'priority'   => 121,
            'capability' => 'edit_theme_options',
        ) );
        
        /** Custom Script */
        Kirki::add_field( 'benevolent_pro', array(
            'type'        => 'code',
            'settings'    => 'benevolent_pro_custom_script',
            'label'       => __( 'Custom Script', 'benevolent-pro' ),
            'help'        => __( 'Put the script like anlytics or any other here.', 'benevolent-pro' ),
            'section'     => 'benevolent_pro_custom_settings',
            'choices'     => array(
                'language' => 'javascript',
                'theme'    => 'monokai',
            ),
        ) );
        
        /** Custom CSS */
        Kirki::add_field( 'benevolent_pro', array(
            'type'        => 'code',
            'settings'    => 'benevolent_pro_custom_css',
            'label'       => __( 'Custom CSS', 'benevolent-pro' ),
            'help'        => __( 'Put your custom css here.', 'benevolent-pro' ),
            'section'     => 'benevolent_pro_custom_settings',
            'choices'     => array(
                'language' => 'css',
                'theme'    => 'monokai',
            ),
        ) );
    
    }
    
}
add_action( 'customize_register', 'benevolent_pro_customize_register_custom' );