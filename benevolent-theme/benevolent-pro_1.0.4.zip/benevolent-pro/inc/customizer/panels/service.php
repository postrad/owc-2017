<?php
/**
 * Service Page Options
 *
 * @package Benevolent
 */

function benevolent_pro_customize_register_service( $wp_customize ) {

    Kirki::add_panel( 'benevolent_pro_service_page_settings', array(
        'priority'    => 26,
        'capability'  => 'edit_theme_options',
        'title'       => __( 'Service Page Settings', 'benevolent-pro' ),
        'description' => __( 'Customize Service Page Settings', 'benevolent-pro' ),
    ) );
    
    /** Services Section Widgets 40 */
    
    /** CTA 50 */
}
add_action( 'customize_register', 'benevolent_pro_customize_register_service' );