<?php
/**
 * Slider Content Section Options
 *
 * @package Benevolent_Pro
 */

function benevolent_pro_customize_register_slider_content( $wp_customize ) {
    
    global $benevolent_pro_options_posts, $benevolent_pro_option_categories;
    
    /** Slider Contents */
    Kirki::add_section( 'benevolent_pro_slider_contents', array(
        'title' => __( 'Slider Contents', 'benevolent-pro' ),
        'priority' => 30,
        'panel' => 'benevolent_pro_slider_settings',
    ) );
    
    /** Select Slider Type */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'select',
        'settings'    => 'benevolent_pro_slider_type',
        'label'       => __( 'Choose Slider Type', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_slider_contents',
        'default'     => 'post',
        'choices'     => array(
                'post' => __( 'Post/Page', 'benevolent-pro' ),
                'cat' => __( 'Category', 'benevolent-pro' ),
                'custom' => __( 'Custom', 'benevolent-pro' ),
            )
    ) );
    
    /** Select Post One */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'select',
        'settings'    => 'benevolent_pro_slider_post_one',
        'label'       => __( 'Choose Post One', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_slider_contents',
        'default'     => '',
        'choices'     => $benevolent_pro_options_posts,
        'required'  => array(
            array(
                'setting'  => 'benevolent_pro_slider_type',
                'operator' => '==',
                'value'    => 'post',
            )            
        )
    ) );
    
    /** Select Post Two */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'select',
        'settings'    => 'benevolent_pro_slider_post_two',
        'label'       => __( 'Choose Post Two', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_slider_contents',
        'default'     => '',
        'choices'     => $benevolent_pro_options_posts,
        'required'  => array(
            array(
                'setting'  => 'benevolent_pro_slider_type',
                'operator' => '==',
                'value'    => 'post',
            )            
        )
    ) );
    /** Select Post Three */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'select',
        'settings'    => 'benevolent_pro_slider_post_three',
        'label'       => __( 'Choose Post Three', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_slider_contents',
        'default'     => '',
        'choices'     => $benevolent_pro_options_posts,
        'required'  => array(
            array(
                'setting'  => 'benevolent_pro_slider_type',
                'operator' => '==',
                'value'    => 'post',
            )            
        )
    ) );
    
    /** Select Post Four */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'select',
        'settings'    => 'benevolent_pro_slider_post_four',
        'label'       => __( 'Choose Post Four', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_slider_contents',
        'default'     => '',
        'choices'     => $benevolent_pro_options_posts,
        'required'  => array(
            array(
                'setting'  => 'benevolent_pro_slider_type',
                'operator' => '==',
                'value'    => 'post',
            )            
        )
    ) );
    
    /** Select Post Five */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'select',
        'settings'    => 'benevolent_pro_slider_post_five',
        'label'       => __( 'Choose Post Five', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_slider_contents',
        'default'     => '',
        'choices'     => $benevolent_pro_options_posts,
        'required'  => array(
            array(
                'setting'  => 'benevolent_pro_slider_type',
                'operator' => '==',
                'value'    => 'post',
            )            
        )
    ) );
    
    /** Select Category */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'select',
        'settings'    => 'benevolent_pro_slider_cat',
        'label'       => __( 'Choose Slider Category', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_slider_contents',
        'default'     => '',
        'choices'     => $benevolent_pro_option_categories,
        'required'  => array(
            array(
                'setting'  => 'benevolent_pro_slider_type',
                'operator' => '==',
                'value'    => 'cat',
            )            
        )
    ) );
    
    /** Add Slides */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'repeater',
        'settings'    => 'benevolent_pro_slider_slides',
        'label'       => __( 'Add Sliders', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_slider_contents',
        'default'     => '',
        'fields'     => array(
            'thumbnail' => array(
                'type'  => 'image', 
                'label' => __( 'Add Image', 'benevolent-pro' ),                
            ),
            'title'     => array(
                'type'  => 'text',
                'label' => __( 'Title', 'benevolent-pro' ),
            ),
            'content'   => array(
                'type'  => 'textarea',
                'label' => __( 'Content', 'benevolent-pro' ),
            ),
            'link'     => array(
                'type'  => 'text',
                'label' => __( 'Link', 'benevolent-pro' ),
                
            )
        ),
        'required'  => array(
            array(
                'setting'  => 'benevolent_pro_slider_type',
                'operator' => '==',
                'value'    => 'custom',
            )            
        ),
        'row_label' => array(
            'type' => 'field', // [default 'text']
            'value' => __( 'slides', 'benevolent-pro' ),
            'field' => 'title',// [only used if type = field, the field-id must exist in fields and be a text field]
        ),  
    ) );
    
    /** Slider Readmore */
    Kirki::add_field( 'benevolent_pro', array(
        'type'      => 'text',
        'settings'  => 'benevolent_pro_slider_readmore',
        'label'     => __( 'Readmore Text', 'benevolent-pro' ),
        'section'   => 'benevolent_pro_slider_contents',
        'default'   => __( 'Learn More', 'benevolent-pro' ),
    ) );
    
}
add_action( 'customize_register', 'benevolent_pro_customize_register_slider_content' );