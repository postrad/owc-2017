<?php
/**
 * Slider Options Section
 *
 * @package Benevolent_Pro
 */

function benevolent_pro_customize_register_slider_option( $wp_customize ) {
    
    /** Slider Options */
    Kirki::add_section( 'benevolent_pro_slider_options', array(
        'title' => __( 'Slider Options', 'benevolent-pro' ),
        'priority' => 20,
        'panel' => 'benevolent_pro_slider_settings',
    ) );
    
    /** Enable/Disable Slider */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'toggle',
        'settings'    => 'benevolent_pro_ed_slider',
        'label'       => __( 'Enable Home Page Slider', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_slider_options',
        'default'     => '',
    ) );
    
    /** Enable/Disable Slider Auto Transition */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'toggle',
        'settings'    => 'benevolent_pro_slider_auto',
        'label'       => __( 'Enable Slider Auto Transition', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_slider_options',
        'default'     => '1',
    ) );
    
    /** Enable/Disable Slider Loop */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'toggle',
        'settings'    => 'benevolent_pro_slider_loop',
        'label'       => __( 'Enable Slider Loop', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_slider_options',
        'default'     => '1',
    ) );
    
    /** Enable/Disable Slider Pager */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'toggle',
        'settings'    => 'benevolent_pro_slider_pager',
        'label'       => __( 'Enable Slider Pager', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_slider_options',
        'default'     => '1',
    ) );
    
    /** Enable/Disable Slider Caption */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'toggle',
        'settings'    => 'benevolent_pro_slider_caption',
        'label'       => __( 'Enable Slider Caption', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_slider_options',
        'default'     => '1',
    ) );
    
    /** Use Full Size Image */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'toggle',
        'settings'    => 'benevolent_pro_slider_full_image',
        'label'       => __( 'Use Full Size Image', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_slider_options',
        'default'     => '',
    ) );
    
    /** Slider Animation */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'select',
        'settings'    => 'benevolent_pro_slider_animation',
        'label'       => __( 'Choose Slider Animation', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_slider_options',
        'default'     => 'slide',
        'choices' => array(
                'fade'  => __( 'Fade', 'benevolent-pro' ),
                'slide' => __( 'Slide', 'benevolent-pro' ),
            )
    ) );
    
    /** Slider Speed */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'slider',
        'settings'    => 'benevolent_pro_slider_speed',
        'label'       => __( 'Slider Speed', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_slider_options',
        'default'     => 400,
        'choices' => array(
                'min' => 100,
                'max' => 1000,
                'step'=> 100
            )
    ) );
    
    /** Slider Pause */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'slider',
        'settings'    => 'benevolent_pro_slider_pause',
        'label'       => __( 'Slider Pause', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_slider_options',
        'default'     => 6000,
        'choices' => array(
                'min' => 1000,
                'max' => 10000,
                'step'=> 500
            )
    ) );
    
}
add_action( 'customize_register', 'benevolent_pro_customize_register_slider_option' );