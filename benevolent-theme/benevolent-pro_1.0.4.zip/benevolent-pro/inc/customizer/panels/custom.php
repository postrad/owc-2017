<?php
/**
 * Custom Code Section 
 * 
 * @package Benevolent_Pro
 */

function benevolent_pro_customize_register_custom_panel( $wp_customize ) {
    
    if ( version_compare( $GLOBALS['wp_version'], '4.7', '>=' ) ) {
        
        /** Custom Codes */
        Kirki::add_panel( 'benevolent_pro_custom_code_panel', array(
            'title' => __( 'Custom Codes', 'benevolent-pro' ),
            'priority' => 121,
            'capability' => 'edit_theme_options',
        ) );
        
        Kirki::add_section( 'benevolent_pro_custom_settings', array(
            'title'    => __( 'Custom Script', 'benevolent-pro' ),
            'priority' => 10,
            'panel'    => 'benevolent_pro_custom_code_panel',
        ) );
        
        /** Custom Script */
        Kirki::add_field( 'business_one_page_pro', array(
            'type'        => 'code',
            'settings'    => 'benevolent_pro_custom_script',
            'label'       => __( 'Custom Script', 'benevolent-pro' ),
            'help'        => __( 'Put the script like anlytics or any other here.', 'benevolent-pro' ),
            'section'     => 'benevolent_pro_custom_settings',
            'choices'     => array(
                'language' => 'javascript',
                'theme'    => 'monokai',
                'height'   => 250,
            ),
        ) );
        
        $wp_customize->get_section( 'custom_css' )->panel = 'benevolent_pro_custom_code_panel';
        
    }
}
add_action( 'customize_register', 'benevolent_pro_customize_register_custom_panel' );