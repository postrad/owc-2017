<?php
/**
 * About Page Options
 *
 * @package Benevolent
 */

function benevolent_pro_customize_register_about( $wp_customize ) {
    
    Kirki::add_panel( 'benevolent_pro_about_page_settings', array(
        'priority'    => 25,
        'capability'  => 'edit_theme_options',
        'title'       => __( 'About Page Settings', 'benevolent-pro' ),
        'description' => __( 'Customize About Page Settings', 'benevolent-pro' ),
    ) );
    
    /** Profile icon text widget 40 */
}
add_action( 'customize_register', 'benevolent_pro_customize_register_about' );