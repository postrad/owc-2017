<?php
/**
 * Header Miscellaneous Options
 *
 * @package Benevolent_Pro
 */

function benevolent_pro_customize_register_header_misc( $wp_customize ) {
    
    $args = array(
        'post_type'      => 'give_forms',
        'posts_per_page' => -1,
        'post_status'    => 'publish'
    );
    
    $options_posts = array();
    $posts_obj = get_posts( $args );
    $options_posts[''] = __( 'Choose Form', 'benevolent-pro' );
    foreach ( $posts_obj as $p ) {
    	$options_posts[$p->ID] = $p->post_title;
    }
    
    Kirki::add_section( 'benevolent_pro_header_misc_setting', array(
        'title'      => __( 'Misc Settings', 'benevolent-pro' ),
        'priority'   => 40,
        'panel' => 'benevolent_pro_header_setting',
    ) );
    
    /** Enable/Disable Sticky Header */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'toggle',
        'settings'    => 'benevolent_pro_ed_sticky_header',
        'label'       => __( 'Enable Sticky Header', 'benevolent-pro' ),
        'tooltip'     => __( 'Enable to make header sticky.', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_header_misc_setting',
        'default'     => '',
    ) );
    
    /** Enable/Disable Search Form */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'toggle',
        'settings'    => 'benevolent_pro_ed_search_form',
        'label'       => __( 'Enable Search Form', 'benevolent-pro' ),
        'tooltip'     => __( 'Enable to show search form in header.', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_header_misc_setting',
        'default'     => '1',
    ) );
    
    /** Enable/Disable Donate Button */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'toggle',
        'settings'    => 'benevolent_pro_ed_donate_button',
        'label'       => __( 'Enable Donate Button', 'benevolent-pro' ),
        'tooltip'     => __( 'Enable to show donate button link.', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_header_misc_setting',
        'default'     => '',
    ) );
    
    if( is_give_activated() ){
        /** Use Donate Form */
        Kirki::add_field( 'benevolent_pro', array(
            'type'        => 'toggle',
            'settings'    => 'benevolent_pro_ed_donate_form',
            'label'       => __( 'Use Donate Form', 'benevolent-pro' ),
            'tooltip'     => __( 'Use Donate form instead of custom donate link.', 'benevolent-pro' ),
            'section'     => 'benevolent_pro_header_misc_setting',
            'default'     => '',
            'active_callback' => array(
                array(
                    'setting'  => 'benevolent_pro_ed_donate_button',
                    'operator' => '==',
                    'value'    => 1,  
                ),                            
            ),
        ) );
        
        /** Enable/Disable Donate Button */
        Kirki::add_field( 'benevolent_pro', array(
            'type'        => 'select',
            'settings'    => 'benevolent_pro_donate_form',
            'label'       => __( 'Choose Donate Form', 'benevolent-pro' ),
            'section'     => 'benevolent_pro_header_misc_setting',
            'choices'     => $options_posts,  
            'default'     => '',
            'active_callback' => array(
                array(
                    'setting'  => 'benevolent_pro_ed_donate_form',
                    'operator' => '==',
                    'value'    => 1,  
                ),
                array(
                    'setting'  => 'benevolent_pro_ed_donate_button',
                    'operator' => '==',
                    'value'    => 1,  
                ),                            
            ),
        ) );
    }
    
    /** Donate Button Label */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'text',
        'settings'    => 'benevolent_pro_donate_button_label',
        'label'       => __( 'Donate Button Label', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_header_misc_setting',
        'default'     => __( 'Donate Now', 'benevolent-pro' ),
        'active_callback' => array(
                array(
                    'setting'  => 'benevolent_pro_ed_donate_button',
                    'operator' => '==',
                    'value'    => 1,  
                ),                            
            ),
    ) );
    
    /** Donate Button Url */
    Kirki::add_field( 'benevolent_pro', array(
        'type'              => 'text',
        'settings'          => 'benevolent_pro_donate_button_url',
        'label'             => __( 'Donate Button Url', 'benevolent-pro' ),
        'section'           => 'benevolent_pro_header_misc_setting',
        'default'           => '',
        'sanitize_callback' => 'esc_url_raw',
        'active_callback'   => array(
                array(
                    'setting'  => 'benevolent_pro_ed_donate_button',
                    'operator' => '==',
                    'value'    => 1,  
                ),                            
            ),
    ) );
    
}
add_action( 'customize_register', 'benevolent_pro_customize_register_header_misc' );