<?php
/**
 * Header Options
 *
 * @package Benevolent_Pro
 */

function benevolent_pro_customize_register_header_layout( $wp_customize ) {
    
    Kirki::add_section( 'benevolent_pro_header_layout_setting', array(
        'title'      => __( 'Layout Settings', 'benevolent-pro' ),
        'priority'   => 30,
        'panel' => 'benevolent_pro_header_setting',
    ) );
    
    /** Header Layout */
    Kirki::add_field( 'benevolent_pro', array(
        'label'     => __( 'Header Layout', 'benevolent-pro' ),
        'help'      => __( 'Choose the layout of header for your site.', 'benevolent-pro' ),
        'section'   => 'benevolent_pro_header_layout_setting',
        'settings'  => 'benevolent_pro_header_layout',
        'type'      => 'radio-image',
        'default'   => 'one',
        'choices'   => array(
            'one'    => get_template_directory_uri() . '/images/header-1.jpg',
            'two'    => get_template_directory_uri() . '/images/header-2.jpg',
            'three'  => get_template_directory_uri() . '/images/header-3.jpg',
            'four'   => get_template_directory_uri() . '/images/header-4.jpg',
            'five'   => get_template_directory_uri() . '/images/header-5.jpg',
        )
    ) );
    
}
add_action( 'customize_register', 'benevolent_pro_customize_register_header_layout' );