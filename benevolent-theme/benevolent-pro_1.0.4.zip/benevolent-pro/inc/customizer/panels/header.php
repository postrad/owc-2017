<?php
/**
 * Header Options
 *
 * @package Benevolent_Pro
 */

function benevolent_pro_customize_register_header( $wp_customize ) {
    
    Kirki::add_panel( 'benevolent_pro_header_setting', array(
        'title'      => __( 'Header Settings', 'benevolent-pro' ),
        'priority'   => 21,
        'capability' => 'edit_theme_options',
    ) );
    
    $wp_customize->get_section( 'title_tagline' )->panel = 'benevolent_pro_header_setting';
}
add_action( 'customize_register', 'benevolent_pro_customize_register_header' );