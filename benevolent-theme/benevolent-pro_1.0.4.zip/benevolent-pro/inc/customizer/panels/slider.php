<?php
/**
 * Slider Options
 *
 * @package Benevolent_Pro
 */

function benevolent_pro_customize_register_slider( $wp_customize ) {
    
    Kirki::add_panel( 'benevolent_pro_slider_settings', array(
        'title'          => __( 'Slider Settings', 'benevolent-pro' ),
        'priority'       => 23,
        'capability'     => 'edit_theme_options',
    ) );
        
}
add_action( 'customize_register', 'benevolent_pro_customize_register_slider' );