<?php
/**
 * Home Typography Options
 *
 * @package Benevolent
 */

function benevolent_pro_customize_register_typography_home( $wp_customize ) {

    /** Home Page Section Title Settings */
    Kirki::add_section( 'benevolent_pro_hps_title_section', array(
        'title'      => __( 'Home Page Section Title Settings', 'benevolent-pro' ),
        'priority'   => 11,
        'capability' => 'edit_theme_options',
        'panel'      => 'benevolent_pro_typography_section'
    ) );
    
    /** Home Page Section Title Font */
    Kirki::add_field( 'benevolent_pro', array(
    	'type'        => 'typography',
    	'settings'    => 'benevolent_pro_hps_title_font',
    	'label'       => __( 'Home Page Section Title Font', 'benevolent-pro' ),
        'tooltip'     => __( 'Setting for the Section Title of Home Page Section', 'benevolent-pro' ),
    	'section'     => 'benevolent_pro_hps_title_section',
    	'default'     => array(
    		'font-family' => 'Raleway',
    		'variant'     => '700',
    	),
    ) );
    
    /** Home Page Section Title Font Size */
    Kirki::add_field( 'benevolent_pro', array(    
        'settings' => 'benevolent_pro_hps_title_font_size',
        'label'    => __( 'Home Page Section Title Font Size', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_hps_title_section',
        'default'  => '40',
        'type'     => 'slider',
        'choices'  => array(
                        'min'  => 20,
                        'max'  => 60,
                        'step' => 1,
                    )
    ) );
    
    /** Home Page Section Title Line Height */
    Kirki::add_field( 'benevolent_pro', array(    
        'settings' => 'benevolent_pro_hps_title_line_height',
        'label'    => __( 'Home Page Section Title Line Height', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_hps_title_section',
        'default'  => '48',
        'type'     => 'slider',
        'choices'  => array(
                        'min'  => 20,
                        'max'  => 70,
                        'step' => 1,
                    )
    ) );
        
}
add_action( 'customize_register', 'benevolent_pro_customize_register_typography_home' );