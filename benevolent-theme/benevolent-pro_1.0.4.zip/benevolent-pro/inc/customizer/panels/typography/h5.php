<?php
/**
 * H5 Typography Options
 *
 * @package Benevolent
 */

function benevolent_pro_customize_register_typography_h5( $wp_customize ) {
    
    /** H5 Typography Settings */
    Kirki::add_section( 'benevolent_pro_h5_section', array(
        'title' => __( 'H5 Settings (Content)', 'benevolent-pro' ),
        'priority' => 27,
        'capability' => 'edit_theme_options',
        'panel'     => 'benevolent_pro_typography_section'
    ) );
    
    /** H5 Font */
    Kirki::add_field( 'benevolent_pro', array(
    	'type'        => 'typography',
    	'settings'    => 'benevolent_pro_h5_font',
    	'label'       => __( 'H5 Font', 'benevolent-pro' ),
    	'section'     => 'benevolent_pro_h5_section',
    	'default'     => array(
    		'font-family'    => 'Raleway',
    		'variant'        => 'regular',
    	),
    ) );
    
    /** H5 Font Size */
    Kirki::add_field( 'benevolent_pro', array(    
        'settings' => 'benevolent_pro_h5_font_size',
        'label'    => __( 'H5 Font Size', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_h5_section',
        'default'  => '20',
        'type'     => 'slider',
        'choices'  => array(
                        'min'  => 10,
                        'max'  => 30,
                        'step' => 1,
                    )
    ) );
    
    /** H5 Line Height */
    Kirki::add_field( 'benevolent_pro', array(    
        'settings' => 'benevolent_pro_h5_line_height',
        'label'    => __( 'H5 Line Height', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_h5_section',
        'default'  => '24',
        'type'     => 'slider',
        'choices'  => array(
                        'min'  => 10,
                        'max'  => 35,
                        'step' => 1,
                    )
    ) );
    
    /** H5 Color */
    Kirki::add_field( 'benevolent_pro', array(    
        'settings' => 'benevolent_pro_h5_color',
        'label'    => __( 'H5 Color', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_h5_section',
        'type'     => 'color',
        'default'  => '#121212',
    ) );
    
}
add_action( 'customize_register', 'benevolent_pro_customize_register_typography_h5' );