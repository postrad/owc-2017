<?php
/**
 * H1 Typography Options
 *
 * @package Benevolent
 */

function benevolent_pro_customize_register_typography_h1( $wp_customize ) {
    
    /** H1 Typography Settings */
    Kirki::add_section( 'benevolent_pro_h1_section', array(
        'title' => __( 'H1 Settings (Content)', 'benevolent-pro' ),
        'priority' => 23,
        'capability' => 'edit_theme_options',
        'panel'     => 'benevolent_pro_typography_section'
    ) );
    
    /** H1 Font */
    Kirki::add_field( 'benevolent_pro', array(
    	'type'        => 'typography',
    	'settings'    => 'benevolent_pro_h1_font',
    	'label'       => __( 'H1 Font', 'benevolent-pro' ),
    	'section'     => 'benevolent_pro_h1_section',
    	'default'     => array(
    		'font-family'    => 'Raleway',
    		'variant'        => 'regular',
    	),
    ) );
    
    /** H1 Font Size */
    Kirki::add_field( 'benevolent_pro', array(    
        'settings' => 'benevolent_pro_h1_font_size',
        'label'    => __( 'H1 Font Size', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_h1_section',
        'default'  => '48',
        'type'     => 'slider',
        'choices'  => array(
                        'min'  => 25,
                        'max'  => 70,
                        'step' => 1,
                    )
    ) );
    
    /** H1 Line Height */
    Kirki::add_field( 'benevolent_pro', array(    
        'settings' => 'benevolent_pro_h1_line_height',
        'label'    => __( 'H1 Line Height', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_h1_section',
        'default'  => '57',
        'type'     => 'slider',
        'choices'  => array(
                        'min'  => 30,
                        'max'  => 80,
                        'step' => 1,
                    )
    ) );
    
    /** H1 Color */
    Kirki::add_field( 'benevolent_pro', array(    
        'settings' => 'benevolent_pro_h1_color',
        'label'    => __( 'H1 Color', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_h1_section',
        'type'     => 'color',
        'default'  => '#121212',
    ) );
    
}
add_action( 'customize_register', 'benevolent_pro_customize_register_typography_h1' );