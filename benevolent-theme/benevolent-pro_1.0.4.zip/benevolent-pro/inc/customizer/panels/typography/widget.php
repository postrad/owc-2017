<?php
/**
 * Widget Typography Options
 *
 * @package Benevolent
 */

function benevolent_pro_customize_register_typography_widget( $wp_customize ) {
    
    /** Widget Title Settings */
    Kirki::add_section( 'benevolent_pro_widget_title_section', array(
        'title'      => __( 'Widget Title Settings', 'benevolent-pro' ),
        'priority'   => 29,
        'capability' => 'edit_theme_options',
        'panel'      => 'benevolent_pro_typography_section'
    ) );
    
    /** Widget Title Font */
    Kirki::add_field( 'benevolent_pro', array(
    	'type'        => 'typography',
    	'settings'    => 'benevolent_pro_widget_title_font',
    	'label'       => __( 'Widget Title Font', 'benevolent-pro' ),
    	'section'     => 'benevolent_pro_widget_title_section',
    	'default'     => array(
    		'font-family'    => 'Raleway',
    		'variant'        => '700',
    	),
    ) );
    
    /** Widget Title Font Size */
    Kirki::add_field( 'benevolent_pro', array(    
        'settings' => 'benevolent_pro_widget_title_font_size',
        'label'    => __( 'Widget Title Font Size', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_widget_title_section',
        'default'  => '20',
        'type'     => 'slider',
        'choices'  => array(
                        'min'  => 10,
                        'max'  => 35,
                        'step' => 1,
                    )
    ) );
    
    /** Widget Title Line Height */
    Kirki::add_field( 'benevolent_pro', array(    
        'settings' => 'benevolent_pro_widget_title_line_height',
        'label'    => __( 'Widget Title Line Height', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_widget_title_section',
        'default'  => '35',
        'type'     => 'slider',
        'choices'  => array(
                        'min'  => 20,
                        'max'  => 60,
                        'step' => 1,
                    )
    ) );
    
}
add_action( 'customize_register', 'benevolent_pro_customize_register_typography_widget' );