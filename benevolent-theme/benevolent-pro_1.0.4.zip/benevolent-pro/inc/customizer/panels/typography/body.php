<?php
/**
 * Body Typography Options
 *
 * @package Benevolent
 */

function benevolent_pro_customize_register_typography_body( $wp_customize ) {

    /** Body Settings */
    Kirki::add_section( 'benevolent_pro_typography_body_section', array(
        'title'      => __( 'Body Settings', 'benevolent-pro' ),
        'priority'   => 10,
        'capability' => 'edit_theme_options',
        'panel'      => 'benevolent_pro_typography_section'
    ) );
    
    /** Body Font */
    Kirki::add_field( 'benevolent_pro', array(
    	'type'        => 'typography',
    	'settings'    => 'benevolent_pro_body_font',
    	'label'       => __( 'Body Font', 'benevolent-pro' ),
    	'section'     => 'benevolent_pro_typography_body_section',
    	'default'     => array(
    		'font-family' => 'Raleway',
    		'variant'     => 'regular',
    	),
    ) );
    
    /** Body Font Size */
    Kirki::add_field( 'benevolent_pro', array(    
        'settings' => 'benevolent_pro_body_font_size',
        'label'    => __( 'Body Font Size', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_typography_body_section',
        'default'  => '18',
        'type'     => 'slider',
        'choices'  => array(
                        'min'  => 10,
                        'max'  => 35,
                        'step' => 1,
                    )
    ) );
    
    /** Body Line Height */
    Kirki::add_field( 'benevolent_pro', array(    
        'settings' => 'benevolent_pro_body_line_height',
        'label'    => __( 'Body Line Height', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_typography_body_section',
        'default'  => '28',
        'type'     => 'slider',
        'choices'  => array(
                        'min'  => 15,
                        'max'  => 50,
                        'step' => 1,
                    )
    ) );
    
    /** Body Color */
    Kirki::add_field( 'benevolent_pro', array(    
        'settings' => 'benevolent_pro_body_color',
        'label'    => __( 'Body Color', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_typography_body_section',
        'type'     => 'color',
        'default'  => '#777777',
    ) );
    
}
add_action( 'customize_register', 'benevolent_pro_customize_register_typography_body' );