<?php
/**
 * H2 Typography Options
 *
 * @package Benevolent
 */

function benevolent_pro_customize_register_typography_h2( $wp_customize ) {
    
     /** H2 Typography Settings */
    Kirki::add_section( 'benevolent_pro_h2_section', array(
        'title' => __( 'H2 Settings (Content)', 'benevolent-pro' ),
        'priority' => 24,
        'capability' => 'edit_theme_options',
        'panel'     => 'benevolent_pro_typography_section'
    ) );
    
    /** H2 Font */
    Kirki::add_field( 'benevolent_pro', array(
    	'type'        => 'typography',
    	'settings'    => 'benevolent_pro_h2_font',
    	'label'       => __( 'H2 Font', 'benevolent-pro' ),
    	'section'     => 'benevolent_pro_h2_section',
    	'default'     => array(
    		'font-family'    => 'Raleway',
    		'variant'        => 'regular',
    	),
    ) );
    
    /** H2 Font Size */
    Kirki::add_field( 'benevolent_pro', array(    
        'settings' => 'benevolent_pro_h2_font_size',
        'label'    => __( 'H2 Font Size', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_h2_section',
        'default'  => '40',
        'type'     => 'slider',
        'choices'  => array(
                        'min'  => 20,
                        'max'  => 60,
                        'step' => 1,
                    )
    ) );
    
    /** H2 Line Height */
    Kirki::add_field( 'benevolent_pro', array(    
        'settings' => 'benevolent_pro_h2_line_height',
        'label'    => __( 'H2 Line Height', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_h2_section',
        'default'  => '48',
        'type'     => 'slider',
        'choices'  => array(
                        'min'  => 30,
                        'max'  => 70,
                        'step' => 1,
                    )
    ) );
    
    /** H2 Color */
    Kirki::add_field( 'benevolent_pro', array(    
        'settings' => 'benevolent_pro_h2_color',
        'label'    => __( 'H2 Color', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_h2_section',
        'type'     => 'color',
        'default'  => '#121212',
    ) );
    
}
add_action( 'customize_register', 'benevolent_pro_customize_register_typography_h2' );