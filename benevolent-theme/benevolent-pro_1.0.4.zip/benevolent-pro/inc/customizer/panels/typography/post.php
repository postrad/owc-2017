<?php
/**
 * Post Typography Options 
 *
 * @package Benevolent
 */

function benevolent_pro_customize_register_typography_post( $wp_customize ) {
    
    /** Post Title Settings */
    Kirki::add_section( 'benevolent_pro_post_title_setting', array(
        'title'      => __( 'Post Title Settings', 'benevolent-pro' ),
        'priority'   => 16,
        'capability' => 'edit_theme_options',
        'panel'      => 'benevolent_pro_typography_section'
    ) );
    
    /** Post Title Font */
    Kirki::add_field( 'benevolent_pro', array(
    	'type'        => 'typography',
    	'settings'    => 'benevolent_pro_post_title_font',
    	'label'       => __( 'Post Title Font', 'benevolent-pro' ),
        'tooltip'     => __( 'Setting for Post Title in Blog/Archive Page.', 'benevolent-pro' ),
    	'section'     => 'benevolent_pro_post_title_setting',
    	'default'     => array(
    		'font-family' => 'Raleway',
    		'variant'     => 'regular',
    	),
    ) );
    
    /** Post Title Font Size */
    Kirki::add_field( 'benevolent_pro', array(    
        'settings' => 'benevolent_pro_post_title_font_size',
        'label'    => __( 'Post Title Font Size', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_post_title_setting',
        'default'  => '30',
        'type'     => 'slider',
        'choices'  => array(
                        'min'  => 15,
                        'max'  => 60,
                        'step' => 1,
                    )
    ) );
    
    /** Post Title Line Height */
    Kirki::add_field( 'benevolent_pro', array(    
        'settings' => 'benevolent_pro_post_title_line_height',
        'label'    => __( 'Post Title Line Height', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_post_title_setting',
        'default'  => '36',
        'type'     => 'slider',
        'choices'  => array(
                        'min'  => 20,
                        'max'  => 70,
                        'step' => 1,
                    )
    ) );
    
    /** Post Title Color */
    Kirki::add_field( 'benevolent_pro', array(    
        'settings' => 'benevolent_pro_post_title_color',
        'label'    => __( 'Post Title Color', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_post_title_setting',
        'type'     => 'color',
        'default'  => '#121212',
    ) );
    
}
add_action( 'customize_register', 'benevolent_pro_customize_register_typography_post' );