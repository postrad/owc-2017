<?php
/**
 * Page Typography Options
 *
 * @package Benevolent
 */

function benevolent_pro_customize_register_typography_page( $wp_customize ) {
    
    /** Page Title Settings */
    Kirki::add_section( 'benevolent_pro_page_title_setting', array(
        'title'      => __( 'Page Title Settings', 'benevolent-pro' ),
        'priority'   => 15,
        'capability' => 'edit_theme_options',
        'panel'      => 'benevolent_pro_typography_section'
    ) );
    
    /** Page Title Font */
    Kirki::add_field( 'benevolent_pro', array(
    	'type'        => 'typography',
    	'settings'    => 'benevolent_pro_page_title_font',
    	'label'       => __( 'Page Title Font', 'benevolent-pro' ),
        'tooltip'     => __( 'Setting for Page title above breadcrumb', 'benevolent-pro' ),
    	'section'     => 'benevolent_pro_page_title_setting',
    	'default'     => array(
    		'font-family' => 'Raleway',
    		'variant'     => 'regular',
    	),
    ) );
    
    /** Page Title Font Size */
    Kirki::add_field( 'benevolent_pro', array(    
        'settings' => 'benevolent_pro_page_title_font_size',
        'label'    => __( 'Page Title Font Size', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_page_title_setting',
        'default'  => '38',
        'type'     => 'slider',
        'choices'  => array(
                        'min'  => 20,
                        'max'  => 60,
                        'step' => 1,
                    )
    ) );
    
    /** Page Title Line Height */
    Kirki::add_field( 'benevolent_pro', array(    
        'settings' => 'benevolent_pro_page_title_line_height',
        'label'    => __( 'Page Title Line Height', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_page_title_setting',
        'default'  => '48',
        'type'     => 'slider',
        'choices'  => array(
                        'min'  => 25,
                        'max'  => 70,
                        'step' => 1,
                    )
    ) );
    
    /** Page Title Color */
    Kirki::add_field( 'benevolent_pro', array(    
        'settings' => 'benevolent_pro_page_title_color',
        'label'    => __( 'Page Title Color', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_page_title_setting',
        'type'     => 'color',
        'default'  => '#000000',
    ) );
    
}
add_action( 'customize_register', 'benevolent_pro_customize_register_typography_page' );