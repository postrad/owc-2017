<?php
/**
 * H6 Typography Options
 *
 * @package Benevolent
 */

function benevolent_pro_customize_register_typography_h6( $wp_customize ) {
    
    /** H6 Typography Settings */
    Kirki::add_section( 'benevolent_pro_h6_section', array(
        'title' => __( 'H6 Settings (Content)', 'benevolent-pro' ),
        'priority' => 28,
        'capability' => 'edit_theme_options',
        'panel'     => 'benevolent_pro_typography_section'
    ) );
    
    /** H6 Font */
    Kirki::add_field( 'benevolent_pro', array(
    	'type'        => 'typography',
    	'settings'    => 'benevolent_pro_h6_font',
    	'label'       => __( 'H6 Font', 'benevolent-pro' ),
    	'section'     => 'benevolent_pro_h6_section',
    	'default'     => array(
    		'font-family'    => 'Raleway',
    		'variant'        => 'regular',
    	),
    ) );
    
    /** H6 Font Size */
    Kirki::add_field( 'benevolent_pro', array(    
        'settings' => 'benevolent_pro_h6_font_size',
        'label'    => __( 'H6 Font Size', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_h6_section',
        'default'  => '18',
        'type'     => 'slider',
        'choices'  => array(
                        'min'  => 10,
                        'max'  => 30,
                        'step' => 1,
                    )
    ) );
    
    /** H6 Line Height */
    Kirki::add_field( 'benevolent_pro', array(    
        'settings' => 'benevolent_pro_h6_line_height',
        'label'    => __( 'H6 Line Height', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_h6_section',
        'default'  => '22',
        'type'     => 'slider',
        'choices'  => array(
                        'min'  => 10,
                        'max'  => 35,
                        'step' => 1,
                    )
    ) );
    
    /** H6 Color */
    Kirki::add_field( 'benevolent_pro', array(    
        'settings' => 'benevolent_pro_h6_color',
        'label'    => __( 'H6 Color', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_h6_section',
        'type'     => 'color',
        'default'  => '#121212',
    ) );
    
}
add_action( 'customize_register', 'benevolent_pro_customize_register_typography_h6' );