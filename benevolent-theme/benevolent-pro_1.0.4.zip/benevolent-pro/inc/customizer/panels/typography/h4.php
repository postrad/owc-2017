<?php
/**
 * H4 Typography Options
 *
 * @package Benevolent
 */

function benevolent_pro_customize_register_typography_h4( $wp_customize ) {
    
    /** H4 Typography Settings */
    Kirki::add_section( 'benevolent_pro_h4_section', array(
        'title' => __( 'H4 Settings (Content)', 'benevolent-pro' ),
        'priority' => 26,
        'capability' => 'edit_theme_options',
        'panel'     => 'benevolent_pro_typography_section'
    ) );
    
    /** H4 Font */
    Kirki::add_field( 'benevolent_pro', array(
    	'type'        => 'typography',
    	'settings'    => 'benevolent_pro_h4_font',
    	'label'       => __( 'H4 Font', 'benevolent-pro' ),
    	'section'     => 'benevolent_pro_h4_section',
    	'default'     => array(
    		'font-family'    => 'Raleway',
    		'variant'        => 'regular',
    	),
    ) );
    
    /** H4 Font Size */
    Kirki::add_field( 'benevolent_pro', array(    
        'settings' => 'benevolent_pro_h4_font_size',
        'label'    => __( 'H4 Font Size', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_h4_section',
        'default'  => '24',
        'type'     => 'slider',
        'choices'  => array(
                        'min'  => 10,
                        'max'  => 30,
                        'step' => 1,
                    )
    ) );
    
    /** H4 Line Height */
    Kirki::add_field( 'benevolent_pro', array(    
        'settings' => 'benevolent_pro_h4_line_height',
        'label'    => __( 'H4 Line Height', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_h4_section',
        'default'  => '28',
        'type'     => 'slider',
        'choices'  => array(
                        'min'  => 15,
                        'max'  => 40,
                        'step' => 1,
                    )
    ) );
    
    /** H4 Color */
    Kirki::add_field( 'benevolent_pro', array(    
        'settings' => 'benevolent_pro_h4_color',
        'label'    => __( 'H4 Color', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_h4_section',
        'type'     => 'color',
        'default'  => '#121212',
    ) );
    
}
add_action( 'customize_register', 'benevolent_pro_customize_register_typography_h4' );