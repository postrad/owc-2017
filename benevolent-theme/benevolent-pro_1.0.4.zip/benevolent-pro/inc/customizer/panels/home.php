<?php
/**
 * Home Page Options
 *
 * @package Benevolent_Pro
 */

function benevolent_pro_customize_register_home( $wp_customize ) {

    /** Home Page Settings */
    Kirki::add_panel( 'benevolent_pro_home_page_settings', array(
        'priority'    => 24,
        'capability'  => 'edit_theme_options',
        'title'       => __( 'Home Page Settings', 'benevolent-pro' ),
        'description' => __( 'Customize Home Page Settings', 'benevolent-pro' ),
    ) );
    
    /** Stat Counter Section 40 */    
    
    /** Promotional Section 70 */    
    
}
add_action( 'customize_register', 'benevolent_pro_customize_register_home' );