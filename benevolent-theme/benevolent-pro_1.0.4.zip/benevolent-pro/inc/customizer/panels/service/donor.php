<?php
/**
 * Service Page Donor Section Options
 *
 * @package Benevolent
 */

function benevolent_pro_customize_register_service_donor( $wp_customize ) {
    
    /* Option list of logo categories */
    $args = array(
       'orderby'                  => 'name',
       'order'                    => 'ASC',
       'hide_empty'               => 1,
       'hierarchical'             => 1,
       'taxonomy'                 => 'logo-category'
    ); 
    $option_cat = array();
    $term_lists = get_terms( $args );
    $option_cat[''] = __( 'Choose Logo Category', 'benevolent-pro' );
    foreach( $term_lists as $term ){
        $option_cat[$term->term_id] = $term->name;
    }
    
    /** Donor Section */
    Kirki::add_section( 'benevolent_pro_service_donor_section', array(
        'title'    => __( 'Donor Section', 'benevolent-pro' ),
        'priority' => 60,
        'panel'    => 'benevolent_pro_service_page_settings',
    ) );
    
    Kirki::add_field( 'benevolent_pro', array(
        'type'     => 'text',
        'settings' => 'benevolent_pro_service_donor_title',
        'label'    => __( 'Donor Section Title', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_service_donor_section',
        'default'  => '',
    ) );
    
    Kirki::add_field( 'benevolent_pro', array(
        'type'     => 'textarea',
        'settings' => 'benevolent_pro_service_donor_content',
        'label'    => __( 'Donor Section Content', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_service_donor_section',
        'default'  => '',
    ) );
    
    Kirki::add_field( 'benevolent_pro', array(
        'type'     => 'select',
        'settings' => 'benevolent_pro_service_donor_cat',
        'label'    => __( 'Donor Logo Category', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_service_donor_section',
        'default'  => '',
        'choices'  => $option_cat 
    ) );
    
}
add_action( 'customize_register', 'benevolent_pro_customize_register_service_donor' );