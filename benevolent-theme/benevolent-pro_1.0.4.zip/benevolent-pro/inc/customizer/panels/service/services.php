<?php
/**
 * Service Page Services Section Options
 *
 * @package Benevolent
 */

function benevolent_pro_customize_register_service_services( $wp_customize ) {
    
    /** Services Section */
    Kirki::add_section( 'benevolent_pro_service_services_section', array(
        'title'    => __( 'Services Section', 'benevolent-pro' ),
        'priority' => 30,
        'panel'    => 'benevolent_pro_service_page_settings',
    ) );
    
    Kirki::add_field( 'benevolent_pro', array(
        'type'     => 'text',
        'settings' => 'benevolent_pro_services_section_title',
        'label'    => __( 'Services Section Title', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_service_services_section',
        'default'  => '',
    ) );
    
    Kirki::add_field( 'benevolent_pro', array(
        'type'     => 'textarea',
        'settings' => 'benevolent_pro_services_section_content',
        'label'    => __( 'Services Section Content', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_service_services_section',
        'default'  => '',
    ) );
    
}
add_action( 'customize_register', 'benevolent_pro_customize_register_service_services' );