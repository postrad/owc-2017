<?php
/**
 * Sort Service Page Section Options
 *
 * @package Benevolent
 */

function benevolent_pro_customize_register_service_sort( $wp_customize ) {
    
    /** Sort Service Page Section */
    Kirki::add_section( 'benevolent_pro_sort_service_section', array(
        'title' => __( 'Sort Service Page Sections', 'benevolent-pro' ),
        'priority' => 70,
        'panel' => 'benevolent_pro_service_page_settings',
    ) );
    
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'sortable',
        'settings'    => 'benevolent_pro_sort_servicepage',
        'label'       => __( 'Sort Sections', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_sort_service_section',
        'default'     => array( 'intro', 'services', 'cta', 'donor' ),
        'choices'     => array(
    		'intro'    => esc_attr__( 'Intro Section', 'benevolent-pro' ),
    		'services' => esc_attr__( 'Services Section', 'benevolent-pro' ),
    		'cta'      => esc_attr__( 'CTA Section', 'benevolent-pro' ),
    		'donor'    => esc_attr__( 'Donor Section', 'benevolent-pro' ),
    	),        
    ) );
    
}
add_action( 'customize_register', 'benevolent_pro_customize_register_service_sort' );