<?php
/**
 * Service Page Intro Section Options
 *
 * @package Benevolent
 */

function benevolent_pro_customize_register_service_intro( $wp_customize ) {
    
    /** Intro Section */
    Kirki::add_section( 'benevolent_pro_service_intro_section', array(
        'title'    => __( 'Intro Section', 'benevolent-pro' ),
        'priority' => 20,
        'panel'    => 'benevolent_pro_service_page_settings',
    ) );
    
    /** Video Iframe */
    Kirki::add_field( 'benevolent_pro', array(
        'type'              => 'textarea',
        'settings'          => 'benevolent_pro_service_video_iframe',
        'label'             => __( 'Video Iframe', 'benevolent-pro' ),
        'section'           => 'benevolent_pro_service_intro_section',
        'default'           => '',
        'sanitize_callback' => 'benevolent_pro_sanitize_iframe'
    ) );
    
}
add_action( 'customize_register', 'benevolent_pro_customize_register_service_intro' );