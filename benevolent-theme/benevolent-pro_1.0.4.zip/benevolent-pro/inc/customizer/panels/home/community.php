<?php
/**
 * Home Page Community Section Options
 *
 * @package Benevolent_Pro
 */

function benevolent_pro_customize_register_home_community( $wp_customize ) {
    
    global $benevolent_pro_options_pp;
    
    /** Community Section */
    Kirki::add_section( 'benevolent_pro_community_settings', array(
        'title' => __( 'Community Section', 'benevolent-pro' ),
        'priority' => 30,
        'panel' => 'benevolent_pro_home_page_settings',
    ) );
    
    /** Community Section Title */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'text',
        'settings'    => 'benevolent_pro_community_section_title',
        'label'       => __( 'Community Section Title', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_community_settings',
        'default'     => '',
    ) );    
    
    /** Community Post One */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'select',
        'settings'    => 'benevolent_pro_community_post_one',
        'label'       => __( 'Select Post One', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_community_settings',
        'default'     => '',
        'choices'     => $benevolent_pro_options_pp
    ) );
    
    /** Community Post Two */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'select',
        'settings'    => 'benevolent_pro_community_post_two',
        'label'       => __( 'Select Post Two', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_community_settings',
        'default'     => '',
        'choices'     => $benevolent_pro_options_pp
    ) );
    
    /** Community Post Three */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'select',
        'settings'    => 'benevolent_pro_community_post_three',
        'label'       => __( 'Select Post Three', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_community_settings',
        'default'     => '',
        'choices'     => $benevolent_pro_options_pp
    ) );
    
    /** Community Post Four */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'select',
        'settings'    => 'benevolent_pro_community_post_four',
        'label'       => __( 'Select Post Four', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_community_settings',
        'default'     => '',
        'choices'     => $benevolent_pro_options_pp
    ) );
    /** Community Section Ends */
    
    /** BG Color */
    Kirki::add_field( 'benevolent_pro', array(
        'label'     => __( 'Backgrond Color ', 'benevolent-pro' ),
        'section'   => 'benevolent_pro_community_settings',
        'settings'  => 'benevolent_pro_community_bg',
        'type'      => 'color',
        'default'   => '#0f907f',
    ) );
    
}
add_action( 'customize_register', 'benevolent_pro_customize_register_home_community' );