<?php
/**
 * Sort Home Page Section Options
 *
 * @package Benevolent_Pro
 */

function benevolent_pro_customize_register_home_sort( $wp_customize ) {
    
    /** Sort Home Page Section */
    Kirki::add_section( 'benevolent_pro_sort_home_section', array(
        'title' => __( 'Sort Home Page Sections', 'benevolent-pro' ),
        'priority' => 80,
        'panel' => 'benevolent_pro_home_page_settings',
    ) );
    
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'sortable',
        'settings'    => 'benevolent_pro_sort_homepage',
        'label'       => __( 'Sort Sections', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_sort_home_section',
        'default'     => array( 'intro', 'community', 'stat', 'give', 'blog', 'sponsor', 'cta' ),
        'choices'     => array(
    		'intro'       => esc_attr__( 'Intro Section', 'benevolent-pro' ),
    		'community'   => esc_attr__( 'Community Section', 'benevolent-pro' ),
    		'stat'        => esc_attr__( 'Stat Counter Section', 'benevolent-pro' ),
    		'give'        => esc_attr__( 'Give Section', 'benevolent-pro' ),
            'blog'        => esc_attr__( 'Blog Section', 'benevolent-pro' ),
            'sponsor'     => esc_attr__( 'Sponsor Section', 'benevolent-pro' ),
            'cta'         => esc_attr__( 'CTA Section', 'benevolent-pro' ),
    	),        
    ) );
    /** Home Page Settings Ends */
    
}
add_action( 'customize_register', 'benevolent_pro_customize_register_home_sort' );