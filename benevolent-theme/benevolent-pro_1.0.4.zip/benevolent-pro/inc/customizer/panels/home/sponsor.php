<?php
/**
 * Home Page Sponsor Section Options
 *
 * @package Benevolent_Pro
 */

function benevolent_pro_customize_register_home_sponsor( $wp_customize ) {

    /* Option list of logo categories */
    $args = array(
       'orderby'                  => 'name',
       'order'                    => 'ASC',
       'hide_empty'               => 1,
       'hierarchical'             => 1,
       'taxonomy'                 => 'logo-category'
    ); 
    $option_cat = array();
    $term_lists = get_terms( $args );
    $option_cat[''] = __( 'Choose Logo Category', 'benevolent-pro' );
    foreach( $term_lists as $term ){
        $option_cat[$term->term_id] = $term->name;
    }

    /** Sponsor Section */
    Kirki::add_section( 'benevolent_pro_sponsor_settings', array(
        'title' => __( 'Sponsor Section', 'benevolent-pro' ),
        'priority' => 60,
        'panel' => 'benevolent_pro_home_page_settings',
    ) );
    
    /** Sponsor Section Title */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'text',
        'settings'    => 'benevolent_pro_sponsor_section_title',
        'label'       => __( 'Sponsor Section Title', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_sponsor_settings',
        'default'     => '',
    ) ); 
    
    /** Sponsor Section Content */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'textarea',
        'settings'    => 'benevolent_pro_sponsor_section_content',
        'label'       => __( 'Sponsor Section Content', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_sponsor_settings',
        'default'     => '',
    ) );
    
    /** Sponsor Logo Category */
    Kirki::add_field( 'benevolent_pro', array(
        'type'     => 'select',
        'settings' => 'benevolent_pro_sponsor_cat',
        'label'    => __( 'Sponsor Logo Category', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_sponsor_settings',
        'default'  => '',
        'choices'  => $option_cat 
    ) );
    /** Client Section Ends */

}
add_action( 'customize_register', 'benevolent_pro_customize_register_home_sponsor' );