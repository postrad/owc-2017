<?php
/**
 * Home Page Intro Section Options
 *
 * @package Benevolent_Pro
 */

function benevolent_pro_customize_register_home_intro( $wp_customize ) {
    
    /** Intro Section */
    Kirki::add_section( 'benevolent_pro_intro_settings', array(
        'title'    => __( 'Intro Section', 'benevolent-pro' ),
        'priority' => 20,
        'panel'    => 'benevolent_pro_home_page_settings',
    ) );
    
    /** Intro Section Title */
    Kirki::add_field( 'benevolent_pro', array(
        'type'     => 'text',
        'settings' => 'benevolent_pro_intro_section_title',
        'label'    => __( 'Intro Section Title', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_intro_settings',
        'default'  => '',
    ) );
    
    /** Intro Section Content */
    Kirki::add_field( 'benevolent_pro', array(
        'type'     => 'textarea',
        'settings' => 'benevolent_pro_intro_section_content',
        'label'    => __( 'Intro Section Content', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_intro_settings',
        'default'  => '',
    ) );
    
    /** Intro One Title */
    Kirki::add_field( 'benevolent_pro', array(
        'type'     => 'text',
        'settings' => 'benevolent_pro_intro_one_title',
        'label'    => __( 'Intro One Title', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_intro_settings',
        'default'  => '',
    ) );
    
    /** Intro One Link Label */
    Kirki::add_field( 'benevolent_pro', array(
        'type'     => 'text',
        'settings' => 'benevolent_pro_intro_one_link_label',
        'label'    => __( 'Intro One Link Label', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_intro_settings',
        'default'  => '',
    ) );
    
    /** Intro One Url */
    Kirki::add_field( 'benevolent_pro', array(
        'type'              => 'text',
        'settings'          => 'benevolent_pro_intro_one_url',
        'label'             => __( 'Intro One Link', 'benevolent-pro' ),
        'section'           => 'benevolent_pro_intro_settings',
        'default'           => '',
        'sanitize_callback' => 'esc_url_raw'
    ) );
    
    /** Upload a Logo One */
    Kirki::add_field( 'benevolent_pro', array(
        'type'     => 'cropped_image',
        'settings' => 'benevolent_pro_intro_one_logo',
        'label'    => __( 'Upload a Logo One', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_intro_settings',
        'default'  => '',
        'width'    => 85,
        'height'   => 85,
    ) );
    
    /** Upload a Image One */
    Kirki::add_field( 'benevolent_pro', array(
        'type'     => 'cropped_image',
        'settings' => 'benevolent_pro_intro_one_image',
        'label'    => __( 'Upload a Image One', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_intro_settings',
        'default'  => '',
        'width'    => 200,
        'height'   => 200,
    ) );
    
    /** Intro Two Title */
    Kirki::add_field( 'benevolent_pro', array(
        'type'     => 'text',
        'settings' => 'benevolent_pro_intro_two_title',
        'label'    => __( 'Intro Two Title', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_intro_settings',
        'default'  => '',
    ) );
    
    /** Intro Two Link Label */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'text',
        'settings'    => 'benevolent_pro_intro_two_link_label',
        'label'       => __( 'Intro Two Link Label', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_intro_settings',
        'default'     => '',
    ) );    
    
    /** Intro Two Url */
    Kirki::add_field( 'benevolent_pro', array(
        'type'              => 'text',
        'settings'          => 'benevolent_pro_intro_two_url',
        'label'             => __( 'Intro Two Link', 'benevolent-pro' ),
        'section'           => 'benevolent_pro_intro_settings',
        'default'           => '',
        'sanitize_callback' => 'esc_url_raw'
    ) );
    
    /** Upload a Logo Two */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'cropped_image',
        'settings'    => 'benevolent_pro_intro_two_logo',
        'label'       => __( 'Upload a Logo Two', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_intro_settings',
        'default'     => '',
        'width'       => 85,
        'height'      => 85,
    ) );
    
    /** Upload a Image Two */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'cropped_image',
        'settings'    => 'benevolent_pro_intro_two_image',
        'label'       => __( 'Upload a Image Two', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_intro_settings',
        'default'     => '',
        'width'       => 200,
        'height'      => 200,
    ) );
    
    /** Intro Three Title */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'text',
        'settings'    => 'benevolent_pro_intro_three_title',
        'label'       => __( 'Intro Three Title', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_intro_settings',
        'default'     => '',
    ) );
    
    /** Intro Three Link Label */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'text',
        'settings'    => 'benevolent_pro_intro_three_link_label',
        'label'       => __( 'Intro Three Link Label', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_intro_settings',
        'default'     => '',
    ) );
        
    /** Intro Three Url */
    Kirki::add_field( 'benevolent_pro', array(
        'type'              => 'text',
        'settings'          => 'benevolent_pro_intro_three_url',
        'label'             => __( 'Intro Three Link', 'benevolent-pro' ),
        'section'           => 'benevolent_pro_intro_settings',
        'default'           => '',
        'sanitize_callback' => 'esc_url_raw'
    ) );
    
    /** Upload a Logo Three */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'cropped_image',
        'settings'    => 'benevolent_pro_intro_three_logo',
        'label'       => __( 'Upload a Logo Three', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_intro_settings',
        'default'     => '',
        'width'       => 85,
        'height'      => 85,
    ) );
   
    /** Upload a Image Three */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'cropped_image',
        'settings'    => 'benevolent_pro_intro_three_image',
        'label'       => __( 'Upload a Image Three', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_intro_settings',
        'default'     => '',
        'width'       => 200,
        'height'      => 200,
    ) );    
    /** Intro Section Ends */
    
}
add_action( 'customize_register', 'benevolent_pro_customize_register_home_intro' );