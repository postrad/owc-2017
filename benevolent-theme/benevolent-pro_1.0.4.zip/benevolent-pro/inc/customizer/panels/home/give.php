<?php
/**
 * Home Page Give Section Options
 *
 * @package Benevolent_Pro
 */

function benevolent_pro_customize_register_home_give( $wp_customize ) {
    
    /** Give Section */
    Kirki::add_section( 'benevolent_pro_give_settings', array(
        'title' => __( 'Give Section', 'benevolent-pro' ),
        'priority' => 45,
        'panel' => 'benevolent_pro_home_page_settings',
    ) );
    
    /** Give Section Title */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'text',
        'settings'    => 'benevolent_pro_give_section_title',
        'label'       => __( 'Give Section Title', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_give_settings',
        'default'     => '',
    ) );
    
    /** Give Section Content */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'textarea',
        'settings'    => 'benevolent_pro_give_section_content',
        'label'       => __( 'Give Section Content', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_give_settings',
        'default'     => '',
    ) );
    
    /** Donate Button Label */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'text',
        'settings'    => 'benevolent_pro_give_button_label',
        'label'       => __( 'Donate Button Label', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_give_settings',
        'default'     => __( 'Donate Now', 'benevolent-pro' ),
    ) );
    
    /** Excerpt Character */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'slider',
        'settings'    => 'benevolent_pro_give_excerpt_char',
        'label'       => __( 'Excerpt Character', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_give_settings',
        'default'     => 200,
        'choices'   => array(
            'min'   => 50,
            'max'   => 500,
            'step'  => 10
        ),
    ) );
    
    /** BG Color */
    Kirki::add_field( 'benevolent_pro', array(
        'label'     => __( 'Backgrond Color ', 'benevolent-pro' ),
        'section'   => 'benevolent_pro_give_settings',
        'settings'  => 'benevolent_pro_give_bg',
        'type'      => 'color',
        'default'   => '#0f907f',
    ) );
    /** Give Section Ends */
}
add_action( 'customize_register', 'benevolent_pro_customize_register_home_give' );