<?php
/**
 * Home Page Blog Section Options
 *
 * @package Benevolent_Pro
 */

function benevolent_pro_customize_register_home_blog( $wp_customize ) {
    
    /** Blog Section */
    Kirki::add_section( 'benevolent_pro_blog_settings', array(
        'title' => __( 'Blog Section', 'benevolent-pro' ),
        'priority' => 50,
        'panel' => 'benevolent_pro_home_page_settings',
    ) );
    
    /** Show/Hide Blog Date */
    Kirki::add_field( 'benevolent_pro', array(
        'type'     => 'toggle',
        'settings' => 'benevolent_pro_ed_blog_date',
        'label'    => __( 'Show Blog Date', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_blog_settings',
        'default'  => '',
    ) );
    
    /** Blog Section Title */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'text',
        'settings'    => 'benevolent_pro_blog_section_title',
        'label'       => __( 'Blog Section Title', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_blog_settings',
        'default'     => '',
    ) );
    
    /** Blog Section Content */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'textarea',
        'settings'    => 'benevolent_pro_blog_section_content',
        'label'       => __( 'Blog Section Content', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_blog_settings',
        'default'     => '',
    ) );
    
    /** Blog Section Read More Text */
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'text',
        'settings'    => 'benevolent_pro_blog_section_readmore',
        'label'       => __( 'Blog Section Read More Text', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_blog_settings',
        'default'     => __( 'Read More', 'benevolent-pro' ),
    ) );    
    /** Blog Section Ends */
    
}
add_action( 'customize_register', 'benevolent_pro_customize_register_home_blog' );