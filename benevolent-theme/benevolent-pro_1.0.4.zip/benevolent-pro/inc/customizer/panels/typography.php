<?php
/**
 * Typography Options 
 *
 * @package Benevolent
 */

function benevolent_pro_customize_register_typography( $wp_customize ) {
    
    Kirki::add_panel( 'benevolent_pro_typography_section', array(
        'title'          => __( 'Typography Settings', 'benevolent-pro' ),
        'priority'       => 33,
        'capability'     => 'edit_theme_options',
    ) );
    
}
add_action( 'customize_register', 'benevolent_pro_customize_register_typography' );