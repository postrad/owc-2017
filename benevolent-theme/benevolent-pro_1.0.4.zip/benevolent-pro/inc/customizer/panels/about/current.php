<?php
/**
 * About Page Current Project Section Options
 *
 * @package Benevolent
 */
 
function benevolent_pro_customize_register_about_current( $wp_customize ) {
    
    global $benevolent_pro_options_posts;
    
    /** Current Project Section */
    Kirki::add_section( 'benevolent_pro_about_current_project_section', array(
        'title'    => __( 'Current Project Section', 'benevolent-pro' ),
        'priority' => 70,
        'panel'    => 'benevolent_pro_about_page_settings',
    ) );
    
    Kirki::add_field( 'benevolent_pro', array(
        'type'     => 'text',
        'settings' => 'benevolent_pro_current_project_section_title',
        'label'    => __( 'Current Project Section Title', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_about_current_project_section',
        'default'  => '',
    ) );
    
    Kirki::add_field( 'benevolent_pro', array(
        'type'     => 'select',
        'settings' => 'benevolent_pro_current_project_one',
        'label'    => __( 'Select Post One', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_about_current_project_section',
        'default'  => '',
        'choices'  => $benevolent_pro_options_posts
    ) );
    
    Kirki::add_field( 'benevolent_pro', array(
        'type'     => 'select',
        'settings' => 'benevolent_pro_current_project_two',
        'label'    => __( 'Select Post Two', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_about_current_project_section',
        'default'  => '',
        'choices'  => $benevolent_pro_options_posts
    ) );
    
    Kirki::add_field( 'benevolent_pro', array(
        'type'     => 'select',
        'settings' => 'benevolent_pro_current_project_three',
        'label'    => __( 'Select Post Three', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_about_current_project_section',
        'default'  => '',
        'choices'  => $benevolent_pro_options_posts
    ) );
    
}
add_action( 'customize_register', 'benevolent_pro_customize_register_about_current' );