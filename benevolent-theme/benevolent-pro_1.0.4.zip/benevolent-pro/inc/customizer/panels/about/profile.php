<?php
/**
 * About Page Profile Section Options
 *
 * @package Benevolent
 */
 
function benevolent_pro_customize_register_about_profile( $wp_customize ) {
    
    /** Profile Section */
    Kirki::add_section( 'benevolent_pro_profile_section', array(
        'title'    => __( 'Profile Section', 'benevolent-pro' ),
        'priority' => 30,
        'panel'    => 'benevolent_pro_about_page_settings',
    ) );
    
    Kirki::add_field( 'benevolent_pro', array(
        'type'     => 'text',
        'settings' => 'benevolent_pro_profile_section_title',
        'label'    => __( 'Profile Section Title', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_profile_section',
        'default'  => '',
    ) );
    
    Kirki::add_field( 'benevolent_pro', array(
        'type'     => 'textarea',
        'settings' => 'benevolent_pro_profile_section_content',
        'label'    => __( 'Profile Section Content', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_profile_section',
        'default'  => '',
    ) );
    
}
add_action( 'customize_register', 'benevolent_pro_customize_register_about_profile' );