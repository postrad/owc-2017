<?php
/**
 * About Page We Believe Section Options
 *
 * @package Benevolent
 */
 
function benevolent_pro_customize_register_about_believe( $wp_customize ) {
    
    /** We Believe Section */
    Kirki::add_section( 'benevolent_pro_about_believe_section', array(
        'title'    => __( 'We Believe Section', 'benevolent-pro' ),
        'priority' => 60,
        'panel'    => 'benevolent_pro_about_page_settings',
    ) );
    
    Kirki::add_field( 'benevolent_pro', array(
        'type'     => 'text',
        'settings' => 'benevolent_pro_believe_section_title',
        'label'    => __( 'We Believe Section Title', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_about_believe_section',
        'default'  => '',
    ) );
    
    Kirki::add_field( 'benevolent_pro', array(
        'type'     => 'editor',
        'settings' => 'benevolent_pro_believe_section_content',
        'label'    => __( 'We Believe Section content', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_about_believe_section',
        'default'  => '',
    ) );
    
}
add_action( 'customize_register', 'benevolent_pro_customize_register_about_believe' );