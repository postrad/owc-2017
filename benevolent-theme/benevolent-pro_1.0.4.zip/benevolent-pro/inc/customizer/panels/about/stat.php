<?php
/**
 * About Page Stat Counter Section Options
 *
 * @package Benevolent
 */
 
function benevolent_pro_customize_register_about_stat( $wp_customize ) {
    
    /** Stat Counter Section */
    Kirki::add_section( 'benevolent_pro_about_stat_counter_section', array(
        'title'    => __( 'Stat Counter Section', 'benevolent-pro' ),
        'priority' => 50,
        'panel'    => 'benevolent_pro_about_page_settings',
    ) );
    
    Kirki::add_field( 'benevolent_pro', array(
        'type'     => 'image',
        'settings' => 'benevolent_pro_about_stat_counter_bg',
        'label'    => __( 'Background Image', 'benevolent-pro' ),
        'section'  => 'benevolent_pro_about_stat_counter_section',
        'default'  => '',
    ) );
    
}
add_action( 'customize_register', 'benevolent_pro_customize_register_about_stat' );