<?php
/**
 * Sort About Page Section Options
 *
 * @package Benevolent
 */
 
function benevolent_pro_customize_register_about_sort( $wp_customize ) {
    
    /** Sort About Page Section */
    Kirki::add_section( 'benevolent_pro_sort_about_section', array(
        'title' => __( 'Sort About Page Sections', 'benevolent-pro' ),
        'priority' => 80,
        'panel' => 'benevolent_pro_about_page_settings',
    ) );
    
    Kirki::add_field( 'benevolent_pro', array(
        'type'        => 'sortable',
        'settings'    => 'benevolent_pro_sort_aboutpage',
        'label'       => __( 'Sort Sections', 'benevolent-pro' ),
        'section'     => 'benevolent_pro_sort_about_section',
        'default'     => array( 'intro', 'profile', 'stat', 'believe', 'current' ),
        'choices'     => array(
    		'intro'   => esc_attr__( 'Intro Section', 'benevolent-pro' ),
    		'profile' => esc_attr__( 'Profile Section', 'benevolent-pro' ),
    		'stat'    => esc_attr__( 'Stat Counter Section', 'benevolent-pro' ),
    		'believe' => esc_attr__( 'We Believe Section', 'benevolent-pro' ),
            'current' => esc_attr__( 'Current Project Section', 'benevolent-pro' ),
    	),        
    ) );
    
}
add_action( 'customize_register', 'benevolent_pro_customize_register_about_sort' );