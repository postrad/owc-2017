<?php
/**
 * Sanitization Functions
 *
 * @package Benevolent
 */

function benevolent_pro_sanitize_email( $email ){
    
	$email = sanitize_email( $email );    	
	
    // If $email is a valid email, return it; otherwise, return the default.	
    return ( !empty( $email ) ? $email : '' );    
}

function benevolent_pro_sanitize_iframe( $iframe ){
    $allow_tag = array(
                    'iframe'=>array(
                        'src'=>array(),
                        'width'=>array(),
                        'height'=>array()
                    )
                );
    return wp_kses( $iframe, $allow_tag );
}

/**
 * Sanitize funtion for link in repeater field
*/
function benevolent_pro_sanitize_customizer( $value ) {

    if ( !is_array( $value ) ) {
        $value = array();
    }
    
    if( ! empty( $value['benevolent_pro_slider_slides'] ) ){
        /** For slider url */
        foreach ( $value['benevolent_pro_slider_slides'] as $key => $subvalue ) {
    
            if ( isset( $value['benevolent_pro_slider_slides'][ $key ]['link'] ) ) {
                $value['benevolent_pro_slider_slides'][ $key ]['link'] = esc_url_raw( $value['benevolent_pro_slider_slides'][ $key ]['link'] );
            }
    
        }
    }
    
    if( ! empty( $value['benevolent_pro_social'] ) ){ 
        /** For Social links */
        foreach ( $value['benevolent_pro_social'] as $key => $subvalue ) {
    
            if ( isset( $value['benevolent_pro_social'][ $key ]['link'] ) ) {
                $value['benevolent_pro_social'][ $key ]['link'] = esc_url_raw( $value['benevolent_pro_social'][ $key ]['link'] );
            }
    
        }
    }
    
    if( ! empty( $value['benevolent_pro_sidebar'] ) ){
        /** For sidebar id */
        foreach ( $value['benevolent_pro_sidebar'] as $key => $subvalue ) {
    
            if ( isset( $value['benevolent_pro_sidebar'][ $key ]['id'] ) ) {
                $value['benevolent_pro_sidebar'][ $key ]['id'] = sanitize_title( $value['benevolent_pro_sidebar'][ $key ]['id'] );
            }
    
        }
    }

    return $value;

}
add_action( 'sanitize_option_theme_mods_benevolent-pro', 'benevolent_pro_sanitize_customizer' );