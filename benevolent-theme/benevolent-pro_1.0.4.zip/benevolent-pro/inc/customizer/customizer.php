<?php
/**
 * Benevolent Pro Theme Customizer.
 *
 * @package Benevolent_Pro
 */

/* Option list of all post */	
$benevolent_pro_options_posts = array();
$benevolent_pro_options_posts_obj = get_posts( 'posts_per_page=-1' );
$benevolent_pro_options_posts[''] = __( 'Choose Post', 'benevolent-pro' );
foreach ( $benevolent_pro_options_posts_obj as $benevolent_pro_posts ) {
	$benevolent_pro_options_posts[$benevolent_pro_posts->ID] = $benevolent_pro_posts->post_title;
}

$args = array( 'post_type' => array( 'post', 'page' ), 'posts_per_page' => -1 );
$benevolent_pro_options_pp = array();
$benevolent_pro_options_pp_obj = get_posts( $args );
$benevolent_pro_options_pp[''] = __( 'Choose Post/Page', 'benevolent-pro' );
foreach ( $benevolent_pro_options_pp_obj as $benevolent_pro_pp ) {
	$benevolent_pro_options_pp[$benevolent_pro_pp->ID] = $benevolent_pro_pp->post_title;
}

/* Option list of all categories */
$benevolent_pro_args = array(
   'type'                     => 'post',
   'orderby'                  => 'name',
   'order'                    => 'ASC',
   'hide_empty'               => 1,
   'hierarchical'             => 1,
   'taxonomy'                 => 'category'
); 
$benevolent_pro_option_categories = array();
$benevolent_pro_category_lists = get_categories( $benevolent_pro_args );
$benevolent_pro_option_categories[''] = __( 'Choose Category', 'benevolent-pro' );
foreach( $benevolent_pro_category_lists as $benevolent_pro_category ){
    $benevolent_pro_option_categories[$benevolent_pro_category->term_id] = $benevolent_pro_category->name;
}
    
$benevolent_pro_panels   = array( 'header', 'slider', 'home', 'about', 'service', 'typography', 'custom' );
$benevolent_pro_sections = array( 'demo', 'general', 'google', 'blog', 'post-page', 'post-meta', 'breadcrumb', 'styling', 'sidebar', 'social', 'custom', 'footer' );

if( is_give_activated() ){
    $benevolent_pro_home_arr = array( 'intro', 'community', 'give', 'blog', 'sponsor', 'sort' );
}else{
    $benevolent_pro_home_arr = array( 'intro', 'community', 'blog', 'sponsor', 'sort' );    
}


$benevolent_pro_sub_section = array(
    'header'     => array( 'layout', 'misc' ),
    'slider'     => array( 'options', 'content' ),
    'home'       => $benevolent_pro_home_arr,
    'about'      => array( 'intro', 'profile', 'stat', 'believe', 'current', 'sort' ),
    'service'    => array( 'intro', 'services', 'donor', 'sort' ),
    'typography' => array( 'body', 'home', 'page', 'post', 'widget', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6' ),
);

foreach( $benevolent_pro_panels as $p ){
    require get_template_directory() . '/inc/customizer/panels/' . $p . '.php';
}

foreach( $benevolent_pro_sections as $s ){
    require get_template_directory() . '/inc/customizer/sections/' . $s . '.php';
}

foreach( $benevolent_pro_sub_section as $k => $v ){
    foreach( $v as $w ){        
        require get_template_directory() . '/inc/customizer/panels/' . $k . '/' . $w . '.php';
    }
}

/**
 * Sanitization Functions
*/
require get_template_directory() . '/inc/customizer/sanitization-functions.php';

/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
function benevolent_pro_customize_preview_js() {
	wp_enqueue_script( 'benevolent_pro_customizer', get_template_directory_uri() . '/js/customizer.js', array( 'customize-preview' ), '20130508', true );
}
add_action( 'customize_preview_init', 'benevolent_pro_customize_preview_js' );

/**
 * Configuration sample for the Kirki Customizer
 */
function benevolent_pro_configuration_sample_styling( $config ) {

    //$config['logo_image']   = get_template_directory_uri() . '/images/logo.png';
    $config['description']  = __( 'Benevolent Pro : A Pro theme of Benevolent.', 'benevolent-pro');
    $config['color_accent'] = '#0F907F';
    $config['color_back']   = '#EFEFEF';
    $config['disable_loader'] = true;

    return $config;

}
add_filter( 'kirki/config', 'benevolent_pro_configuration_sample_styling' );

/**
 * If you need to include Kirki in your theme,
 * then you may want to consider adding the translations here
 * using your textdomain.
 * 
 * If you're using Kirki as a plugin this is not needed.
 */
add_filter( 'kirki/my_config/l10n', function( $l10n ) {

	$l10n['background-color']      = esc_attr__( 'Background Color', 'benevolent-pro' );
	$l10n['background-image']      = esc_attr__( 'Background Image', 'benevolent-pro' );
	$l10n['no-repeat']             = esc_attr__( 'No Repeat', 'benevolent-pro' );
	$l10n['repeat-all']            = esc_attr__( 'Repeat All', 'benevolent-pro' );
	$l10n['repeat-x']              = esc_attr__( 'Repeat Horizontally', 'benevolent-pro' );
	$l10n['repeat-y']              = esc_attr__( 'Repeat Vertically', 'benevolent-pro' );
	$l10n['inherit']               = esc_attr__( 'Inherit', 'benevolent-pro' );
	$l10n['background-repeat']     = esc_attr__( 'Background Repeat', 'benevolent-pro' );
	$l10n['cover']                 = esc_attr__( 'Cover', 'benevolent-pro' );
	$l10n['contain']               = esc_attr__( 'Contain', 'benevolent-pro' );
	$l10n['background-size']       = esc_attr__( 'Background Size', 'benevolent-pro' );
	$l10n['fixed']                 = esc_attr__( 'Fixed', 'benevolent-pro' );
	$l10n['scroll']                = esc_attr__( 'Scroll', 'benevolent-pro' );
	$l10n['background-attachment'] = esc_attr__( 'Background Attachment', 'benevolent-pro' );
	$l10n['left-top']              = esc_attr__( 'Left Top', 'benevolent-pro' );
	$l10n['left-center']           = esc_attr__( 'Left Center', 'benevolent-pro' );
	$l10n['left-bottom']           = esc_attr__( 'Left Bottom', 'benevolent-pro' );
	$l10n['right-top']             = esc_attr__( 'Right Top', 'benevolent-pro' );
	$l10n['right-center']          = esc_attr__( 'Right Center', 'benevolent-pro' );
	$l10n['right-bottom']          = esc_attr__( 'Right Bottom', 'benevolent-pro' );
	$l10n['center-top']            = esc_attr__( 'Center Top', 'benevolent-pro' );
	$l10n['center-center']         = esc_attr__( 'Center Center', 'benevolent-pro' );
	$l10n['center-bottom']         = esc_attr__( 'Center Bottom', 'benevolent-pro' );
	$l10n['background-position']   = esc_attr__( 'Background Position', 'benevolent-pro' );
	$l10n['background-opacity']    = esc_attr__( 'Background Opacity', 'benevolent-pro' );
	$l10n['on']                    = esc_attr__( 'ON', 'benevolent-pro' );
	$l10n['off']                   = esc_attr__( 'OFF', 'benevolent-pro' );
	$l10n['all']                   = esc_attr__( 'All', 'benevolent-pro' );
	$l10n['cyrillic']              = esc_attr__( 'Cyrillic', 'benevolent-pro' );
	$l10n['cyrillic-ext']          = esc_attr__( 'Cyrillic Extended', 'benevolent-pro' );
	$l10n['devanagari']            = esc_attr__( 'Devanagari', 'benevolent-pro' );
	$l10n['greek']                 = esc_attr__( 'Greek', 'benevolent-pro' );
	$l10n['greek-ext']             = esc_attr__( 'Greek Extended', 'benevolent-pro' );
	$l10n['khmer']                 = esc_attr__( 'Khmer', 'benevolent-pro' );
	$l10n['latin']                 = esc_attr__( 'Latin', 'benevolent-pro' );
	$l10n['latin-ext']             = esc_attr__( 'Latin Extended', 'benevolent-pro' );
	$l10n['vietnamese']            = esc_attr__( 'Vietnamese', 'benevolent-pro' );
	$l10n['hebrew']                = esc_attr__( 'Hebrew', 'benevolent-pro' );
	$l10n['arabic']                = esc_attr__( 'Arabic', 'benevolent-pro' );
	$l10n['bengali']               = esc_attr__( 'Bengali', 'benevolent-pro' );
	$l10n['gujarati']              = esc_attr__( 'Gujarati', 'benevolent-pro' );
	$l10n['tamil']                 = esc_attr__( 'Tamil', 'benevolent-pro' );
	$l10n['telugu']                = esc_attr__( 'Telugu', 'benevolent-pro' );
	$l10n['thai']                  = esc_attr__( 'Thai', 'benevolent-pro' );
	$l10n['serif']                 = _x( 'Serif', 'font style', 'benevolent-pro' );
	$l10n['sans-serif']            = _x( 'Sans Serif', 'font style', 'benevolent-pro' );
	$l10n['monospace']             = _x( 'Monospace', 'font style', 'benevolent-pro' );
	$l10n['font-family']           = esc_attr__( 'Font Family', 'benevolent-pro' );
	$l10n['font-size']             = esc_attr__( 'Font Size', 'benevolent-pro' );
	$l10n['font-weight']           = esc_attr__( 'Font Weight', 'benevolent-pro' );
	$l10n['line-height']           = esc_attr__( 'Line Height', 'benevolent-pro' );
	$l10n['font-style']            = esc_attr__( 'Font Style', 'benevolent-pro' );
	$l10n['letter-spacing']        = esc_attr__( 'Letter Spacing', 'benevolent-pro' );
	$l10n['top']                   = esc_attr__( 'Top', 'benevolent-pro' );
	$l10n['bottom']                = esc_attr__( 'Bottom', 'benevolent-pro' );
	$l10n['left']                  = esc_attr__( 'Left', 'benevolent-pro' );
	$l10n['right']                 = esc_attr__( 'Right', 'benevolent-pro' );
	$l10n['color']                 = esc_attr__( 'Color', 'benevolent-pro' );
	$l10n['add-image']             = esc_attr__( 'Add Image', 'benevolent-pro' );
	$l10n['change-image']          = esc_attr__( 'Change Image', 'benevolent-pro' );
	$l10n['remove']                = esc_attr__( 'Remove', 'benevolent-pro' );
	$l10n['no-image-selected']     = esc_attr__( 'No Image Selected', 'benevolent-pro' );
	$l10n['select-font-family']    = esc_attr__( 'Select a font-family', 'benevolent-pro' );
	$l10n['variant']               = esc_attr__( 'Variant', 'benevolent-pro' );
	$l10n['subsets']               = esc_attr__( 'Subset', 'benevolent-pro' );
	$l10n['size']                  = esc_attr__( 'Size', 'benevolent-pro' );
	$l10n['height']                = esc_attr__( 'Height', 'benevolent-pro' );
	$l10n['spacing']               = esc_attr__( 'Spacing', 'benevolent-pro' );
	$l10n['ultra-light']           = esc_attr__( 'Ultra-Light 100', 'benevolent-pro' );
	$l10n['ultra-light-italic']    = esc_attr__( 'Ultra-Light 100 Italic', 'benevolent-pro' );
	$l10n['light']                 = esc_attr__( 'Light 200', 'benevolent-pro' );
	$l10n['light-italic']          = esc_attr__( 'Light 200 Italic', 'benevolent-pro' );
	$l10n['book']                  = esc_attr__( 'Book 300', 'benevolent-pro' );
	$l10n['book-italic']           = esc_attr__( 'Book 300 Italic', 'benevolent-pro' );
	$l10n['regular']               = esc_attr__( 'Normal 400', 'benevolent-pro' );
	$l10n['italic']                = esc_attr__( 'Normal 400 Italic', 'benevolent-pro' );
	$l10n['medium']                = esc_attr__( 'Medium 500', 'benevolent-pro' );
	$l10n['medium-italic']         = esc_attr__( 'Medium 500 Italic', 'benevolent-pro' );
	$l10n['semi-bold']             = esc_attr__( 'Semi-Bold 600', 'benevolent-pro' );
	$l10n['semi-bold-italic']      = esc_attr__( 'Semi-Bold 600 Italic', 'benevolent-pro' );
	$l10n['bold']                  = esc_attr__( 'Bold 700', 'benevolent-pro' );
	$l10n['bold-italic']           = esc_attr__( 'Bold 700 Italic', 'benevolent-pro' );
	$l10n['extra-bold']            = esc_attr__( 'Extra-Bold 800', 'benevolent-pro' );
	$l10n['extra-bold-italic']     = esc_attr__( 'Extra-Bold 800 Italic', 'benevolent-pro' );
	$l10n['ultra-bold']            = esc_attr__( 'Ultra-Bold 900', 'benevolent-pro' );
	$l10n['ultra-bold-italic']     = esc_attr__( 'Ultra-Bold 900 Italic', 'benevolent-pro' );
	$l10n['invalid-value']         = esc_attr__( 'Invalid Value', 'benevolent-pro' );

	return $l10n;

} );

/**
 * Change the URL that will be used by Kirki
 * to load its assets in the customizer.
 */
if ( ! function_exists( 'benevolent_pro_kirki_update_url' ) ) {
    function benevolent_pro_kirki_update_url( $config ) {
        $config['url_path'] = get_template_directory_uri() . '/inc/kirki/';
        return $config;
    }
}
add_filter( 'kirki/config', 'benevolent_pro_kirki_update_url' );