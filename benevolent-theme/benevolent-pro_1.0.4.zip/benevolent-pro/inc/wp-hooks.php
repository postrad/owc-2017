<?php
/**
 * Benevolent WordPress Hooks
 *
 * @package Benevolent_Pro 
 */

if( get_theme_mod( 'benevolent_pro_ed_adminbar' ) ) add_filter( 'show_admin_bar', '__return_false' );

/**
 * 
 * @see benevolent_pro_setup
 * @see benevolent_pro_content_width
*/
add_action( 'after_setup_theme', 'benevolent_pro_setup' );
add_action( 'after_setup_theme', 'benevolent_pro_content_width', 0 );
add_action( 'after_setup_theme', 'benevolent_pro_theme_updater' );

/**
 * Enqueue Scripts
 * 
 * @see benevolent_pro_scripts
*/
add_action( 'wp_enqueue_scripts', 'benevolent_pro_scripts' );

/**
 * Enqueue Google Fonts 
 * @see benevolent_pro_scripts_styles
*/
add_action( 'wp_enqueue_scripts', 'benevolent_pro_scripts_styles' );

/**
 * Enqueue Admin Scripts
 * 
 * @see benevolent_pro_admin_scripts
*/
add_action( 'admin_enqueue_scripts', 'benevolent_pro_admin_scripts' );

/**
 * Enqueue Customizer Control Script for displaying widget in respective panels
 * @see benevolent_pro_customizer_js
*/
add_action( 'customize_controls_enqueue_scripts', 'benevolent_pro_customizer_js' );

/**
 * Body Classes
 * 
 * @see benevolent_pro_body_classes
*/
add_filter( 'body_class', 'benevolent_pro_body_classes' );

/**
 * Add Post Class
 * @see benevolent_pro_post_classes
*/
add_filter( 'post_class', 'benevolent_pro_post_classes' );

/**
 * @see benevolent_pro_category_transient_flusher
*/
add_action( 'edit_category', 'benevolent_pro_category_transient_flusher' );
add_action( 'save_post',     'benevolent_pro_category_transient_flusher' );

/**
 * Move comment field to the bottom
 * 
 * @see benevolent_pro_move_comment_field_to_bottom
*/
add_filter( 'comment_form_fields', 'benevolent_pro_move_comment_field_to_bottom' );

/**
 * Dynamic CSS
 * @see benevolent_pro_dynamic_css
*/
add_action( 'wp_head', 'benevolent_pro_dynamic_css', 100 );

/**
 * Custom JS
 * @see benevolent_pro_custom_js
*/
add_action( 'wp_footer', 'benevolent_pro_custom_js' );

/**
 * Excerpt More and length
 * 
 * @see benevolent_pro_excerpt_more
 * @see benevolent_pro_excerpt_length
*/
add_filter( 'excerpt_more', 'benevolent_pro_excerpt_more' );
add_filter( 'excerpt_length', 'benevolent_pro_excerpt_length', 999 );

/**
 * Remove default thumbnail and add custom thumbnail meta box.
 * 
 * @see benevolent_pro_logo_metabox
 */
add_action( 'do_meta_boxes', 'benevolent_pro_logo_metabox' );

/**
 * Add excerpt field in pages
 * @see benevolent_pro_excerpts_in_pages
*/
add_action( 'init', 'benevolent_pro_excerpts_in_pages' );

/**
 * Gooble Map for contact page templates
 * @see benevolent_pro_google_map
*/
add_action( 'wp_head', 'benevolent_pro_google_map' );

/**
 * Donate Button Link
 * @see benevolent_pro_donate_button_link - 10
*/
add_filter( 'wp_nav_menu_items', 'benevolent_pro_donate_button_link', 10, 2 );

/**
 * Ajax Search
 * @see benevolent_pro_ajax_search
*/
if( get_theme_mod( 'benevolent_pro_ed_ajax_search' ) ) {
    add_action( 'wp_ajax_benevolent_pro_search', 'benevolent_pro_ajax_search' );
    add_action( 'wp_ajax_nopriv_benevolent_pro_search', 'benevolent_pro_ajax_search' );
}

/**
 * Excluding post from blog of specific categories
 * 
 * @see benevolent_pro_exclude_cat
 * @see benevolent_pro_custom_category_widget
 * @see benevolent_pro_exclude_posts_from_recentPostWidget_by_cat
 */
add_filter( 'pre_get_posts', 'benevolent_pro_exclude_cat' );

add_filter( "widget_categories_args", "benevolent_pro_custom_category_widget" );

add_filter( "widget_categories_dropdown_args", "benevolent_pro_custom_category_widget" );

add_filter( "widget_posts_args", "benevolent_pro_exclude_posts_from_recentPostWidget_by_cat" );

/**
 * To allow Skype in Html attributes
 * @see benevolent_pro_allowed_social_protocols 
 */
add_filter( 'kses_allowed_protocols' , 'benevolent_pro_allowed_social_protocols' );

/** Remove issues with prefetching adding extra views */
remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head', 10, 0);

/** Enable shortcodes in text widgets */
add_filter( 'widget_text', 'do_shortcode' );