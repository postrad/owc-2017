<?php
/**
 * Benevolent Template Hooks.
 *
 * @package Benevolent_Pro 
 */

/**
 * Doctype
 * 
 * @see benevolent_pro_doctype_cb
*/
add_action( 'benevolent_pro_doctype', 'benevolent_pro_doctype_cb' );

/**
 * Before wp_head
 * 
 * @see benevolent_pro_head
*/
add_action( 'benevolent_pro_before_wp_head', 'benevolent_pro_head' );

/**
 * Before Header
 * 
 * @see benevolent_pro_fb_page_box - 15
 * @see benevolent_pro_page_start  - 20
*/
add_action( 'benevolent_pro_before_header', 'benevolent_pro_fb_page_box', 15 );
add_action( 'benevolent_pro_before_header', 'benevolent_pro_page_start', 20 );

/**
 * Header
 * 
 * @see benevolent_pro_dynamic_header  - 20
*/
add_action( 'benevolent_pro_header', 'benevolent_pro_dynamic_header', 20 );

/**
 * After Header
 * 
 * @see benevolent_pro_slider - 20 
*/
add_action( 'benevolent_pro_after_header', 'benevolent_pro_slider', 20 );

/**
 * Before Content
 * 
 * @see benevolent_pro_breadcrumb - 20
*/
add_action( 'benevolent_pro_before_content', 'benevolent_pro_breadcrumb', 20 );

/**
 * Content
 * 
 * @see benevolent_pro_content_start
*/
add_action( 'benevolent_pro_content', 'benevolent_pro_content_start' );

/** CONTENT HOOK GOES HERE */

/**
 * After Content
 * 
 * @see benevolent_pro_content_end - 20
*/
add_action( 'benevolent_pro_after_content', 'benevolent_pro_content_end', 20 );

/**
 * Footer
 * 
 * @see benevolent_pro_footer_start  - 20
 * @see benevolent_pro_footer_top    - 30
 * @see benevolent_pro_footer_credit - 40
 * @see benevolent_pro_footer_end    - 50
*/
add_action( 'benevolent_pro_footer', 'benevolent_pro_footer_start', 20 );
add_action( 'benevolent_pro_footer', 'benevolent_pro_footer_top', 30 );
add_action( 'benevolent_pro_footer', 'benevolent_pro_footer_credit', 40 );
add_action( 'benevolent_pro_footer', 'benevolent_pro_footer_end', 50 );

/**
 * After Footer
 * 
 * @see benevolent_pro_back_to_top - 15
 * @see benevolent_pro_page_end    - 20
*/
add_action( 'benevolent_pro_after_footer', 'benevolent_pro_back_to_top', 15 );
add_action( 'benevolent_pro_after_footer', 'benevolent_pro_page_end', 20 );