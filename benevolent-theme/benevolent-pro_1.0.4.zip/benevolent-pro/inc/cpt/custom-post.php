<?php
/**
 * Rara Theme custom post and taxonomy definitions.
 *
 * @link https://codex.wordpress.org/Function_Reference/register_post_type
 * @link https://codex.wordpress.org/Function_Reference/register_taxonomy
 *
 * @package Rara_Theme
 */
 
if ( ! function_exists('benevolent_pro_logo_post_type') ) {

    // Register Custom Post Type
    function benevolent_pro_logo_post_type() {
    
    	$labels = array(
    		'name'                  => _x( 'Logos', 'Post Type General Name', 'benevolent-pro' ),
    		'singular_name'         => _x( 'Logo', 'Post Type Singular Name', 'benevolent-pro' ),
    		'menu_name'             => __( 'Logos', 'benevolent-pro' ),
    		'name_admin_bar'        => __( 'Logo', 'benevolent-pro' ),
    		'archives'              => __( 'Logo Archives', 'benevolent-pro' ),
    		'attributes'            => __( 'Logo Attributes', 'benevolent-pro' ),
    		'parent_item_colon'     => __( 'Parent Logo:', 'benevolent-pro' ),
    		'all_items'             => __( 'All Logos', 'benevolent-pro' ),
    		'add_new_item'          => __( 'Add New Logo', 'benevolent-pro' ),
    		'add_new'               => __( 'Add New', 'benevolent-pro' ),
    		'new_item'              => __( 'New Logo', 'benevolent-pro' ),
    		'edit_item'             => __( 'Edit Logo', 'benevolent-pro' ),
    		'update_item'           => __( 'Update Logo', 'benevolent-pro' ),
    		'view_item'             => __( 'View Logo', 'benevolent-pro' ),
    		'view_items'            => __( 'View Logos', 'benevolent-pro' ),
    		'search_items'          => __( 'Search Logo', 'benevolent-pro' ),
    		'not_found'             => __( 'Not found', 'benevolent-pro' ),
    		'not_found_in_trash'    => __( 'Not found in Trash', 'benevolent-pro' ),
    		'featured_image'        => __( 'Featured Image', 'benevolent-pro' ),
    		'set_featured_image'    => __( 'Set featured image', 'benevolent-pro' ),
    		'remove_featured_image' => __( 'Remove featured image', 'benevolent-pro' ),
    		'use_featured_image'    => __( 'Use as featured image', 'benevolent-pro' ),
    		'insert_into_item'      => __( 'Insert into logo', 'benevolent-pro' ),
    		'uploaded_to_this_item' => __( 'Uploaded to this logo', 'benevolent-pro' ),
    		'items_list'            => __( 'Logos list', 'benevolent-pro' ),
    		'items_list_navigation' => __( 'Logos list navigation', 'benevolent-pro' ),
    		'filter_items_list'     => __( 'Filter logos list', 'benevolent-pro' ),
    	);
    	$args = array(
    		'label'                 => __( 'Logo', 'benevolent-pro' ),
    		'description'           => __( 'A custom post type for client logos.', 'benevolent-pro' ),
    		'labels'                => $labels,
    		'supports'              => array( 'title', 'thumbnail', ),
    		'hierarchical'          => false,
    		'public'                => true,
    		'show_ui'               => true,
    		'show_in_menu'          => true,
    		'menu_position'         => 5,
    		'menu_icon'             => 'dashicons-images-alt2',
    		'show_in_admin_bar'     => true,
    		'show_in_nav_menus'     => false,
    		'can_export'            => true,
    		'has_archive'           => false,		
    		'exclude_from_search'   => true,
    		'publicly_queryable'    => true,
    		'capability_type'       => 'post',
    	);
    	register_post_type( 'logo', $args );
    
    }
    add_action( 'init', 'benevolent_pro_logo_post_type', 0 );

}

if ( ! function_exists( 'benevolent_pro_logo_taxonomy' ) ) {

    // Register Custom Taxonomy
    function benevolent_pro_logo_taxonomy() {
    
    	$labels = array(
    		'name'                       => _x( 'Logo Categories', 'Taxonomy General Name', 'benevolent-pro' ),
    		'singular_name'              => _x( 'Logo Category', 'Taxonomy Singular Name', 'benevolent-pro' ),
    		'menu_name'                  => __( 'Logo Category', 'benevolent-pro' ),
    		'all_items'                  => __( 'All Logo Categories', 'benevolent-pro' ),
    		'parent_item'                => __( 'Parent Logo Category', 'benevolent-pro' ),
    		'parent_item_colon'          => __( 'Parent Logo Category:', 'benevolent-pro' ),
    		'new_item_name'              => __( 'New Logo Category Name', 'benevolent-pro' ),
    		'add_new_item'               => __( 'Add New Logo Category', 'benevolent-pro' ),
    		'edit_item'                  => __( 'Edit Logo Category', 'benevolent-pro' ),
    		'update_item'                => __( 'Update Logo Category', 'benevolent-pro' ),
    		'view_item'                  => __( 'View Logo Category', 'benevolent-pro' ),
    		'separate_items_with_commas' => __( 'Separate logo categories with commas', 'benevolent-pro' ),
    		'add_or_remove_items'        => __( 'Add or remove logo categories', 'benevolent-pro' ),
    		'choose_from_most_used'      => __( 'Choose from the most used', 'benevolent-pro' ),
    		'popular_items'              => __( 'Popular Logo Categories', 'benevolent-pro' ),
    		'search_items'               => __( 'Search Logo Categories', 'benevolent-pro' ),
    		'not_found'                  => __( 'Not Found', 'benevolent-pro' ),
    		'no_terms'                   => __( 'No logo lategories', 'benevolent-pro' ),
    		'items_list'                 => __( 'Logo Categories list', 'benevolent-pro' ),
    		'items_list_navigation'      => __( 'Logo Categories list navigation', 'benevolent-pro' ),
    	);
    	$args = array(
    		'labels'                     => $labels,
    		'hierarchical'               => true,
    		'public'                     => true,
    		'show_ui'                    => true,
    		'show_admin_column'          => true,
    		'show_in_nav_menus'          => false,
    		'show_tagcloud'              => false,
    	);
    	register_taxonomy( 'logo-category', array( 'logo' ), $args );
    
    }
    add_action( 'init', 'benevolent_pro_logo_taxonomy', 0 );

}

if ( ! function_exists('benevolent_pro_testimonial_post_type') ) {

    // Register Custom Post Type
    function benevolent_pro_testimonial_post_type() {
    
    	$labels = array(
    		'name'                  => _x( 'Testimonials', 'Post Type General Name', 'benevolent-pro' ),
    		'singular_name'         => _x( 'Testimonial', 'Post Type Singular Name', 'benevolent-pro' ),
    		'menu_name'             => __( 'Testimonials', 'benevolent-pro' ),
    		'name_admin_bar'        => __( 'Testimonial', 'benevolent-pro' ),
    		'archives'              => __( 'Testimonial Archives', 'benevolent-pro' ),
    		'attributes'            => __( 'Testimonial Attributes', 'benevolent-pro' ),
    		'parent_item_colon'     => __( 'Parent Testimonial:', 'benevolent-pro' ),
    		'all_items'             => __( 'All Testimonials', 'benevolent-pro' ),
    		'add_new_item'          => __( 'Add New Testimonial', 'benevolent-pro' ),
    		'add_new'               => __( 'Add New', 'benevolent-pro' ),
    		'new_item'              => __( 'New Testimonial', 'benevolent-pro' ),
    		'edit_item'             => __( 'Edit Testimonial', 'benevolent-pro' ),
    		'update_item'           => __( 'Update Testimonial', 'benevolent-pro' ),
    		'view_item'             => __( 'View Testimonial', 'benevolent-pro' ),
    		'view_items'            => __( 'View Testimonials', 'benevolent-pro' ),
    		'search_items'          => __( 'Search Testimonial', 'benevolent-pro' ),
    		'not_found'             => __( 'Not found', 'benevolent-pro' ),
    		'not_found_in_trash'    => __( 'Not found in Trash', 'benevolent-pro' ),
    		'featured_image'        => __( 'Featured Image', 'benevolent-pro' ),
    		'set_featured_image'    => __( 'Set featured image', 'benevolent-pro' ),
    		'remove_featured_image' => __( 'Remove featured image', 'benevolent-pro' ),
    		'use_featured_image'    => __( 'Use as featured image', 'benevolent-pro' ),
    		'insert_into_item'      => __( 'Insert into testimonial', 'benevolent-pro' ),
    		'uploaded_to_this_item' => __( 'Uploaded to this testimonial', 'benevolent-pro' ),
    		'items_list'            => __( 'Testimonials list', 'benevolent-pro' ),
    		'items_list_navigation' => __( 'Testimonials list navigation', 'benevolent-pro' ),
    		'filter_items_list'     => __( 'Filter testimonials list', 'benevolent-pro' ),
    	);
    	$args = array(
    		'label'                 => __( 'Testimonial', 'benevolent-pro' ),
    		'description'           => __( 'A custom post type for testimonial.', 'benevolent-pro' ),
    		'labels'                => $labels,
    		'supports'              => array( 'title', 'editor', 'thumbnail', ),
    		'hierarchical'          => false,
    		'public'                => true,
    		'show_ui'               => true,
    		'show_in_menu'          => true,
    		'menu_position'         => 10,
    		'menu_icon'             => 'dashicons-testimonial',
    		'show_in_admin_bar'     => true,
    		'show_in_nav_menus'     => false,
    		'can_export'            => true,
    		'has_archive'           => false,		
    		'exclude_from_search'   => false,
    		'publicly_queryable'    => true,
    		'capability_type'       => 'post',
    	);
    	register_post_type( 'testimonial', $args );
    
    }
    add_action( 'init', 'benevolent_pro_testimonial_post_type', 0 );

}

if ( ! function_exists('benevolent_pro_team_post_type') ) {

    // Register Custom Post Type
    function benevolent_pro_team_post_type() {
    
    	$labels = array(
    		'name'                  => _x( 'Teams', 'Post Type General Name', 'benevolent-pro' ),
    		'singular_name'         => _x( 'Team', 'Post Type Singular Name', 'benevolent-pro' ),
    		'menu_name'             => __( 'Teams', 'benevolent-pro' ),
    		'name_admin_bar'        => __( 'Team', 'benevolent-pro' ),
    		'archives'              => __( 'Team Archives', 'benevolent-pro' ),
    		'attributes'            => __( 'Team Attributes', 'benevolent-pro' ),
    		'parent_item_colon'     => __( 'Parent Team:', 'benevolent-pro' ),
    		'all_items'             => __( 'All Teams', 'benevolent-pro' ),
    		'add_new_item'          => __( 'Add New Team', 'benevolent-pro' ),
    		'add_new'               => __( 'Add New', 'benevolent-pro' ),
    		'new_item'              => __( 'New Team', 'benevolent-pro' ),
    		'edit_item'             => __( 'Edit Team', 'benevolent-pro' ),
    		'update_item'           => __( 'Update Team', 'benevolent-pro' ),
    		'view_item'             => __( 'View Team', 'benevolent-pro' ),
    		'view_items'            => __( 'View Teama', 'benevolent-pro' ),
    		'search_items'          => __( 'Search Team', 'benevolent-pro' ),
    		'not_found'             => __( 'Not found', 'benevolent-pro' ),
    		'not_found_in_trash'    => __( 'Not found in Trash', 'benevolent-pro' ),
    		'featured_image'        => __( 'Featured Image', 'benevolent-pro' ),
    		'set_featured_image'    => __( 'Set featured image', 'benevolent-pro' ),
    		'remove_featured_image' => __( 'Remove featured image', 'benevolent-pro' ),
    		'use_featured_image'    => __( 'Use as featured image', 'benevolent-pro' ),
    		'insert_into_item'      => __( 'Insert into team', 'benevolent-pro' ),
    		'uploaded_to_this_item' => __( 'Uploaded to this team', 'benevolent-pro' ),
    		'items_list'            => __( 'Teams list', 'benevolent-pro' ),
    		'items_list_navigation' => __( 'Teams list navigation', 'benevolent-pro' ),
    		'filter_items_list'     => __( 'Filter teams list', 'benevolent-pro' ),
    	);
    	$args = array(
    		'label'                 => __( 'Team', 'benevolent-pro' ),
    		'description'           => __( 'A custom post type for team.', 'benevolent-pro' ),
    		'labels'                => $labels,
    		'supports'              => array( 'title', 'editor', 'thumbnail', ),
    		'hierarchical'          => false,
    		'public'                => true,
    		'show_ui'               => true,
    		'show_in_menu'          => true,
    		'menu_position'         => 10,
    		'menu_icon'             => 'dashicons-groups',
    		'show_in_admin_bar'     => true,
    		'show_in_nav_menus'     => false,
    		'can_export'            => true,
    		'has_archive'           => false,		
    		'exclude_from_search'   => false,
    		'publicly_queryable'    => true,
    		'capability_type'       => 'post',
    	);
    	register_post_type( 'team', $args );
    
    }
    add_action( 'init', 'benevolent_pro_team_post_type', 0 );

}

if( ! function_exists( 'benevolent_pro_logo_category_filter' ) ) :
/**
 * Function to list logo category filter in admin
*/
function benevolent_pro_logo_category_filter() {

    // only display these taxonomy filters on desired custom post_type listings
    global $typenow;
    
    if( $typenow == 'logo' ){

        // create an array of taxonomy slugs you want to filter by - if you want to retrieve all taxonomies, could use get_taxonomies() to build the list
        $filters = array( 'logo-category' );

        foreach( $filters as $tax_slug ) {
            // retrieve the taxonomy object
            $tax_obj = get_taxonomy( $tax_slug );
            $tax_name = $tax_obj->labels->name;
            
            // Get taxonomy terms and order by name.
            $args = array(
                'orderby' => 'name',
                'hide_empty' => false
            );
                    
            // retrieve array of term objects per taxonomy
            $terms = get_terms( $tax_slug, $args );

            // output html for taxonomy dropdown filter
            echo "<select name='$tax_slug' id='$tax_slug' class='postform'>";
            // Default show all.
            printf( '<option value="0">%s</option>', sprintf( __( 'Show All %s', 'benevolent-pro' ), $tax_name ) );

            //echo "<option value='0'>Show All $tax_name</option>";
            foreach( $terms as $term ){
                if ( isset( $_GET[ $tax_slug ] ) && $_GET[ $tax_slug ] === $term->slug ) {
                    echo '<option value='. $term->slug . ' selected="selected">' . $term->name .' (' . $term->count .')</option>';
                }else{
                    echo '<option value='. $term->slug . '>' . $term->name .' (' . $term->count .')</option>';
                }
            }
            echo "</select>";
        }
    }
}
add_action( 'restrict_manage_posts', 'benevolent_pro_logo_category_filter' );
endif;