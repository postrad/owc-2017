<?php
/**
 * Widget Contact
 *
 * @package Benevolent_Pro
 */
 
// register Benevolent_Pro_Contact widget
function benevolent_pro_register_contact_widget() {
    register_widget( 'Benevolent_Pro_Contact' );
}
add_action( 'widgets_init', 'benevolent_pro_register_contact_widget' );
 
 /**
 * Adds Benevolent_Pro_Contact widget.
 */
class Benevolent_Pro_Contact extends WP_Widget {

	/**
	 * Register widget with WordPress.
	 */
	function __construct() {
		parent::__construct(
			'benevolent_pro_contact', // Base ID
			__( 'RARA: Contact', 'benevolent-pro' ), // Name
			array( 'description' => __( 'A Contact Widget', 'benevolent-pro' ), ) // Args
		);
	}

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */
	public function widget( $args, $instance ) {
        
        $title       = ! empty( $instance['title'] ) ? $instance['title'] : '';
        $content     = ! empty( $instance['content'] ) ? $instance['content'] : '';
        $street_add  = ! empty( $instance['street_add'] ) ? $instance['street_add'] : '';
        $phone       = ! empty( $instance['phone'] ) ? $instance['phone'] : '';
        $email       = ! empty( $instance['email'] ) ? $instance['email'] : '';
        $show_social = ! empty( $instance['show_social'] ) ? $instance['show_social'] : '';
        
        echo $args['before_widget'];
        
        if( $title ) echo $args['before_title'] . apply_filters( 'widget_title', $title, $instance, $this->id_base ) . $args['after_title'];
        
        echo '<div class="widget-holder">';
        
        if( $content ) echo wpautop( wp_kses_post( $content ) );
        
        if( $street_add ) echo '<address class="address">' . esc_html( $street_add ) . '</address>';
        
        if( $phone ) echo '<a href="tel:' . preg_replace( '/\D/', '', $phone ) . '" class="tel-link">' . esc_html( $phone ) . '</a>';
        
        if( $email ) echo '<a href="mailto:' . sanitize_email( $email ) . '" class="email-link">' . esc_html( $email ) . '</a>';
        
        if( $show_social ) benevolent_pro_get_social_links( true );
        
        echo '</div>';
        
        echo $args['after_widget'];   
        
	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	public function form( $instance ) {
        
        $title       = ! empty( $instance['title'] ) ? $instance['title'] : '';
        $content     = ! empty( $instance['content'] ) ? $instance['content'] : '';
        $street_add  = ! empty( $instance['street_add'] ) ? $instance['street_add'] : '';
        $phone       = ! empty( $instance['phone'] ) ? $instance['phone'] : '';
        $email       = ! empty( $instance['email'] ) ? $instance['email'] : '';
        $show_social = ! empty( $instance['show_social'] ) ? $instance['show_social'] : '';
        
        ?>
		
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title', 'benevolent-pro' ); ?></label> 
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
		</p>
        
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'content' ) ); ?>"><?php esc_html_e( 'Content', 'benevolent-pro' ); ?></label>
            <textarea name="<?php echo esc_attr( $this->get_field_name( 'content' ) ); ?>" class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'content' ) ); ?>"><?php echo esc_attr( $content ); ?></textarea>
        </p>
        
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'street_add' ) ); ?>"><?php esc_html_e( 'Street Address', 'benevolent-pro' ); ?></label> 
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'street_add' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'street_add' ) ); ?>" type="text" value="<?php echo esc_attr( $street_add ); ?>" />
		</p>
        
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'phone' ) ); ?>"><?php esc_html_e( 'Phone', 'benevolent-pro' ); ?></label> 
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'phone' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'phone' ) ); ?>" type="text" value="<?php echo esc_attr( $phone ); ?>" />
		</p>        
        
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'email' ) ); ?>"><?php esc_html_e( 'Email', 'benevolent-pro' ); ?></label> 
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'email' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'email' ) ); ?>" type="text" value="<?php echo esc_attr( $email ); ?>" />
		</p>
        
        <p>
            <input id="<?php echo esc_attr( $this->get_field_id( 'show_social' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'show_social' ) ); ?>" type="checkbox" value="1" <?php checked( '1', $show_social ); ?>/>
            <label for="<?php echo esc_attr( $this->get_field_id( 'show_social' ) ); ?>"><?php esc_html_e( 'Show Social Icons', 'benevolent-pro' ); ?></label>
		</p>
		<?php 
	}

	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		
        $instance['title']       = ! empty( $new_instance['title'] ) ? sanitize_text_field( $new_instance['title'] ) : '';
        $instance['content']     = ! empty( $new_instance['content'] ) ? wp_kses_post( $new_instance['content'] ) : '';
        $instance['street_add']  = ! empty( $new_instance['street_add'] ) ? sanitize_text_field( $new_instance['street_add'] ) : '';
        $instance['phone']       = ! empty( $new_instance['phone'] ) ? sanitize_text_field( $new_instance['phone'] ) : '';
        $instance['email']       = ! empty( $new_instance['email'] ) ? sanitize_email( $new_instance['email'] ) : '';
        $instance['show_social'] = ! empty( $new_instance['show_social'] ) ? absint( $new_instance['show_social'] ) : '';
                
        return $instance;
	}

} // class Benevolent_Pro_Contact 