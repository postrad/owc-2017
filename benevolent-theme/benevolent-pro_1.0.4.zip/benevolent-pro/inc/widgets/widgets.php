<?php
/**
 * Benevolent Pro functions and definitions.
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Benevolent_Pro 
 */

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function benevolent_pro_widgets_init() {
	
    $sidebars = array(
        'sidebar'   => array(
            'name'        => __( 'Sidebar', 'benevolent-pro' ),
            'id'          => 'sidebar', 
            'description' => __( 'Default Sidebar', 'benevolent-pro' ),
        ),
        'stat-counter'=> array(
            'name'        => __( 'Stat Counter Widget Section', 'benevolent-pro' ),
            'id'          => 'stat-counter', 
            'description' => __( 'Add home page stat counter widgets.', 'benevolent-pro' ),
        ),
        'cta'=> array(
            'name'        => __( 'CTA Widget Section (Home)', 'benevolent-pro' ),
            'id'          => 'cta', 
            'description' => __( 'Add home page CTA widgets.', 'benevolent-pro' ),
        ),
        'about-profile'=> array(
            'name'        => __( 'Profile Widget Section', 'benevolent-pro' ),
            'id'          => 'about-profile', 
            'description' => __( 'Add about page profile widgets.', 'benevolent-pro' ),
        ),
        'about-counter'=> array(
            'name'        => __( 'Counter Widget Section', 'benevolent-pro' ),
            'id'          => 'about-counter', 
            'description' => __( 'Add about page stat counter widgets.', 'benevolent-pro' ),
        ),          
        'service-first'=> array(
            'name'        => __( 'Services Widget Section', 'benevolent-pro' ),
            'id'          => 'service-first', 
            'description' => __( 'Add service page service widgets.', 'benevolent-pro' ),
        ), 
        'service-cta'=> array(
            'name'        => __( 'CTA Widget Section (Service)', 'benevolent-pro' ),
            'id'          => 'service-cta', 
            'description' => __( 'Add service page cta widgets.', 'benevolent-pro' ),
        ), 
        'footer-one'=> array(
            'name'        => __( 'Footer One', 'benevolent-pro' ),
            'id'          => 'footer-one', 
            'description' => __( 'Add footer one widgets.', 'benevolent-pro' ),
        ),
        'footer-two'=> array(
            'name'        => __( 'Footer Two', 'benevolent-pro' ),
            'id'          => 'footer-two', 
            'description' => __( 'Add footer two widgets.', 'benevolent-pro' ),
        ),
        'footer-three'=> array(
            'name'        => __( 'Footer Three', 'benevolent-pro' ),
            'id'          => 'footer-three', 
            'description' => __( 'Add footer three widgets.', 'benevolent-pro' ),
        ),
        'footer-four'=> array(
            'name'        => __( 'Footer Four', 'benevolent-pro' ),
            'id'          => 'footer-four', 
            'description' => __( 'Add footer four widgets.', 'benevolent-pro' ),
        )
    );
    
    foreach( $sidebars as $sidebar ){
        register_sidebar( array(
    		'name'          => $sidebar['name'],
    		'id'            => $sidebar['id'],
    		'description'   => $sidebar['description'],
    		'before_widget' => '<section id="%1$s" class="widget %2$s">',
    		'after_widget'  => '</section>',
    		'before_title'  => '<h2 class="widget-title">',
    		'after_title'   => '</h2>',
    	) );
    }
    
    /** Dynamic sidebars */
    $dynamic_sidebars = benevolent_pro_get_dynamnic_sidebar(); 
    $dynamic_sidebars = array_diff( array_unique( $dynamic_sidebars ), array('') );
    
    if( $dynamic_sidebars ){
        foreach( $dynamic_sidebars as $k => $v ){
            register_sidebar( array(
        		'name'          => esc_html( $v ),
        		'id'            => esc_attr( $k ),
        		'description'   => '',
        		'before_widget' => '<section id="%1$s" class="widget %2$s">',
        		'after_widget'  => '</section>',
        		'before_title'  => '<h2 class="widget-title">',
        		'after_title'   => '</h2>',
        	) );
        }
    }
    
}
add_action( 'widgets_init', 'benevolent_pro_widgets_init' );

/**
 * Recent Post Widget
 */
require get_template_directory() . '/inc/widgets/widget-recent-post.php';

/**
 * Author Post Widget
 */
require get_template_directory() . '/inc/widgets/widget-author-post.php';

/**
 * Category Post Widget
 */
require get_template_directory() . '/inc/widgets/widget-cat-post.php';

/**
 * Contact Widget
 */
require get_template_directory() . '/inc/widgets/widget-contact.php';

/**
 * CTA Widget
 */
require get_template_directory() . '/inc/widgets/widget-cta.php';

/**
 * Facebook Page Widget
 */
require get_template_directory() . '/inc/widgets/widget-facebook-page.php';

/**
 * Featured Post Widget
 */
require get_template_directory() . '/inc/widgets/widget-featured-post.php';

/**
 * Flickr Widget
 */
require get_template_directory() . '/inc/widgets/widget-flickr.php';

/**
 * Icon Text Widget
 */
require get_template_directory() . '/inc/widgets/widget-icon-text.php';

/**
 * Instagram Widget
 */
require get_template_directory() . '/inc/widgets/widget-instagram.php';

/**
 * Popular Post Widget
 */
require get_template_directory() . '/inc/widgets/widget-popular-post.php';

/**
 * Social Link Widget
 */
require get_template_directory() . '/inc/widgets/widget-social-links.php';

/**
 * Stat Counter Widget
 */
require get_template_directory() . '/inc/widgets/widget-stat-counter.php';

/**
 * Twitter Widget
 */
require get_template_directory() . '/inc/widgets/widget-twitter-feeds.php';