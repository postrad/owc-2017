<?php
/**
 * Stat Counter Widget
 *
 * @package Benevolent_Pro
 */

// register Benevolent_Pro_Stat_Counter_Widget widget
function benevolent_pro_register_stat_counter_widget(){
    register_widget( 'Benevolent_Pro_Stat_Counter_Widget' );
}
add_action('widgets_init', 'benevolent_pro_register_stat_counter_widget');
 
 /**
 * Adds Benevolent_Pro_Stat_Counter_Widget widget.
 */
class Benevolent_Pro_Stat_Counter_Widget extends WP_Widget {

    /**
     * Register widget with WordPress.
     */
    public function __construct() {
        parent::__construct(
			'benevolent_pro_stat_counter_widget', // Base ID
			__( 'RARA: Stat Counter Widget', 'benevolent-pro' ), // Name
			array( 'description' => __( 'Widget for stat counter.', 'benevolent-pro' ), ) // Args
		);
    }

    /**
     * Front-end display of widget.
     *
     * @see WP_Widget::widget()
     *
     * @param array $args     Widget arguments.
     * @param array $instance Saved values from database.
     */
    public function widget( $args, $instance ) {
        
        $title   = ! empty( $instance['title'] ) ? $instance['title'] : '' ;		
        $counter = ! empty( $instance['counter'] ) ? $instance['counter'] : '';
        
        echo $args['before_widget']; ?>
        
            <div class="col">
				
                <div class="text-holder">
					<?php 
                        if( $counter ) echo '<strong class="number">' . absint( $counter ) . '</strong>';
                         
    					if( $title ) echo $args['before_title'] . apply_filters( 'widget_title', $title, $instance, $this->id_base ) . $args['after_title']; 
                    ?>                    
				</div>
                
			</div>        
        
        <?php
        echo $args['after_widget'];
    }

    /**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	public function form( $instance ) {
        
        $title   = ! empty( $instance['title'] ) ? $instance['title'] : '' ;		
        $counter = ! empty( $instance['counter'] ) ? $instance['counter'] : '';
        
        ?>
		
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title', 'benevolent-pro' ); ?></label> 
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />            
		</p>
        
        <p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'counter' ) ); ?>"><?php esc_html_e( 'Counter', 'benevolent-pro' ); ?></label>
			<input name="<?php echo esc_attr( $this->get_field_name( 'counter' ) ); ?>" type="number" step="1" min="1" id="<?php echo esc_attr( $this->get_field_id( 'content' ) ); ?>" value="<?php echo absint( $counter ); ?>" class="small-text" />			
		</p>
                        
        <?php
	}
    
    /**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		
        $instance['title']   = ! empty( $new_instance['title'] ) ? sanitize_text_field( $new_instance['title'] ) : '' ;
        $instance['counter'] = ! empty( $new_instance['counter'] ) ? absint( $new_instance['counter'] ) : '';
        
        return $instance;
	}
    
}  // class Benevolent_Pro_Stat_Counter_Widget 