<?php
/**
 * GIVE Plugin Related Functions
 *  
 * @package Benevolent_Pro 
*/

/**
 * Custom Give Single Template Wrapper Start
 */
function benevolent_pro_give_start_wrapper() {
	echo '<div id="primary" class="content-area"><main id="main" class="site-main" role="main">';
}
add_filter( 'give_default_wrapper_start', 'benevolent_pro_give_start_wrapper' );

/**
 * Custom Give Single Template Wrapper End
 */
function benevolent_pro_give_end_wrapper() {
	echo '</main></div>';
}
add_filter( 'give_default_wrapper_end', 'benevolent_pro_give_end_wrapper' );

/**
 * Function to add/remove give hook
*/
function benevolent_pro_give_hooks(){
    
    remove_action( 'give_before_single_form_summary', array( Give()->template_loader, 'give_output_sidebar_option' ), 1 );   
    remove_action( 'give_single_form_summary', 'give_template_single_title', 5 );
    
    add_action( 'give_before_single_form_summary', 'give_template_single_title', 4 );
    add_action( 'give_before_single_form_summary', 'give_left_sidebar_pre_wrap', 5 );
	add_action( 'give_before_single_form_summary', 'give_show_form_images', 10 );
	add_action( 'give_before_single_form_summary', 'give_left_sidebar_post_wrap', 30 );
    
    //Filter to change image size in single give form page as per our theme
    add_filter( 'single_give_form_large_thumbnail_size', 'benevolent_pro_give_imgsize_filter'  );
    
    add_action( 'give_sidebar', 'benevolent_pro_give_sidebar' );
         
}
add_action( 'after_setup_theme', 'benevolent_pro_give_hooks' );

/**
 * Function to change image size in single give
*/
function benevolent_pro_give_imgsize_filter(){    
    
    return ( is_active_sidebar( 'give-forms-sidebar' ) ? 'benevolent-pro-with-sidebar' : 'benevolent-pro-without-sidebar' );
}

/**
 * Function to add sidebar in give single page
*/
function benevolent_pro_give_sidebar(){
    
    $sidebar_option = give_get_option( 'disable_form_sidebar' );
    
    if ( is_active_sidebar( 'give-forms-sidebar' ) && ( $sidebar_option !== 'on' ) ) {
        echo '<aside id="secondary" class="widget-area" role="complementary">';
        dynamic_sidebar( 'give-forms-sidebar' );
        echo '</aside>';
    }
}