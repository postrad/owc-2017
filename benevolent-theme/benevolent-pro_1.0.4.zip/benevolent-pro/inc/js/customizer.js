jQuery(document).ready(function($) {
	/* Move widgets to their respective sections */
	wp.customize.section( 'sidebar-widgets-stat-counter' ).panel( 'benevolent_pro_home_page_settings' );
	wp.customize.section( 'sidebar-widgets-stat-counter' ).priority( '40' );
    wp.customize.section( 'sidebar-widgets-cta' ).panel( 'benevolent_pro_home_page_settings' );
	wp.customize.section( 'sidebar-widgets-cta' ).priority( '70' );
    
    wp.customize.section( 'sidebar-widgets-about-profile' ).panel( 'benevolent_pro_about_page_settings' );
	wp.customize.section( 'sidebar-widgets-about-profile' ).priority( '40' );
    wp.customize.section( 'sidebar-widgets-about-counter' ).panel( 'benevolent_pro_about_page_settings' );
	wp.customize.section( 'sidebar-widgets-about-counter' ).priority( '55' );
    
        
    wp.customize.section( 'sidebar-widgets-service-first' ).panel( 'benevolent_pro_service_page_settings' );
	wp.customize.section( 'sidebar-widgets-service-first' ).priority( '40' );
    wp.customize.section( 'sidebar-widgets-service-cta' ).panel( 'benevolent_pro_service_page_settings' );
	wp.customize.section( 'sidebar-widgets-service-cta' ).priority( '50' );
    
});