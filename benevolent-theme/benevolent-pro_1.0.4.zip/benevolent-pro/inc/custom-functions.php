<?php
/**
 * Benevolent Pro functions and definitions.
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Benevolent_Pro 
 */

if ( ! function_exists( 'benevolent_pro_setup' ) ) :
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function benevolent_pro_setup() {
	/*
	 * Make theme available for translation.
	 * Translations can be filed in the /languages/ directory.
	 * If you're building a theme based on Benevolent Pro, use a find and replace
	 * to change 'benevolent-pro' to the name of your theme in all the template files.
	 */
	load_theme_textdomain( 'benevolent-pro', get_template_directory() . '/languages' );
    
    // Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	add_theme_support( 'title-tag' );

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
	 */
	add_theme_support( 'post-thumbnails' );

	// This theme uses wp_nav_menu() in one location.
	register_nav_menus( array(
		'primary'   => esc_html__( 'Primary', 'benevolent-pro' ),
        'secondary' => esc_html__( 'Secondary', 'benevolent-pro' ),
	) );

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'search-form',
		'comment-form',
		'comment-list',
		'gallery',
		'caption',
	) );

	/*
	 * Enable support for Post Formats.
	 * See https://developer.wordpress.org/themes/functionality/post-formats/
	 */
	add_theme_support( 'post-formats', array(
		'aside',        
		'image',
		'video',
		'quote',
		'link',
        'gallery',
        'status',
        'audio', 
        'chat'
	) );
    
    // Custom Image Size
    add_image_size( 'benevolent-pro-slider', 1920, 967, true );
    add_image_size( 'benevolent-pro-community', 960, 450, true );
    add_image_size( 'benevolent-pro-blog', 350, 196, true );
    add_image_size( 'benevolent-pro-with-sidebar', 780, 437, true );
    add_image_size( 'benevolent-pro-without-sidebar', 1180, 437, true );
    add_image_size( 'benevolent-pro-featured-post', 275, 275, true );
    add_image_size( 'benevolent-pro-recent-post', 75, 75, true );
    add_image_size( 'benevolent-pro-testimonial', 228, 337, true );
    add_image_size( 'benevolent-pro-team', 350, 235, true );
    add_image_size( 'benevolent-pro-give', 380, 255, true );
    
    /* Custom Logo */
    add_theme_support( 'custom-logo', array(
    	'header-text' => array( 'site-title', 'site-description' ),
    ) );
    
}
endif;

if( ! function_exists( 'benevolent_pro_content_width' ) ) :
/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function benevolent_pro_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'benevolent_pro_content_width', 780 );
}
endif;

if( ! function_exists( 'benevolent_pro_scripts' ) ) :
/**
 * Enqueue scripts and styles.
 */
function benevolent_pro_scripts() {
	
    $map_api = get_theme_mod( 'benevolent_pro_map_api' );
    $key     = $map_api ? '?key='.esc_attr( $map_api ) : '' ;
    
    wp_enqueue_style( 'font-awesome', get_template_directory_uri() . '/css/font-awesome.css' );
    wp_enqueue_style( 'jquery.sidr.light', get_template_directory_uri() . '/css/jquery.sidr.light.css' );
    wp_enqueue_style( 'lightslider', get_template_directory_uri() . '/css/lightslider.css' );
    wp_enqueue_style( 'benevolent-pro-style', get_stylesheet_uri(), array(), BENEVOLENT_PRO_THEME_VERSION );
    
    // woocommerce css	
    if( is_woocommerce_activated() )
    wp_enqueue_style( 'benevolent-pro-woocommerce-style', get_template_directory_uri(). '/css/woocommerce.css', BENEVOLENT_PRO_THEME_VERSION );
    
    //Fancy Box
    if( get_theme_mod( 'benevolent_pro_ed_lightbox') ){
        wp_enqueue_style( 'jquery.fancybox', get_template_directory_uri() . '/js/fancybox/jquery.fancybox.css', '', '2.1.5' );
        wp_enqueue_script( 'jquery.fancybox.pack', get_template_directory_uri() . '/js/fancybox/jquery.fancybox.pack.js', array('jquery'), '2.1.5', true );
    }
    
    if( is_page_template( 'templates/template-contact.php' ) )
    wp_enqueue_script( 'benevolent-pro-googlemap', '//maps.googleapis.com/maps/api/js'.$key, array('jquery'), '3.0', false );
    
    if( is_page_template( array( 'templates/template-team.php', 'templates/template-about.php', 'templates/template-service.php' ) ) )
    wp_enqueue_script( 'masonry' );
    
    if( is_active_widget( false, false, 'benevolent_pro_flickr_widget' ) )
    wp_enqueue_script( 'jflickrfeed', get_template_directory_uri() . '/js/jflickrfeed.js', array('jquery'), BENEVOLENT_PRO_THEME_VERSION, true );
    
    
    wp_enqueue_script( 'waypoint', get_template_directory_uri() . '/js/waypoint.js', array('jquery'), '2.0.3', true );
    wp_enqueue_script( 'jquery.counterup', get_template_directory_uri() . '/js/jquery.counterup.js', array('jquery', 'waypoint'), '1.0', true );
    wp_enqueue_script( 'jquery.fitvids', get_template_directory_uri() . '/js/jquery.fitvids.js', array('jquery'), '1.1', true );
    wp_enqueue_script( 'equal-height', get_template_directory_uri() . '/js/equal-height.js', array('jquery'), '0.7.0', true );
    wp_enqueue_script( 'jquery.sidr', get_template_directory_uri() . '/js/jquery.sidr.js', array('jquery'), '2.2.1', true );
	wp_enqueue_script( 'lightslider', get_template_directory_uri() . '/js/lightslider.js', array('jquery'), '1.1.5', true );	
    wp_register_script( 'benevolent-pro-custom', get_template_directory_uri() . '/js/custom.js', array('jquery'), BENEVOLENT_PRO_THEME_VERSION, true );
    wp_register_script( 'benevolent-pro-ajax', get_template_directory_uri() . '/js/ajax.js', array('jquery'), BENEVOLENT_PRO_THEME_VERSION, true );
    
    $slider_auto      = get_theme_mod( 'benevolent_pro_slider_auto', '1' );
    $slider_loop      = get_theme_mod( 'benevolent_pro_slider_loop', '1' );
    $slider_pager     = get_theme_mod( 'benevolent_pro_slider_pager', '1' );    
    $slider_animation = get_theme_mod( 'benevolent_pro_slider_animation', 'slide' );
    $slider_speed     = get_theme_mod( 'benevolent_pro_slider_speed', '400' );
    $slider_pause     = get_theme_mod( 'benevolent_pro_slider_pause', '6000' );
    $sticky_header    = get_theme_mod( 'benevolent_pro_ed_sticky_header' );
    $header_style     = get_theme_mod( 'benevolent_pro_header_layout', 'one' );
    
    $array = array(
        'auto'      => esc_attr( $slider_auto ),
        'loop'      => esc_attr( $slider_loop ),
        'pager'     => esc_attr( $slider_pager ),
        'mode'      => esc_attr( $slider_animation ),
        'speed'     => absint( $slider_speed ),
        'pause'     => absint( $slider_pause ),  
        'lightbox'  => esc_attr( get_theme_mod( 'benevolent_pro_ed_lightbox') ),      
        'rtl'       => is_rtl(),
        'sticky'    => $sticky_header,
        'header'    => $header_style,
    );
    
    wp_localize_script( 'benevolent-pro-custom', 'benevolent_pro_data', $array );
    wp_enqueue_script( 'benevolent-pro-custom' );
    
    $pagination = get_theme_mod( 'benevolent_pro_pagination_type', 'default' );
    
    if( get_theme_mod( 'benevolent_pro_ed_ajax_search' ) || $pagination == 'load_more' || $pagination == 'infinite_scroll' ){
        
        // Add parameters for the JS
        global $wp_query;
        $max = $wp_query->max_num_pages;
        $paged = ( get_query_var( 'paged' ) > 1 ) ? get_query_var( 'paged' ) : 1;
        
        wp_enqueue_script( 'benevolent-pro-ajax' );
        
        wp_localize_script( 
            'benevolent-pro-ajax', 
            'benevolent_pro_ajax',
            array(
                'url'           => admin_url( 'admin-ajax.php' ),
                'startPage'     => $paged,
                'maxPages'      => $max,
                'nextLink'      => next_posts( $max, false ),
                'autoLoad'      => $pagination,
                'loadmore'      => __( 'Load More Posts', 'benevolent-pro' ),
                'loading'       => __('Loading...', 'benevolent-pro'),
                'nomore'        => __( 'No more posts.', 'benevolent-pro' ),
                'plugin_url'    => plugins_url()
             )
        );
        
        if ( is_jetpack_activated( true ) ) {
            wp_enqueue_style( 'tiled-gallery', plugins_url() . '/jetpack/modules/tiled-gallery/tiled-gallery/tiled-gallery.css' );            
        }
    }
    
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
endif;

/**
 * Enqueue google fonts
*/
function benevolent_pro_scripts_styles() {
    wp_enqueue_style( 'benevolent-pro-google-fonts', benevolent_pro_fonts_url(), array(), null );
}

if( ! function_exists( 'benevolent_pro_admin_scripts' ) ) :
/**
 * Enqueue admin scripts and styles.
 */
function benevolent_pro_admin_scripts(){
    
    if( function_exists( 'wp_enqueue_media' ) )
    wp_enqueue_media();
    
    wp_enqueue_style( 'wp-color-picker' );  
    wp_enqueue_style( 'fontawesome', get_template_directory_uri() . '/css/font-awesome.css', array(), '4.6.3' );
    wp_enqueue_style( 'benevolent-pro-admin-style', get_template_directory_uri() . '/inc/css/admin.css', array(), BENEVOLENT_PRO_THEME_VERSION );
    
    wp_register_script( 'benevolent-pro-media-uploader', get_template_directory_uri() . '/inc/js/media-uploader.js', array('jquery'), BENEVOLENT_PRO_THEME_VERSION );
    wp_register_script( 'benevolent-pro-admin-js', get_template_directory_uri() . '/inc/js/admin.js', array('jquery'), BENEVOLENT_PRO_THEME_VERSION );
    
    wp_localize_script( 'benevolent-pro-media-uploader', 'benevolent_pro_uploader', array(
        'upload' => __( 'Upload', 'benevolent-pro' ),
        'change' => __( 'Change', 'benevolent-pro' ),
        'msg'    => __( 'Please upload valid image file.', 'benevolent-pro' )
    ));
    
    wp_localize_script( 'benevolent-pro-admin-js', 'benevolent_pro_admin', array(
        'import_true' => __( 'Are you sure to import dummy content?', 'benevolent-pro' ),
        'demo_msg'    => __( 'The Demo Contents are Loading. It might take a while. Please keep patience.', 'benevolent-pro' ),
        'success_msg' => __( 'Demo Contents Successfully Imported.', 'benevolent-pro' ),
    ));
    
    wp_enqueue_script( 'benevolent-pro-media-uploader' );
    
    //For Color Picker
    wp_enqueue_script('benevolent-pro-color-picker', get_template_directory_uri() . '/inc/js/color-picker.js', array( 'wp-color-picker' ), BENEVOLENT_PRO_THEME_VERSION );
    
    wp_enqueue_script( 'benevolent-pro-admin-js' );
    
}
endif;

if( ! function_exists( 'benevolent_pro_customizer_js' ) ) :
/** 
 * Registering and enqueuing scripts/stylesheets for Customizer controls.
 */ 
function benevolent_pro_customizer_js() {
	wp_enqueue_script( 'benevolent-pro-customizer-js', get_template_directory_uri() . '/inc/js/customizer.js', array('jquery'), BENEVOLENT_PRO_THEME_VERSION, true  );
}
endif;

if( ! function_exists( 'benevolent_pro_body_classes' ) ) :
/**
 * Adds custom classes to the array of body classes.
 *
 * @param array $classes Classes for the body element.
 * @return array
 */
function benevolent_pro_body_classes( $classes ) {
	
    $blog_layout = get_theme_mod( 'benevolent_pro_blog_layout', 'default' ); //From Customizer
    $bg_color    = get_theme_mod( 'benevolent_pro_bg_color', '#FFFFFF' );
    $bg_image    = get_theme_mod( 'benevolent_pro_bg_image' );
    $bg_pattern  = get_theme_mod( 'benevolent_pro_bg_pattern', 'nobg' );
    $bg          = get_theme_mod( 'benevolent_pro_body_bg', 'image' );
    
    // Adds a class of group-blog to blogs with more than 1 published author.
	if ( is_multi_author() ) {
		$classes[] = 'group-blog';
	}

	// Adds a class of hfeed to non-singular pages.
	if ( ! is_singular() ) {
		$classes[] = 'hfeed';
	}
    
    // Adds a class for custom background Color
    if( $bg_color != '#FFFFFF' ){
        $classes[] = 'custom-background-color';
    }
    
    // Adds a class for custom background Color
    if( ( $bg == 'image' && $bg_image ) || (  $bg == 'pattern' && $bg_pattern != 'nobg' ) ){
        $classes[] = 'custom-background-image';
    }
    
    if( get_theme_mod( 'benevolent_pro_ed_slider' ) ){
        $classes[] = 'has-slider';
	}
    
    if( $blog_layout === 'round' ){
        $classes[] = 'blog-round';
    }
    
    if( $blog_layout === 'square' ){
        $classes[] = 'blog-medium';
    }
    
    if( is_woocommerce_activated() && ( is_shop() || is_product_category() || is_product_tag() || 'product' === get_post_type() ) && ! is_active_sidebar( 'shop-sidebar' ) ){
        $classes[] = 'full-width';
    }
    
    $classes[] = benevolent_pro_sidebar( false, true );
    
	return $classes;
}
endif;

if( ! function_exists( 'benevolent_pro_post_classes' ) ) :
/**
 * Adds custom classes to the array of post classes.
 *
 * @param array $classes Classes for the post element.
 * @return array
 */
function benevolent_pro_post_classes( $classes ) {
    
    $classes[] = 'latest_post';
    
    if( is_post_type_archive( 'give_forms' ) || ( is_give_activated() && ( is_give_taxonomy() || is_singular( 'give_forms' ) ) ) ){
        $classes[] = 'post';
    }
    
    return $classes;
}
endif;

/**
 * Flush out the transients used in benevolent_pro_categorized_blog.
 */
function benevolent_pro_category_transient_flusher() {
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	// Like, beat it. Dig?
	delete_transient( 'benevolent_pro_categories' );
}

if( ! function_exists( 'benevolent_pro_move_comment_field_to_bottom' ) ) :
/** 
 * Hook to move comment text field to the bottom in WP 4.4 
 *
 * @link http://www.wpbeginner.com/wp-tutorials/how-to-move-comment-text-field-to-bottom-in-wordpress-4-4/  
 */
function benevolent_pro_move_comment_field_to_bottom( $fields ) {
    $comment_field = $fields['comment'];
    unset( $fields['comment'] );
    $fields['comment'] = $comment_field;
    return $fields;
}
endif;

/**
 * Custom CSS
*/
if ( function_exists( 'wp_update_custom_css_post' ) ) {
    // Migrate any existing theme CSS to the core option added in WordPress 4.7.
    $css = get_theme_mod( 'benevolent_pro_custom_css' );
    if ( $css ) {
        $core_css = wp_get_custom_css(); // Preserve any CSS already added to the core option.
        $return = wp_update_custom_css_post( $core_css . $css );
        if ( ! is_wp_error( $return ) ) {
            // Remove the old theme_mod, so that the CSS is stored in only one place moving forward.
            remove_theme_mod( 'benevolent_pro_custom_css' );
        }
    }
} else {
    function benevolent_pro_custom_css(){
        $custom_css = get_theme_mod( 'benevolent_pro_custom_css' );
        if( !empty( $custom_css ) ){
    		echo '<style type="text/css">';
    		echo wp_strip_all_tags( $custom_css );
    		echo '</style>';
    	}
    }
    add_action( 'wp_head', 'benevolent_pro_custom_css', 101 );
}

if( ! function_exists( 'benevolent_pro_custom_js' ) ) :
/**
 * Custom JS
*/
function benevolent_pro_custom_js(){
    $custom_script = get_theme_mod( 'benevolent_pro_custom_script' );
    if( $custom_script ){
        echo '<script type="text/javascript">';
		echo wp_strip_all_tags( $custom_script );
		echo '</script>';
    }
}
endif;

if( ! function_exists( 'benevolent_pro_excerpt_more' ) ) :
/**
 * Replaces "[...]" (appended to automatically generated excerpts) with ... * 
 */
function benevolent_pro_excerpt_more() {
	return ' &hellip; ';
}
endif;

if( ! function_exists( 'benevolent_pro_excerpt_length' ) ) :
/**
 * Changes the default 55 character in excerpt 
*/
function benevolent_pro_excerpt_length( $length ) {
	return 60;
}
endif;

if( ! function_exists( 'benevolent_pro_logo_metabox' ) ) :
/**
 * Function that removes the default thumbnail and add custom thumbnail meta box 
 */
function benevolent_pro_logo_metabox(){
   remove_meta_box( 'postimagediv', 'logo', 'side' );
   add_meta_box( 'postimagediv', __( 'Featured Image', 'benevolent-pro' ), 'post_thumbnail_meta_box', 'logo', 'normal', 'high' );
}
endif;

if( ! function_exists( 'benevolent_pro_excerpts_in_pages' ) ) :
/**
 * Function to add excerpt field in pages
*/
function benevolent_pro_excerpts_in_pages() {
     add_post_type_support( 'page', 'excerpt' );
}
endif;

if( ! function_exists( 'benevolent_pro_google_map' ) ) :
/**
 * Callback Function for Google Map 
*/
function benevolent_pro_google_map(){
    if( is_page_template( 'templates/template-contact.php' ) ){
        
        $ed_google_map   = get_theme_mod( 'benevolent_pro_ed_google_map' );
        $lattitude       = get_theme_mod( 'benevolent_pro_lattitude', '27.7304135' );
        $longitude       = get_theme_mod( 'benevolent_pro_longitude', '85.3304937' );
        $map_height      = get_theme_mod( 'benevolent_pro_map_height', '320' );
        $map_zoom        = get_theme_mod( 'benevolent_pro_map_zoom', '17' );
        $map_type        = get_theme_mod( 'benevolent_pro_map_type', 'ROADMAP' );
        $map_scroll      = ( get_theme_mod( 'benevolent_pro_ed_map_scroll', '1' ) == 1 ) ? 'true' : 'false';
        $map_control     = ( get_theme_mod( 'benevolent_pro_ed_map_controls', '1' ) != 1 ) ? 'true' : 'false';
        $map_control_inv = ( get_theme_mod( 'benevolent_pro_ed_map_controls', '1' ) == 1 ) ? 'true' : 'false';
        $ed_map_marker   = get_theme_mod( 'benevolent_pro_ed_map_marker' );
        $marker_title    = get_theme_mod( 'benevolent_pro_marker_title' );
        
        if( $ed_google_map ){ ?>
        <style>
          #map {
            width: 100%;
            height: <?php echo $map_height; ?>px;
          }
        </style>
        <script type="text/javascript">
        
            var map;
            var myLatLng = {lat: <?php echo $lattitude;?>, lng: <?php echo $longitude;?>};
            
            function initialize() {
                var mapOptions = {
                    zoom: <?php echo $map_zoom; ?>,
                    center: new google.maps.LatLng(<?php echo $lattitude;?>, <?php echo $longitude;?> ),
                    mapTypeId: google.maps.MapTypeId.<?php echo $map_type; ?>,
                    scrollwheel: <?php echo $map_scroll ?>,
                    zoomControl: <?php echo $map_control_inv ?>,
                    zoomControlOptions: {
                        style: google.maps.ZoomControlStyle.SMALL
                    },
                    mapTypeControl: <?php echo $map_control_inv ?>,
                    mapTypeControlOptions: {
                        style: google.maps.MapTypeControlStyle.DROPDOWN_MENU
                    },
                    disableDefaultUI: <?php echo $map_control ?>,
                };
                map = new google.maps.Map(document.getElementById('map'), mapOptions);
                
                <?php if( $ed_map_marker ){ ?>
                var marker = new google.maps.Marker({
                  position: myLatLng,
                  map: map,
                  <?php if( $marker_title ) echo 'title: "' . esc_html( $marker_title ) . '"' ?>
                });
                <?php } ?>
                
            }
            google.maps.event.addDomListener(window, 'load', initialize); 
          
        </script>
    <?php }
    }    
}
endif;

if( ! function_exists( 'benevolent_pro_donate_button_link' ) ) :
/**
* Filter wp_nav_menu() to add profile link
* 
* @link http://www.wpbeginner.com/wp-themes/how-to-add-custom-items-to-specific-wordpress-menus/
*/
function benevolent_pro_donate_button_link( $menu, $args ) {
    
    $button         = '';
    $ed_donate_btn  = get_theme_mod( 'benevolent_pro_ed_donate_button' );
    $ed_donate_form = get_theme_mod( 'benevolent_pro_ed_donate_form' );
    $donate_form    = get_theme_mod( 'benevolent_pro_donate_form' );
    $button_text    = get_theme_mod( 'benevolent_pro_donate_button_label', __( 'Donate Now', 'benevolent-pro' ) );
    $button_url     = get_theme_mod( 'benevolent_pro_donate_button_url' );
    $header_layout  = get_theme_mod( 'benevolent_pro_header_layout', 'one' );
        
    if( $ed_donate_btn && $args->theme_location == 'primary' && $header_layout !== 'three' ){
        
        if( is_give_activated() && ( $ed_donate_form && $donate_form && $button_text ) ){
            $button = '<li><a href="' . esc_url( get_permalink( $donate_form ) ). '" class="btn-donate">' . esc_html( $button_text ) . '</a></li>';
        }elseif( $button_text && $button_url ){ 
            $button = '<li><a href="' . esc_url( $button_url ). '" class="btn-donate">' . esc_html( $button_text ) . '</a></li>';
        }
        
        $menu = $menu . $button;               
    }
       
    return $menu; 
}
endif;

if( ! function_exists( 'benevolent_pro_ajax_search' ) ) :
/**
 * AJAX Search results
 */ 
function benevolent_pro_ajax_search() {
    $query = $_REQUEST['q']; // It goes through esc_sql() in WP_Query
    $search_query = new WP_Query( array( 's' => $query, 'posts_per_page' => 3, 'post_status' => 'publish' )); 
    $search_count = new WP_Query( array( 's' => $query, 'posts_per_page' => -1, 'post_status' => 'publish' ));
    $search_count = $search_count->post_count;
    if ( !empty( $query ) && $search_query->have_posts() ) : 
        
        echo '<ul class="ajax-search-results">';
        while ( $search_query->have_posts() ) : $search_query->the_post(); ?>
        <li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>   
        <?php
        endwhile;
        echo '</ul>';
        
        echo '<div class="ajax-search-meta"><span class="results-count">'.$search_count.' '.__( 'Results', 'benevolent-pro' ).'</span><a href="'.get_search_link( $query ).'" class="results-link">'.__( 'Show all results.', 'benevolent-pro' ).'</a></div>';
    else:
        echo '<div class="no-results">'.__( 'No results found.', 'benevolent-pro' ).'</div>';
    endif;
    
    wp_die(); // this is required to terminate immediately and return a proper response
}
endif;

if( ! function_exists( 'benevolent_pro_exclude_cat' ) ) :
/**
 * Exclude post with Category from blog and archive page. 
*/
function benevolent_pro_exclude_cat( $query ){
    $cat = get_theme_mod( 'benevolent_pro_exclude_categories' );
    
    if( $cat && ! is_admin() && $query->is_main_query() ){
        $cat = array_diff( array_unique( $cat ), array('') );
        if( $query->is_home() || $query->is_archive() ) {
			$query->set( 'category__not_in', $cat );
		}
    }    
}
endif;

if( ! function_exists( 'benevolent_pro_custom_category_widget' ) ) :
/** 
 * Exclude Categories from Category Widget 
*/ 
function benevolent_pro_custom_category_widget( $arg ) {
	$cat = get_theme_mod( 'benevolent_pro_exclude_categories' );
    
    if( $cat ){
        $cat = array_diff( array_unique( $cat ), array('') );
        $arg["exclude"] = $cat;
    }
	return $arg;
}
endif;

if( ! function_exists( 'benevolent_pro_exclude_posts_from_recentPostWidget_by_cat' ) ) :
/**
 * Exclude post from recent post widget of excluded catergory
 * 
 * @link http://blog.grokdd.com/exclude-recent-posts-by-category/
*/
function benevolent_pro_exclude_posts_from_recentPostWidget_by_cat( $arg ){
    
    $cat = get_theme_mod( 'benevolent_pro_exclude_categories' );
   
    if( $cat ){
        $cat = array_diff( array_unique( $cat ), array('') );
        $arg["category__not_in"] = $cat;
    }
    
    return $arg;   
}
endif;

if( ! function_exists( 'benevolent_pro_allowed_social_protocols' ) ) :
/**
 * List of allowed social protocols in HTML attributes.
 * @param  array $protocols Array of allowed protocols.
 * @return array
 */
function benevolent_pro_allowed_social_protocols( $protocols ) {
    $social_protocols = array(
        'skype'
    );
    return array_merge( $protocols, $social_protocols );    
}
endif;

/**
 * Load theme updater functions.
 * Action is used so that child themes can easily disable.
 */
function benevolent_pro_theme_updater() {
    require( get_template_directory() . '/updater/theme-updater.php' );
}