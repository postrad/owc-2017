<?php
/**
 * Custom template tags for this theme.
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package Benevolent_Pro
 */

if( ! function_exists( 'benevolent_pro_doctype_cb' ) ) :
/**
 * Doctype Declaration
*/
function benevolent_pro_doctype_cb(){
    ?>
    <!DOCTYPE html>
    <html <?php language_attributes(); ?>>
    <?php
}
endif;

if( ! function_exists( 'benevolent_pro_head' ) ) :
/**
 * Before wp_head
*/
function benevolent_pro_head(){
    ?>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="http://gmpg.org/xfn/11">
    <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
    <?php
}
endif;

if( ! function_exists( 'benevolent_pro_fb_page_box' ) ) :
/**
 * Callback to add Facebook Page Plugin JS
*/
function benevolent_pro_fb_page_box(){
    if( is_active_widget( false, false, 'benevolent_pro_facebook_page_widget' ) ){ ?>
        <div id="fb-root"></div>
        <script>(function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.4";
        fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));</script>
    <?php }
}
endif;

if( ! function_exists( 'benevolent_pro_page_start' ) ) :
/**
 * Page Start
*/
function benevolent_pro_page_start(){
    ?>
    <div id="page" class="site">
    <?php
}
endif;

if( ! function_exists( 'benevolent_pro_dynamic_header' ) ) :
/**
 * Dynamic Header 
*/
function benevolent_pro_dynamic_header(){
    
    $header_array = array( 'one', 'two', 'three', 'four', 'five' );
    $header = get_theme_mod( 'benevolent_pro_header_layout', 'one' );
    if( in_array( $header, $header_array ) ){            
        get_template_part( 'header/' . $header );
    }
    
}
endif;

if( ! function_exists( 'benevolent_pro_slider' ) ) : 
/**
 * Callback for Banner Slider 
 */
function benevolent_pro_slider(){

    if( is_front_page() && get_theme_mod( 'benevolent_pro_ed_slider' ) ){
    
        $slider_caption    = get_theme_mod( 'benevolent_pro_slider_caption', '1' );
        $slider_type       = get_theme_mod( 'benevolent_pro_slider_type', 'post' ); 
        $slider_post_one   = get_theme_mod( 'benevolent_pro_slider_post_one' );
        $slider_post_two   = get_theme_mod( 'benevolent_pro_slider_post_two' );
        $slider_post_three = get_theme_mod( 'benevolent_pro_slider_post_three' );
        $slider_post_four  = get_theme_mod( 'benevolent_pro_slider_post_four' );
        $slider_post_five  = get_theme_mod( 'benevolent_pro_slider_post_five' );
        $slider_cat        = get_theme_mod( 'benevolent_pro_slider_cat' );
        $slider_slides     = get_theme_mod( 'benevolent_pro_slider_slides' );
        $slider_readmore   = get_theme_mod( 'benevolent_pro_slider_readmore', __( 'Learn More', 'benevolent-pro' ) );
        $slider_full_img   = get_theme_mod( 'benevolent_pro_slider_full_image' );
        
        $slider_posts      = array( $slider_post_one, $slider_post_two, $slider_post_three, $slider_post_four, $slider_post_five );
        $slider_posts      = array_diff( array_unique( $slider_posts ), array('') );
        
        if( $slider_full_img ){
            $img_size = 'full';
        }else{
            $img_size = 'benevolent-pro-slider';
        }
                
        if( $slider_type == 'post' || $slider_type == 'cat' ){
            
            if( $slider_type == 'post' && $slider_posts ){
                $qry = new WP_Query ( array( 
                    'post_type'           => array( 'post', 'page' ),
                    'post_status'         => 'publish',
                    'posts_per_page'      => -1,                    
                    'post__in'            => $slider_posts, 
                    'orderby'             => 'post__in',
                    'ignore_sticky_posts' => true
                ) );
                
                if( $qry->have_posts() ){?>
                    <div class="banner">
                        <div class="lightslider">
                            <ul id="banner-slider">
                            <?php
                            while( $qry->have_posts() ){
                                $qry->the_post();
                                $image = wp_get_attachment_image_src( get_post_thumbnail_id(), $img_size );
                            ?>
                                <?php if( has_post_thumbnail() ){?>
                                <li>
                                    <a href="<?php the_permalink(); ?>"><img src="<?php echo esc_url( $image[0] ); ?>" alt="<?php the_title_attribute(); ?>" /></a>
                                    <?php if( $slider_caption ){ ?>
                				    <div class="banner-text">
                						<div class="container">
                							<div class="text">                								
                								<strong class="main-title"><?php the_title(); ?></strong>
                                                <?php 
                                                    if( has_excerpt() ){
                                                        the_excerpt();    
                                                    }else{
                                                        echo wpautop( wp_kses_post( force_balance_tags( benevolent_pro_excerpt( get_the_content(), 50, '...', false, false ) ) ) );
                                                    }  
                                                ?>
                                                <a class="btn-more" href="<?php the_permalink(); ?>"><?php echo esc_html( $slider_readmore );?></a>
                							</div>
                						</div>
                					</div>
                                    <?php } ?>
                                </li>
                                <?php } ?>
                            <?php
                            }
                            ?>
                            </ul>
                        </div>
                    </div>
                    <?php
                }else{
                    echo '<div class="banner"></div>';
                }
                wp_reset_postdata();       
            } //end of post slider
            
            if( $slider_type == 'cat' && $slider_cat ){
                $qry = new WP_Query ( array( 
                    'post_type'           => 'post', 
                    'post_status'         => 'publish',
                    'posts_per_page'      => -1,                    
                    'cat'                 => $slider_cat,
                    'ignore_sticky_posts' => true
                ) );
                
                if( $qry->have_posts() ){?>
                    <div class="banner">
                        <div class="lightslider">
                            <ul id="banner-slider">
                            <?php
                            while( $qry->have_posts() ){
                                $qry->the_post();
                                $image = wp_get_attachment_image_src( get_post_thumbnail_id(), $img_size );
                            ?>
                                <?php if( has_post_thumbnail() ){?>
                                <li>
                                    <a href="<?php the_permalink(); ?>"><img src="<?php echo esc_url( $image[0] ); ?>" alt="<?php the_title_attribute(); ?>" /></a>
                                    <?php if( $slider_caption ){ ?>
                				    <div class="banner-text">
                						<div class="container">
                							<div class="text">                								
                								<strong class="main-title"><?php the_title(); ?></strong>
                                                <?php 
                                                    if( has_excerpt() ){
                                                        the_excerpt();    
                                                    }else{
                                                        echo wpautop( wp_kses_post( force_balance_tags( benevolent_pro_excerpt( get_the_content(), 50, '...', false, false ) ) ) );
                                                    }  
                                                ?>
                                                <a class="btn-more" href="<?php the_permalink(); ?>"><?php echo esc_html( $slider_readmore );?></a>
                							</div>
                						</div>
                					</div>
                                    <?php } ?>
                                </li>
                                <?php } ?>
                            <?php
                            }
                            ?>
                            </ul>
                        </div>
                    </div>
                    <?php
                }else{
                    echo '<div class="banner"></div>';
                }
                wp_reset_postdata();       
            }//end of cat slider   
            
        }elseif( $slider_type == 'custom' && $slider_slides ){ //end of post and cat slider ?>
            <div class="banner">
                <div class="lightslider">
                    <ul id="banner-slider">
                    <?php
                    foreach( $slider_slides as $slides ){
                        if( $slides['thumbnail'] ){
                            $image = wp_get_attachment_image_src( $slides['thumbnail'], $img_size );
                            if( $image ){
                            ?>
                            <li>
                                <?php if( $slides['link'] ) echo '<a href="' . esc_url( $slides['link'] ) . '">'; ?>
                                <img src="<?php echo esc_url( $image[0] ); ?>" alt="<?php esc_attr( $slides['title'] ); ?>" />
                				<?php if( $slides['link'] ) echo '</a>'; ?>
                                <?php if( $slider_caption && ( $slides['title'] || ( $slides['link'] && $slider_readmore ) ) ){ ?>
                                <div class="banner-text">
                					<div class="container">
                                        <div class="text">
                    						<?php 
                                            if( $slides['title'] ) echo '<strong class="main-title">' . esc_html( $slides['title'] ) . '</strong>';
                    						if( $slides['content'] ) echo wpautop( wp_kses_post( $slides['content'] ) );
                                            if( $slides['link'] && $slider_readmore ){ ?>
                                            <a href="<?php echo esc_url( $slides['link'] ); ?>" class="btn-more"><?php echo esc_html( $slider_readmore ); ?></a>
                                            <?php }?>
                    					</div>
                                    </div>
                				</div>                                
                                <?php }?>
                            </li>
                            <?php        
                            }        
                        }
                    }
                    ?>
                    </ul>
                </div>
            </div>
            <?php
        }else{
            echo '<div class="banner"></div>';
        } // end of custom slider  
        
    }
   
}
endif;

if( ! function_exists( 'benevolent_pro_breadcrumb' ) ) :
/**
 * Custom Bread Crumb
 *
 * @link http://www.qualitytuts.com/wordpress-custom-breadcrumbs-without-plugin/
 */
function benevolent_pro_breadcrumb() {
    
    if( get_theme_mod( 'benevolent_pro_ed_breadcrumb' ) && ! is_404() ){ 
        
        global $post;
        
        $post_page   = get_option( 'page_for_posts' ); //The ID of the page that displays posts.
        $show_front  = get_option( 'show_on_front' ); //What to show on the front page
        $showOnHome  = 0; // 1 - show breadcrumbs on the homepage, 0 - don't show
        $delimiter   = get_theme_mod( 'benevolent_pro_breadcrumb_separator', __( '>', 'benevolent-pro' ) ); // delimiter between crumbs
        $home        = get_theme_mod( 'benevolent_pro_breadcrumb_home_text', __( 'Home', 'benevolent-pro' ) ); // text for the 'Home' link
        $showCurrent = get_theme_mod( 'benevolent_pro_ed_current', '1' ); // 1 - show current post/page title in breadcrumbs, 0 - don't show
        $before      = '<span class="current">'; // tag before the current crumb
        $after       = '</span>'; // tag after the current crumb        
     
        if( is_front_page() ){
        
            if( $showOnHome == 1 ) echo '<div id="crumbs"><div class="container"><a href="' . esc_url( home_url() ) . '">' . esc_html( $home ) . '</a></div></div>';
        
        }else{
     
            echo '<div id="crumbs"><div class="container"><a href="' . esc_url( home_url() ) . '">' . esc_html( $home ) . '</a> ';
            
            if( is_home() ){
                
                if( $showCurrent == 1 ) echo esc_html( $delimiter ) . ' ' . $before . esc_html( single_post_title( '', false ) ) . $after;
                              
            }elseif( is_category() ){
                
                $thisCat    = get_category( get_query_var( 'cat' ), false );
                
                if( $show_front === 'page' && $post_page ){ //If static blog post page is set
                    $p = get_post( $post_page );
                    echo esc_html( $delimiter ) . ' <a href="' . esc_url( get_permalink( $post_page ) ) . '">' . esc_html( $p->post_title ) . '</a> ';  
                }      
                
                if ( $thisCat->parent != 0 ) echo get_category_parents( $thisCat->parent, TRUE, ' ' . $delimiter . ' ' );
                if ( $showCurrent == 1 ) echo esc_html( $delimiter ) . ' ' . $before .  esc_html( single_cat_title( '', false ) ) . $after;
                
         
            }elseif( is_woocommerce_activated() && ( is_product_category() || is_product_tag() ) ){ //For Woocommerce archive page
        
                $current_term = $GLOBALS['wp_query']->get_queried_object();
                if( is_product_category() ){
                    $ancestors = get_ancestors( $current_term->term_id, 'product_cat' );
                    $ancestors = array_reverse( $ancestors );
            		foreach ( $ancestors as $ancestor ) {
            			$ancestor = get_term( $ancestor, 'product_cat' );    
            			if ( ! is_wp_error( $ancestor ) && $ancestor ) {
            				echo esc_html( $delimiter ) . ' <a href="' . esc_url( get_term_link( $ancestor ) ) . '">' . esc_html( $ancestor->name ) . '</a> ';
            			}
            		}
                }           
                if ( $showCurrent == 1 ) echo esc_html( $delimiter ) . ' ' . $before . esc_html( $current_term->name ) . $after;
                
            } elseif( is_woocommerce_activated() && is_shop() ){ //Shop Archive page
                if ( get_option( 'page_on_front' ) == wc_get_page_id( 'shop' ) ) {
        			return;
        		}
        		$_name = wc_get_page_id( 'shop' ) ? get_the_title( wc_get_page_id( 'shop' ) ) : '';
        
        		if ( ! $_name ) {
        			$product_post_type = get_post_type_object( 'product' );
        			$_name = $product_post_type->labels->singular_name;
        		}
                if ( $showCurrent == 1 ) echo esc_html( $delimiter ) . ' ' . $before . esc_html( $_name ) . $after;
                
            }elseif( is_tag() ){
                
                if ( $showCurrent == 1 ) echo esc_html( $delimiter ) . ' ' . $before . esc_html( single_tag_title( '', false ) ) . $after;
         
            }elseif( is_author() ){
                
                global $author;
                $userdata = get_userdata( $author );
                if ( $showCurrent == 1 ) echo esc_html( $delimiter ) . ' ' . $before . esc_html( $userdata->display_name ) . $after;
         
            }elseif( is_search() ){
                
                if ( $showCurrent == 1 ) echo esc_html( $delimiter ) . ' ' . $before . esc_html__( 'Search Result', 'benevolent-pro' ) . $after;
         
            }elseif( is_day() ){
                
                echo esc_html( $delimiter ) . ' <a href="' . esc_url( get_year_link( get_the_time('Y') ) ) . '">' . esc_html( get_the_time('Y') ) . '</a> ';
                echo esc_html( $delimiter ) . ' <a href="' . esc_url( get_month_link( get_the_time('Y'), get_the_time('m') ) ) . '">' . esc_html( get_the_time('F') ) . '</a> ';
                if ( $showCurrent == 1 ) echo esc_html( $delimiter ) . ' ' .  $before . esc_html( get_the_time('d') ) . $after;
         
            }elseif( is_month() ){
                
                echo esc_html( $delimiter ) . ' <a href="' . esc_url( get_year_link( get_the_time('Y') ) ) . '">' . esc_html( get_the_time('Y') ) . '</a> ';
                if ( $showCurrent == 1 ) echo esc_html( $delimiter ) . ' ' . $before . esc_html( get_the_time('F') ) . $after;
         
            }elseif( is_year() ){
                
                if ( $showCurrent == 1 ) echo esc_html( $delimiter ) . ' ' . $before . esc_html( get_the_time('Y') ) . $after;
         
            }elseif( is_single() && !is_attachment() ){
                
                if( is_woocommerce_activated() && 'product' === get_post_type() ){ //For Woocommerce single product
            		/** NEED TO CHECK THIS PORTION WHILE INTEGRATION WITH WOOCOMMERCE */
                    if ( $terms = wc_get_product_terms( $post->ID, 'product_cat', array( 'orderby' => 'parent', 'order' => 'DESC' ) ) ) {
            			$main_term = apply_filters( 'woocommerce_breadcrumb_main_term', $terms[0], $terms );
            			$ancestors = get_ancestors( $main_term->term_id, 'product_cat' );
                        $ancestors = array_reverse( $ancestors );
                		foreach ( $ancestors as $ancestor ) {
                			$ancestor = get_term( $ancestor, 'product_cat' );    
                			if ( ! is_wp_error( $ancestor ) && $ancestor ) {
                				echo esc_html( $delimiter ) . ' <a href="' . esc_url( get_term_link( $ancestor ) ) . '">' . esc_html( $ancestor->name ) . '</a> ';
                			}
                		}
            			echo esc_html( $delimiter ) . ' <a href="' . esc_url( get_term_link( $main_term ) ) . '">' . esc_html( $main_term->name ) . '</a> ';
            		}
                    
                    if ( $showCurrent == 1 ) echo esc_html( $delimiter ) . ' ' . $before . esc_html( get_the_title() ) . $after;
                    
                }elseif ( get_post_type() != 'post' ) { //For Custom Post Type
                    
                    if( ( get_post_type() != 'team' ) && ( get_post_type() != 'testimonial' ) && ( get_post_type() != 'logo' ) ){ //excluding archive for our CPTs.
                        $post_type = get_post_type_object( get_post_type() );
                        $slug = $post_type->rewrite;
                        echo esc_html( $delimiter ) . ' <a href="' . esc_url( home_url( '/' . $slug['slug'] . '/' ) ) . '">' . esc_html( $post_type->labels->singular_name ) . '</a> ';
                    }
                    
                    if ( $showCurrent == 1 ) echo esc_html( $delimiter ) . ' ' . $before . esc_html( get_the_title() ) . $after;
                    
                } else { //For Post
                    
                    $cat_object       = get_the_category();
                    $potential_parent = 0;
                    
                    if( $show_front === 'page' && $post_page ){ //If static blog post page is set
                        $p = get_post( $post_page );
                        echo esc_html( $delimiter ) . ' <a href="' . esc_url( get_permalink( $post_page ) ) . '">' . esc_html( $p->post_title ) . '</a> ';  
                    }
                    
                    if( is_array( $cat_object ) ){ //Getting category hierarchy if any
            
            			//Now try to find the deepest term of those that we know of
            			$use_term = key( $cat_object );
            			foreach( $cat_object as $key => $object )
            			{
            				//Can't use the next($cat_object) trick since order is unknown
            				if( $object->parent > 0  && ( $potential_parent === 0 || $object->parent === $potential_parent ) ){
            					$use_term = $key;
            					$potential_parent = $object->term_id;
            				}
            			}
                        
            			$cat = $cat_object[$use_term];
                  
                        $cats = get_category_parents( $cat, TRUE, ' ' . esc_html( $delimiter ) . ' ' );
                        if ( $showCurrent == 0 ) $cats = preg_replace( "#^(.+)\s$delimiter\s$#", "$1", $cats );
                        echo $delimiter . ' ' . $cats;
                    }
        
                    if ( $showCurrent == 1 ) echo $before . esc_html( get_the_title() ) . $after;
                }
            
            }elseif( !is_single() && !is_page() && get_post_type() != 'post' && !is_404() ){
                
                $post_type = get_post_type_object(get_post_type());
                echo esc_html( $delimiter ) . ' ' . $before . esc_html( $post_type->labels->singular_name ) . $after;
         
            }elseif ( is_attachment() ){
                
                $parent = get_post( $post->post_parent );
                $cat = get_the_category( $parent->ID );
                if( $cat ){
                    $cat = $cat[0];
                    echo esc_html( $delimiter ) . ' ' . get_category_parents( $cat, TRUE, ' ' . $delimiter . ' ' );
                    echo '<a href="' . esc_url( get_permalink( $parent ) ) . '">' . esc_html( $parent->post_title ) . '</a>';
                }
                if ( $showCurrent == 1 ) echo ' ' . $delimiter . ' ' . $before . esc_html( get_the_title() ) . $after;
         
            } elseif ( is_page() && !$post->post_parent ) {
                
                if ( $showCurrent == 1 ) echo esc_html( $delimiter ) . ' ' . $before . esc_html( get_the_title() ) . $after;
         
            } elseif ( is_page() && $post->post_parent ) {
                
                $parent_id  = $post->post_parent;
                $breadcrumbs = array();
                
                while( $parent_id ){
                    $page = get_page( $parent_id );
                    $breadcrumbs[] = esc_html( $delimiter ) . ' <a href="' . esc_url( get_permalink( $page->ID ) ) . '">' . esc_html( get_the_title( $page->ID ) ) . '</a> ';
                    $parent_id  = $page->post_parent;
                }
                $breadcrumbs = array_reverse( $breadcrumbs );
                for( $i = 0; $i < count( $breadcrumbs ); $i++ ){
                    echo $breadcrumbs[$i];
                }
                if ( $showCurrent == 1 ) echo esc_html( $delimiter ) . ' ' . $before . esc_html( get_the_title() ) . $after;
         
            } 
            
            if ( get_query_var('paged') && ( $showCurrent == 1 ) ) echo __( ' (Page', 'benevolent-pro' ) . ' ' . get_query_var('paged') . __( ')', 'benevolent-pro' );
         
            echo '</div></div>';
     
        }
    }
} // end benevolent_pro_breadcrumb()
endif;

if( ! function_exists( 'benevolent_pro_content_start' ) ) :
/**
 * Content Start
*/
function benevolent_pro_content_start(){
    
    if( ! is_page_template( array( 'templates/template-home.php', 'templates/template-about.php', 'templates/template-service.php', 'templates/template-team.php', 'templates/template-testimonial.php' ) ) ){ ?>
        <div class="container">
            <?php if( ! is_page_template( 'templates/template-contact.php' ) ){ ?>
            <div id="content" class="site-content">
                <div class="row">
                <?php                
            }                       
    }
}
endif;

if( ! function_exists( 'benevolent_pro_content_end' ) ) :
/**
 * Content End
*/
function benevolent_pro_content_end(){
    if( ! is_page_template( array( 'templates/template-home.php', 'templates/template-about.php', 'templates/template-service.php', 'templates/template-team.php', 'templates/template-testimonial.php' ) ) ){
        
        if( ! is_page_template( 'templates/template-contact.php' ) ){ ?>
                </div><!-- .row -->
            </div><!-- #content -->
            <?php } ?>
        </div><!-- .container -->
    <?php    
    }
}
endif;

if( ! function_exists( 'benevolent_pro_footer_start' ) ) :
/**
 * Footer Start
*/
function benevolent_pro_footer_start(){
    ?>
    <footer id="colophon" class="site-footer" role="contentinfo">
    <?php
}
endif;

if( ! function_exists( 'benevolent_pro_footer_top' ) ) :
/**
 * Footer Top
*/
function benevolent_pro_footer_top(){
    if( is_active_sidebar( 'footer-one' ) || is_active_sidebar( 'footer-two' ) || is_active_sidebar( 'footer-three' ) || is_active_sidebar( 'footer-four' ) ){ ?>
    <div class="container">
		<div class="footer-t">
			<div class="row">
					<?php if( is_active_sidebar( 'footer-one' ) ){ ?>
					<div class="column">
					   <?php dynamic_sidebar( 'footer-one' ); ?>	
					</div>
                <?php } ?>
				
                <?php if( is_active_sidebar( 'footer-two' ) ){ ?>
                    <div class="column">
					   <?php dynamic_sidebar( 'footer-two' ); ?>	
					</div>
                <?php } ?>
                
                <?php if( is_active_sidebar( 'footer-three' ) ){ ?>
                    <div class="column">
					   <?php dynamic_sidebar( 'footer-three' ); ?>	
					</div>
                <?php } ?>
                
                <?php if( is_active_sidebar( 'footer-four' ) ){ ?>
                    <div class="column">
					   <?php dynamic_sidebar( 'footer-four' ); ?>	
					</div>
                <?php } ?>
				</div>
		</div>
	</div>
    <?php 
    } 
}
endif;

if( ! function_exists( 'benevolent_pro_footer_credit' ) ) :
/**
 * Footer Credits 
*/
function benevolent_pro_footer_credit(){
    
    $footer_copyright = get_theme_mod( 'benevolent_pro_footer_copyright' );
    $ed_author_link   = get_theme_mod( 'benevolent_pro_ed_author_link' );
    $ed_wp_link       = get_theme_mod( 'benevolent_pro_ed_wp_link' );
    
    $text  = '<div class="site-info"><div class="container">';
    
    if( $footer_copyright ){
        $text .= '<span class="copyright">' .wp_kses_post( $footer_copyright ) . '</span>';
    }else{
        $text .= '<span class="copyright">';
        $text .=  esc_html__( '&copy; ', 'benevolent-pro' ) . esc_html( date_i18n('Y') ); 
        $text .= ' <a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html( get_bloginfo( 'name' ) ) . '</a>.</span>';
    }
    
    if( ! $ed_author_link || ! $ed_wp_link ) $text .= '<span class="by">';
    
    if( ! $ed_author_link ){
        $text .= '<a href="' . esc_url( 'http://raratheme.com/wordpress-themes/benevolent-pro/' ) .'" rel="author" target="_blank">' . esc_html__( 'Benevolent Pro by Rara Theme', 'benevolent-pro' ) . '</a>. ';
    }
    
    if( ! $ed_wp_link ){
        $text .= sprintf( esc_html__( 'Powered by: %s', 'benevolent-pro' ), '<a href="'. esc_url( __( 'https://wordpress.org/', 'benevolent-pro' ) ) .'" target="_blank">WordPress</a>' );
    }
    
    if( ! $ed_author_link || ! $ed_wp_link ) $text .= '</span>';
    
    $text .= '</div></div>';
    
    echo apply_filters( 'benevolent_pro_footer_text', $text );        
        
}
endif;

if( ! function_exists( 'benevolent_pro_footer_end' ) ) :
/**
 * Footer End
*/
function benevolent_pro_footer_end(){
    ?>
    </footer><!-- #colophon -->
    <?php
}
endif;

if( ! function_exists( 'benevolent_pro_back_to_top' ) ) :
/**
 * Back to Top
*/
function benevolent_pro_back_to_top(){
    ?>
    <div id="rara-top"><i class="fa fa-angle-up"></i></div>
    <?php
}
endif;

if( ! function_exists( 'benevolent_pro_page_end' ) ) :
/**
 * Page End
*/
function benevolent_pro_page_end(){
    ?>
    </div><!-- #page -->
    <?php
}
endif;