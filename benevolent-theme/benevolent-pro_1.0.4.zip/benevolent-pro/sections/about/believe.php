<?php
/**
 * We Believe Section
 * 
 * @package Benevolent_Pro
 */

$title   = get_theme_mod( 'benevolent_pro_believe_section_title' );
$content = get_theme_mod( 'benevolent_pro_believe_section_content' ); 

if( $title || $content ){ ?>

    <section class="our-believe">
    	<div class="container">
    		
            <?php 
            
                if( $title ) echo '<header class="heading"><h2 class="main-title">' . esc_html( $title ) . '</h2></header>';
                
                if( $content ){
                    echo '<div class="text-holder">' . wpautop( wp_kses_post( $content ) ) . '</div>';
                }
                
            ?>
            
    	</div>
    </section>

<?php
}