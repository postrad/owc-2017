<?php
/**
 * Current Project Section
 * 
 * @package Benevolent_Pro
 */

$title      = get_theme_mod( 'benevolent_pro_current_project_section_title' );
$post_one   = get_theme_mod( 'benevolent_pro_current_project_one' );
$post_two   = get_theme_mod( 'benevolent_pro_current_project_two' );
$post_three = get_theme_mod( 'benevolent_pro_current_project_three' );

$current_posts = array( $post_one, $post_two, $post_three );
$current_posts = array_diff( array_unique( $current_posts ), array('') );

if( $title || $current_posts ){ ?>

<section class="current-project">
	<div class="container">
		
        <?php
        
            if( $title ) echo '<header class="heading"><h2 class="main-title">' . esc_html( $title ) . '</h2></header>';
            
            $qry = new WP_Query ( array( 
                'post_type'           => 'post',
                'post_status'         => 'publish',
                'posts_per_page'      => -1,                    
                'post__in'            => $current_posts, 
                'orderby'             => 'post__in',
                'ignore_sticky_posts' => true
            ) );
            
            if( $current_posts && $qry->have_posts() ){ ?>            
                <div class="row">
                    <?php
                    while( $qry->have_posts() ){
                        $qry->the_post();
                        ?>
            			<div class="col">
            				<div class="post">
            					<?php if( has_post_thumbnail() ){ ?>
                                <a href="<?php the_permalink(); ?>" class="post-thumbnail"><?php the_post_thumbnail( 'benevolent-pro-blog' ); ?></a>
            					<?php }?>
                                <header class="entry-header">
            						<h2 class="entry-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
            					</header>
            					<div class="entry-content">
            						<?php 
                                        if( has_excerpt() ){
                                            the_excerpt();        
                                        }else{
                                            echo wpautop( wp_kses_post( force_balance_tags( benevolent_pro_excerpt( get_the_content() ) ) ) );
                                        }
                                     ?>
            					</div>
            					<footer class="entry-footer">
            						<div class="btn-readmore"><a href="<?php the_permalink(); ?>"><?php _e( 'Read More', 'benevolent-pro' ); ?></a></div>
            					</footer>
            				</div>
            			</div>
                        <?php
                        }
                    ?>    			
        		</div>
                <?php
                wp_reset_postdata();
            }
        ?>
	</div>
</section>

<?php
}