<?php
/**
 * Intro Section Service Page
 * 
 * @package Benevolent_Pro
 */

$iframe = get_theme_mod( 'benevolent_pro_service_video_iframe' );
?>

<section class="services-intro">
	<div class="container">
		<h2 class="main-title"><?php the_title(); ?></h2>
		<div class="intro-content">
		
        	<div class="row">
				<?php if( $iframe ){ ?>
                <div class="video-holder">
                    <?php echo benevolent_pro_sanitize_iframe( $iframe ); ?>
                </div>
				<?php } ?>
                <div class="text-holder">
					<?php the_content(); ?>
				</div>
                
			</div>
		</div>
	</div>
</section>