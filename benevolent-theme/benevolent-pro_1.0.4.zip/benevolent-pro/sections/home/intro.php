<?php
/**
 * Intro Section
 * 
 * @package Benevolent_Pro
 */
 

$title   = get_theme_mod( 'benevolent_pro_intro_section_title' );
$content = get_theme_mod( 'benevolent_pro_intro_section_content' );
$img_one = get_theme_mod( 'benevolent_pro_intro_one_image' );
$img_two = get_theme_mod( 'benevolent_pro_intro_two_image' );
$img_thr = get_theme_mod( 'benevolent_pro_intro_three_image' );

$intros = array(
    'one'   => array(
        'image' => get_theme_mod( 'benevolent_pro_intro_one_image' ),
        'logo'  => get_theme_mod( 'benevolent_pro_intro_one_logo' ),
        'title' => get_theme_mod( 'benevolent_pro_intro_one_title' ),
        'link'  => get_theme_mod( 'benevolent_pro_intro_one_link_label' ),
        'url'   => get_theme_mod( 'benevolent_pro_intro_one_url' )
    ),
    'two'   => array(
        'image' => get_theme_mod( 'benevolent_pro_intro_two_image' ),
        'logo'  => get_theme_mod( 'benevolent_pro_intro_two_logo' ),
        'title' => get_theme_mod( 'benevolent_pro_intro_two_title' ),
        'link'  => get_theme_mod( 'benevolent_pro_intro_two_link_label' ),
        'url'   => get_theme_mod( 'benevolent_pro_intro_two_url' )
    ),
    'three' => array(
        'image' => get_theme_mod( 'benevolent_pro_intro_three_image' ),
        'logo'  => get_theme_mod( 'benevolent_pro_intro_three_logo' ),
        'title' => get_theme_mod( 'benevolent_pro_intro_three_title' ),
        'link'  => get_theme_mod( 'benevolent_pro_intro_three_link_label' ),
        'url'   => get_theme_mod( 'benevolent_pro_intro_three_url' )
    )
);

if( $img_one || $img_two || $img_thr || $title || $content ){ ?>

    <section class="intro"> 
        <div class="container">
        	<?php if( $title || $content ){ ?>
            <header class="header">
        		<?php 
                    if( $title ) echo '<h2 class="main-title">' . esc_html( $title ) . '</h2>'; 
                    if( $content ) echo wpautop( wp_kses_post( $content ) );
                ?>
        	</header>
            <?php } ?>
            
        	<div class="row">
        		<?php 
                    foreach( $intros as $intro ){
                        benevolent_pro_intro_helper( $intro['image'], $intro['logo'], $intro['title'], $intro['link'], $intro['url'] );
                    }
                 ?>
        	</div>
        </div>
    </section>

<?php
}