<?php
/**
 * CTA Section
 * 
 * @package Benevolent_Pro
 */
 
if( is_active_sidebar( 'cta' ) ){ 
?>

<section class="promotional-block">
	<?php dynamic_sidebar( 'cta' ); ?>    
</section>

<?php
}