<?php
/**
 * Sponsor Section
 * 
 * @package Benevolent_Pro
 */
 
$title   = get_theme_mod( 'benevolent_pro_sponsor_section_title' );
$content = get_theme_mod( 'benevolent_pro_sponsor_section_content' );
$cat     = get_theme_mod( 'benevolent_pro_sponsor_cat' );

benevolent_pro_logo_helper( $title, $content, $cat );