<?php
/**
 * Stats Section
 * 
 * @package Benevolent_Pro
 */
 
 
if( is_active_sidebar( 'stat-counter' ) ){ 
?>

<section class="stats">
    <div class="container">
    	<div class="row">
    		<?php dynamic_sidebar( 'stat-counter' ); ?>
    	</div>
    </div>
</section>

<?php
}