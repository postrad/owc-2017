<?php
/**
 * Community Section
 * 
 * @package Benevolent_Pro
 */
 
$title      = get_theme_mod( 'benevolent_pro_community_section_title' );
$post_one   = get_theme_mod( 'benevolent_pro_community_post_one' );
$post_two   = get_theme_mod( 'benevolent_pro_community_post_two' );
$post_three = get_theme_mod( 'benevolent_pro_community_post_three' );
$post_four  = get_theme_mod( 'benevolent_pro_community_post_four' );

$posts = array( $post_one, $post_two, $post_three, $post_four );
$posts = array_diff( array_unique( $posts ), array('') );

if( $title || $posts ){ ?>

<section class="our-community">
    
    <?php
        
        if( $title ) echo '<header class="header"><h2 class="main-title">' . esc_html( $title ) . '</h2></header>'; 
        
        $qry = new WP_Query( array( 
            'post_type'           => array( 'post', 'page' ),
            'posts_per_page'      => -1,
            'post__in'            => $posts,
            'orderby'             => 'post__in',
            'ignore_sticky_posts' => true
        ) );

        if( $posts && $qry->have_posts() ){
            echo '<div class="community-holder">';
            while( $qry->have_posts() ){
                $qry->the_post();
                if( has_post_thumbnail() ){
                ?>
                <div class="columns-2">
    				<?php the_post_thumbnail( 'benevolent-pro-community' ); ?>
    				<div class="text-holder">
                        <div class="table">
                            <div class="table-row">
                                <div class="table-cell">				
                                <strong class="title"><?php the_title(); ?></strong>
    				            <?php 
                                if( has_excerpt() ){ 
    				                the_excerpt();                                
                                }else{
                                    echo wpautop( wp_kses_post( force_balance_tags( benevolent_pro_excerpt( get_the_content(), 50, '...', false, false ) ) ) );    
                                } ?>
                                </div>
                            </div>
                        </div>
                    </div>
        			<div class="hover-state">
                        <div class="table">
                            <div class="table-row">
                                <div class="table-cell">
    				                <strong class="title"><?php the_title(); ?></strong>
    				                <?php 
                                    if( has_excerpt() ){ 
        				                the_excerpt();
                                    }else{
                                        echo wpautop( wp_kses_post( force_balance_tags( benevolent_pro_excerpt( get_the_content(), 50, '...', false, false ) ) ) );    
                                    } ?>
    				                <div class="btn-holder">
                                        <a href="<?php the_permalink(); ?>"><span class="fa fa-angle-right"></span></a>
                                    </div>    				                
    				            </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                }
            }
            wp_reset_postdata(); 
            echo '</div>';
        }
    ?>
    
    </section>
    
<?php
}			