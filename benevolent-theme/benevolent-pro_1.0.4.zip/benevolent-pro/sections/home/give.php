<?php
/**
 * Give Section
 * 
 * @package Benevolent_Pro
 */
 
$title          = get_theme_mod( 'benevolent_pro_give_section_title' );
$content        = get_theme_mod( 'benevolent_pro_give_section_content' );
$readmore       = get_theme_mod( 'benevolent_pro_give_button_label', __( 'Donate Now', 'benevolent-pro' ) );// From Customizer
$excerpt_char   = get_theme_mod( 'benevolent_pro_give_excerpt_char', 200 ); //From Customizer
$excerpt_option = give_get_option( 'disable_forms_excerpt' );
 
$qry = new WP_Query( array( 
    'post_type'           => 'give_forms',
    'post_status'         => 'publish',
    'posts_per_page'      => -1,
    'ignore_sticky_posts' => true,   
) );

if( $title || $content || $qry->have_posts() ){ ?>

    <section class="give-section">
        <?php
        if( $title || $content ){
        ?>
        <header class="header">
        	<div class="container">
        		<div class="heading">
        			<?php 
                        if( $title ) echo '<h2 class="main-title">' . esc_html( $title ) . '</h2>';
                        if( $content ) echo wpautop( wp_kses_post( $content ) ); 
                    ?>
        		</div>
        	</div>
        </header>
        <?php } 
        
        $total_posts = $qry->found_posts;
    
        if( $qry->have_posts() ){
        ?>    
        <div class="give-holder">
        	<div class="container">
        		<?php 
                    echo ( $total_posts > 3 ) ? '<ul class="give-slider">' : '<div class="row">'; 
                    
                    while( $qry->have_posts() ){
                        $qry->the_post();
                    
                        echo ( $total_posts > 3 ) ? '<li>' : '<div class="columns-3">'; ?>
                    
        				<div class="post">
                            <?php if( has_post_thumbnail() ){ ?>
        					<a href="<?php the_permalink(); ?>" class="post-thumbnail"><?php the_post_thumbnail( 'benevolent-pro-give' ); ?></a>
                            <?php } ?>
        					<div class="text-holder">
        						<header class="entry-header">
        							<h3 class="entry-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
        						</header>
        						<div class="entry-content">
        							<?php 
                                        
                                        if( $excerpt_option !== 'on' ){
                                            if( has_excerpt() ){
                                                the_excerpt();    
                                            }else{
                                                //Output the content
                                				$content_option = get_post_meta( $id, '_give_content_option', true );
                                				if ( $content_option != 'none' ) {
                                					$content = get_post_meta( $id, '_give_form_content', true );
                                					echo wpautop( wp_kses_post( force_balance_tags( benevolent_pro_excerpt( $content, $excerpt_char, '...', false, false ) ) ) );
                                				}
                                            }
                                        }
                                        
                                        //Output the goal
                        				$goal_option = get_post_meta( $id, '_give_goal_option', true );
                        				if ( $goal_option == 'yes' ) {
                        					$shortcode = '[give_goal id="' . $id . '"]';
                        					echo do_shortcode( $shortcode );
                        				}                                       
                                        
                                    ?>
        						</div>
        						<a href="<?php the_permalink(); ?>" class="btn-donate"><?php echo esc_html( $readmore ); ?></a>
        					</div>
        				</div>
                        <?php
                        echo ( $total_posts > 3 ) ? '</li>' : '</div>';
                    }
                    wp_reset_postdata();
                    
                echo ( $total_posts > 3 ) ? '</ul>' : '</div>'; 
                ?>    			
        	</div>
        </div>
        <?php 
        }
    ?>
    </section>
<?php    
}