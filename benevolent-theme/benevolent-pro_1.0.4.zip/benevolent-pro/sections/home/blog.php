<?php
/**
 * Blog Section
 * 
 * @package Benevolent_Pro
 */
 
$ed_bdate = get_theme_mod( 'benevolent_pro_ed_blog_date', '1' );
$title    = get_theme_mod( 'benevolent_pro_blog_section_title' );
$content  = get_theme_mod( 'benevolent_pro_blog_section_content' );
$readmore = get_theme_mod( 'benevolent_pro_blog_section_readmore', __( 'Read More', 'benevolent-pro' ) );
$cat      = get_theme_mod( 'benevolent_pro_exclude_categories' );

if( $cat ) $cat = array_diff( array_unique( $cat ), array('') );
 
$qry = new WP_Query( array( 
    'post_type'           => 'post',
    'post_status'         => 'publish',
    'posts_per_page'      => 3,
    'ignore_sticky_posts' => true,
    'category__not_in'    => $cat    
) );

if( $title || $content || $qry->have_posts() ){ ?>

    <section class="blog-section">
        <?php
        if( $title || $content ){
        ?>
        <header class="header">
        	<div class="container">
        		<div class="text">
        			<?php 
                        if( $title ) echo '<h2 class="main-title">' . esc_html( $title ) . '</h2>';
                        if( $content ) echo wpautop( wp_kses_post( $content ) );
                    ?>
        		</div>
        	</div>
        </header>
        <?php } 
    
    
        if( $qry->have_posts() ){
        ?>    
        <div class="blog-holder">
        	<div class="container">
        		<div class="row">
        			<?php
                    while( $qry->have_posts() ){
                        $qry->the_post();
                    ?>
                    <div class="columns-3">
        				<div class="post">
                            <?php if( has_post_thumbnail() ){ ?>
        					<a href="<?php the_permalink(); ?>" class="post-thumbnail"><?php the_post_thumbnail( 'benevolent-pro-blog' ); ?></a>
                            <?php } ?>
        					<div class="text-holder">
        						<header class="entry-header">
        							<h3 class="entry-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
        							<?php if( $ed_bdate ){ ?>
                                    <div class="entry-meta">
        								<span class="posted-on"><span class="fa fa-calendar-o"></span><a href="<?php the_permalink(); ?>"><?php echo esc_html( get_the_date() ); ?></a></span>
        							</div>
                                    <?php } ?>
        						</header>
        						<div class="entry-content">
        							<?php 
                                        if( has_excerpt() ){
                                            the_excerpt();        
                                        }else{
                                            echo wpautop( wp_kses_post( force_balance_tags( benevolent_pro_excerpt( get_the_content(), 100, '...', false, false ) ) ) );        
                                        }
                                    ?>
        						</div>
        						<a href="<?php the_permalink(); ?>" class="readmore"><?php echo esc_html( $readmore ); ?></a>
        					</div>
        				</div>
        			</div>
        			<?php
                    }
                    wp_reset_postdata();
                    ?>    			
        		</div>
        	</div>
        </div>
        <?php 
        }
    ?>
    </section>
<?php    
}