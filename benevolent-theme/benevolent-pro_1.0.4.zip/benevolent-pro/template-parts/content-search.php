<?php
/**
 * Template part for displaying results in search pages.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Benevolent_Pro
 */

$excerpt_char = get_theme_mod( 'benevolent_pro_post_no_of_char', 200 );
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<header class="entry-header">
		<?php the_title( sprintf( '<h2 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' ); ?>
	</header><!-- .entry-header -->

	<div class="entry-summary">
		<?php 
            if( has_excerpt() ){
                the_excerpt();        
            }else{
                echo wpautop( wp_kses_post( force_balance_tags( benevolent_pro_excerpt( get_the_content(), $excerpt_char, '...', false, false ) ) ) );        
            }
        ?>
	</div><!-- .entry-summary -->

</article><!-- #post-## -->