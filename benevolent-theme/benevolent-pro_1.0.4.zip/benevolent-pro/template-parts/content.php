<?php
/**
 * Template part for displaying posts.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Benevolent_Pro
 */

$blog_layout  = get_theme_mod( 'benevolent_pro_blog_layout', 'default' ); //From Customizer
$excerpt_char = get_theme_mod( 'benevolent_pro_post_no_of_char', 200 ); //From Customizer
$read_more    = get_theme_mod( 'benevolent_pro_post_read_more', __( 'Read More', 'benevolent-pro' ) ); //From Customizer
$img_size     = '';

if( $blog_layout == 'round' || $blog_layout == 'square' ){
    $img_size = 'benevolent-pro-featured-post';
}else{
    $img_size = benevolent_pro_sidebar( true ) ? 'benevolent-pro-with-sidebar' : 'benevolent-pro-without-sidebar';
}

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	
    <?php 
        if( has_post_thumbnail() ){
            echo '<a href="' . esc_url( get_the_permalink() ) . '" class="post-thumbnail">';
            the_post_thumbnail( $img_size );
            echo '</a>' ; 
        }
    ?>
    
    <div class="text-holder">
        <header class="entry-header">
    		<?php
    			
            the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );
    		
    		if ( 'post' === get_post_type() ) benevolent_pro_posted_on(); 
            
            ?>
    	</header><!-- .entry-header -->
        
        
    	<div class="entry-content">
    		<?php
    		
                if( false === get_post_format() ){
                    if( has_excerpt() ){
                        the_excerpt();    
                    }else{
                        echo wpautop( wp_kses_post( force_balance_tags( benevolent_pro_excerpt( get_the_content(), $excerpt_char, '...', false, false ) ) ) );  
                    }
                }else{
                    the_content( sprintf(
        				/* translators: %s: Name of current post. */
        				wp_kses( __( 'Continue reading %s <span class="meta-nav">&rarr;</span>', 'benevolent-pro' ), array( 'span' => array( 'class' => array() ) ) ),
        				the_title( '<span class="screen-reader-text">"', '"</span>', false )
        			) );
                }
                
    			wp_link_pages( array(
    				'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'benevolent-pro' ),
    				'after'  => '</div>',
    			) );
    		?>
    	</div><!-- .entry-content -->
    
    	
        <footer class="entry-footer">
    		<a href="<?php the_permalink(); ?>" class="readmore"><?php echo esc_html( $read_more ); ?></a>
            <?php benevolent_pro_entry_footer(); ?>
    	</footer><!-- .entry-footer -->
        
    </div>
</article><!-- #post-## -->