<?php
/**
 * Template part for displaying posts.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Benevolent_Pro
 */
$blog_layout    = get_theme_mod( 'benevolent_pro_blog_layout', 'default' ); //From Customizer
$excerpt_char   = get_theme_mod( 'benevolent_pro_give_excerpt_char', 200 ); //From Customizer
$read_more      = get_theme_mod( 'benevolent_pro_give_button_label', __( 'Donate Now', 'benevolent-pro' ) ); //From Customizer
$id             = get_the_ID();
$excerpt_option = give_get_option( 'disable_forms_excerpt' );

if( $blog_layout == 'round' || $blog_layout == 'square' ){
    $img_size = 'benevolent-pro-featured-post';
}else{
    $img_size = benevolent_pro_sidebar( true ) ? 'benevolent-pro-with-sidebar' : 'benevolent-pro-without-sidebar';
}
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	
    <?php 
        if( has_post_thumbnail() ){
            echo '<a href="' . esc_url( get_the_permalink() ) . '" class="post-thumbnail">';
            the_post_thumbnail( $img_size );
            echo '</a>' ; 
        }
    ?>
    
    <div class="text-holder">
        <header class="entry-header">
    		<?php the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' ); ?>
    	</header><!-- .entry-header -->
        
        
    	<div class="entry-content">
    		<?php
    		  
                if( $excerpt_option !== 'on' ){
                    if( has_excerpt() ){
                        the_excerpt();    
                    }else{
                        //Output the content
        				$content_option = get_post_meta( $id, '_give_content_option', true );
        				if ( $content_option != 'none' ) {
        					$content = get_post_meta( $id, '_give_form_content', true );
        					echo wpautop( wp_kses_post( force_balance_tags( benevolent_pro_excerpt( $content, $excerpt_char, '...', false, false ) ) ) );
        				}
                    }
                }
                
                //Output the goal
				$goal_option = get_post_meta( $id, '_give_goal_option', true );
				if ( $goal_option == 'yes' ) {
					$shortcode = '[give_goal id="' . $id . '"]';
					echo do_shortcode( $shortcode );
				}
                
    		?>
    	</div><!-- .entry-content -->
    
    	
        <footer class="entry-footer">
    		<a href="<?php the_permalink(); ?>" class="btn-donate"><?php echo esc_html( $read_more ); ?></a>
            <?php benevolent_pro_entry_footer(); ?>
    	</footer><!-- .entry-footer -->
        
    </div>
</article><!-- #post-## -->