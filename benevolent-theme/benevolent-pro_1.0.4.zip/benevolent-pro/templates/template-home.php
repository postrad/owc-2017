<?php
/**
 * Template Name: Home Page
 *
 * @package Benevolent
 */

get_header(); 

    $sections = get_theme_mod( 'benevolent_pro_sort_homepage', array( 'intro', 'community', 'stat', 'give', 'blog', 'sponsor', 'cta' ) );
           
    foreach( $sections as $section ){
        if( $section == 'give' ){
            if( is_give_activated() ) get_template_part( 'sections/home/' . esc_attr( $section ) );
        }else{
            get_template_part( 'sections/home/' . esc_attr( $section ) );    
        }                
    }

get_footer();