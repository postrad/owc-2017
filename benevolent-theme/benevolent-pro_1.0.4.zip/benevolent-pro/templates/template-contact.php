<?php
/**
 * Template Name: Contact Page
 *
 * @package Benevolent
 */

get_header(); ?>

    <div class="site-content" id="content">
        <div class="row">
        	
            <div id="primary" class="content-area">
        		<main id="main" class="site-main" role="main">
        
        			<?php
        			while ( have_posts() ) : the_post();
        
        				get_template_part( 'template-parts/content', 'page' );
        
        			endwhile; // End of the loop.
                    
        			?>
        
        		</main><!-- #main -->
        	</div><!-- #primary -->
            
            <?php get_sidebar(); ?>
            
            
        </div><!-- .row -->
        
        <div id="map" class="map-holder"></div> <!-- GOOGLE MAP HOLDER -->
        
    </div><!-- .site-content -->
    
<?php
get_footer();