<?php
/**
 * Template Name: Testimonial Page
 *
 * @package Benevolent
 */

get_header(); 

    while ( have_posts() ) : the_post();
?>
	<div class="inner-page">
        <div class="container">
    		<h2 class="main-title"><?php the_title(); ?></h2>
            <div class="entry-content"><?php the_content(); ?></div>
            
            <?php
                $args = array(
                    'post_type'      => 'testimonial',
                    'post_status'    => 'publish',
                    'posts_per_page' => -1
                );
                
                $qry = new WP_Query( $args );
                
                if( $qry->have_posts() ){ ?>
        			<div class="testimonial-holder">
        				<?php 
                        while( $qry->have_posts() ){ 
        				    $qry->the_post();
                            $designation = get_post_meta( get_the_ID(), '_benevolent_pro_testimonial_designation', true );                            
                            ?>
                            <div class="testimonial">
            					<?php if( has_post_thumbnail() ){ ?>
                                <div class="img-holder"><?php the_post_thumbnail( 'benevolent-pro-testimonial' ); ?></div>
                                <?php } ?>
            					<div class="testimonial-content">
            						 <div class="entry-content"><?php the_content(); ?></div>
            						 <div class="cite">
            						 	<strong class="name"><?php the_title(); ?></strong>
            						 	<span class="designation"><?php echo esc_html( $designation ); ?></span>
            						 </div>
            					</div>
            				</div>
            				<?php 
                            }
                        ?>
        			</div>
                    <?php
                    wp_reset_postdata();
                }
            ?>
    	</div>
    </div>
    
<?php        
    endwhile;
    
get_footer();