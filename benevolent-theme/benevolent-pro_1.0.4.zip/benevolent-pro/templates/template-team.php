<?php
/**
 * Template Name: Team Page
 *
 * @package Benevolent
 */

get_header(); 

    while ( have_posts() ) : the_post();
?>
    <div class="inner-page">
        <div class="container">
    		<h2 class="main-title"><?php the_title(); ?></h2>
            <div class="entry-content"><?php the_content(); ?></div>
    		
            <?php
                $args = array(
                    'post_type'      => 'team',
                    'post_status'    => 'publish',
                    'posts_per_page' => -1
                );
                
                $qry = new WP_Query( $args );
                
                if( $qry->have_posts() ){ ?>
                    <div class="team-holder">
        				<div class="row">
       					<?php
                            while( $qry->have_posts() ){
                                $qry->the_post();
                                $designation = get_post_meta( get_the_ID(), '_benevolent_pro_team_designation', true );    
                            ?>
                            <div class="col">
        						<div class="team-member">
        							<header class="heading">
        								<h3 class="team-title"><?php the_title(); ?></h3>
        								<span class="designation"><?php echo esc_html( $designation ); ?></span>
        							</header>
        							
                                    <?php if( has_post_thumbnail() ){ ?>
                                    <div class="img-holder"><?php the_post_thumbnail( 'benevolent-pro-team' ); ?></div>
        							<?php }?>
                                    
                                    <div class="team-content"><?php the_content(); ?></div>
        						</div>
        					</div>
        					<?php
                            }
                        ?>
        				</div>
        			</div>
                    <?php
                    wp_reset_postdata();
                }
            ?>
    	</div>
    </div>
	
<?php        
    endwhile;
    
get_footer();