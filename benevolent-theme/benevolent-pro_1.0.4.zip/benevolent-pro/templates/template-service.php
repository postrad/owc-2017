<?php
/**
 * Template Name: Service Page
 *
 * @package Benevolent
 */

get_header();
?>

<div class="inner-page">

    <?php
    while ( have_posts() ) : the_post();
    
        $sections = get_theme_mod( 'benevolent_pro_sort_servicepage', array( 'intro', 'services', 'cta', 'donor' ) );
               
        foreach( $sections as $section ){
            get_template_part( 'sections/service/' . esc_attr( $section ) );    
        }
    
    endwhile;
    ?>    

</div>

<?php        
get_footer();