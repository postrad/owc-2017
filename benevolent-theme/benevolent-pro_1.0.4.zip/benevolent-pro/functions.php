<?php
/**
 * Benevolent Pro functions and definitions.
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Benevolent_Pro 
 */

//define theme version
if ( !defined( 'BENEVOLENT_PRO_THEME_VERSION' ) ) {
	$theme_data = wp_get_theme();
	
	define ( 'BENEVOLENT_PRO_THEME_VERSION', $theme_data->get( 'Version' ) );
}

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/custom-functions.php';

/**
 * Custom template hooks for this theme.
 */
require get_template_directory() . '/inc/wp-hooks.php';

/**
 * Custom template functions for this theme.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Custom template hooks for this theme.
 */
require get_template_directory() . '/inc/template-hooks.php';

/**
 * Custom functions that act independently of the theme templates.
 */
require get_template_directory() . '/inc/extras.php';

/**
 * Load Jetpack compatibility file.
 */
require get_template_directory() . '/inc/jetpack.php';

/**
 * CPT
 */
require get_template_directory() . '/inc/cpt/custom-post.php';

/**
 * Meta Box.
 */
require get_template_directory() . '/inc/cpt/metabox.php';

/**
 * Widgets
 */
require get_template_directory() . '/inc/widgets/widgets.php';

/**
 * Shortcodes
*/
require get_template_directory() . '/inc/shortcodes.php';

/**
* If Kirki is not already installed, use the included version
*/
if ( ! class_exists( 'Kirki' ) ) {    
    require get_template_directory() . '/inc/kirki/kirki.php';
}

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer/customizer.php';

/**
 * Give Plugin Related Functions
*/
if( is_give_activated() )
require get_template_directory() . '/inc/give-functions.php';

/**
 * WooCommerce Related funcitons
*/
if( is_woocommerce_activated() )
require get_template_directory() . '/inc/woocommerce-functions.php';

/**
 * Typography Functions
*/
require get_template_directory() . '/inc/typography-functions.php';

/**
 * Dynamic Styles
*/
require get_template_directory() . '/css/style.php';

/**
 * Demo Import
*/
require get_template_directory() . '/inc/demo/import-hooks.php';

/**
 * Plugin Recommendation
*/
require get_template_directory() . '/inc/tgmpa/recommended-plugins.php';