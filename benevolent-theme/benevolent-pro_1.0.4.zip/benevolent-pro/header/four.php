<?php
/**
 * Header Four
 * 
 * @package Benevolent_Pro
*/

$ed_social_link = get_theme_mod( 'benevolent_pro_ed_social_header' ); // From customizer
$ed_search_form = get_theme_mod( 'benevolent_pro_ed_search_form', '1' ); // From customizer

?>

<header id="masthead" class="site-header header-four" role="banner">
	
    <div class="header-top">
		<div class="container">
			
            <div class="site-branding">
            
        		<?php if( function_exists( 'has_custom_logo' ) && has_custom_logo() ) the_custom_logo(); ?>
        		
                <h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
        		
                <?php
        		$description = get_bloginfo( 'description', 'display' );
        		if ( $description || is_customize_preview() ) : ?>
        			<p class="site-description"><?php echo $description; /* WPCS: xss ok. */ ?></p>
        		<?php endif; ?>
                
        	</div><!-- .site-branding -->
			
            <?php if( has_nav_menu( 'secondary' ) ){ ?>            
                <div id="secondary-mobile-header">
    			    <a id="responsive-secondary-menu-button" href="#sidr-main2"><?php esc_html_e( 'Menu', 'benevolent-pro' ); ?></a>
    			</div> 
            <?php } ?>
			
            <?php if( has_nav_menu( 'secondary' ) || $ed_social_link ){ ?>
                <div class="right-panel">
                
    				<?php if( has_nav_menu( 'secondary' ) ){ ?> 
                        <nav id="top-navigation" class="secondary-navigation" role="navigation">
                			<?php wp_nav_menu( array( 'theme_location' => 'secondary', 'menu_id' => 'secondary-menu', 'fallback_cb' => false ) ); ?>
                		</nav><!-- #top-navigation -->
                    <?php } ?>
                    
    		        <?php if( $ed_social_link ) benevolent_pro_get_social_links(); ?>
                    
    			</div><!-- .right-panel -->
            <?php } ?>
            
		</div>
	</div><!-- .header-top -->
    
	<div class="header-bottom">
		<div class="container">
			
            <nav id="site-navigation" class="main-navigation" role="navigation">
    			<?php wp_nav_menu( array( 'theme_location' => 'primary', 'menu_id' => 'primary-menu' ) ); ?>
    		</nav><!-- #site-navigation -->
            
			<div id="mobile-header">
			    <a id="responsive-menu-button" href="#sidr-main"><?php esc_html_e( 'Menu', 'benevolent-pro' ); ?></a>
			</div>
            
            <?php if( $ed_search_form ){ ?>
                <div class="search">
    				<span class="fa fa-search"></span>
    				<div class="form-holder">
    					<?php get_search_form(); ?>
    				</div>
    			</div>
            <?php } ?>
            			
		</div>
	</div><!-- .header-bottom -->
</header>