<?php
/**
 * Header One
 * 
 * @package Benevolent_Pro
*/

$ed_social_link = get_theme_mod( 'benevolent_pro_ed_social_header' ); // From customizer

?>

<header id="masthead" class="site-header header-one" role="banner">

<?php 
    
    if( $ed_social_link || has_nav_menu( 'secondary' ) ){ ?>
    
        <div class="header-top">
            <div class="container">
                <?php if( has_nav_menu( 'secondary' ) ) {?>            
                    <div id="secondary-mobile-header">
        			    <a id="responsive-secondary-menu-button" href="#top-navigation"><?php esc_html_e( 'Menu', 'benevolent-pro' ); ?></a>
        			</div>                
                    <nav id="top-navigation" class="secondary-navigation" role="navigation">
            			<?php wp_nav_menu( array( 'theme_location' => 'secondary', 'menu_id' => 'secondary-menu', 'fallback_cb' => false ) ); ?>
            		</nav><!-- #top-navigation -->
                <?php } 
                
                    if( $ed_social_link ) benevolent_pro_get_social_links(); 
                ?>
            </div>
        </div><!-- .header-top -->
        
        <?php
    }
    
    ?>
    
    <div class="header-bottom">
            
        <div class="container">
    	
            <div class="site-branding">
            
    			<?php if( function_exists( 'has_custom_logo' ) && has_custom_logo() ) the_custom_logo(); ?>
   				
                <h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
    			
                <?php
    			$description = get_bloginfo( 'description', 'display' );
    			if ( $description || is_customize_preview() ) : ?>
    				<p class="site-description"><?php echo $description; /* WPCS: xss ok. */ ?></p>
    			<?php endif; ?>
                
    		</div><!-- .site-branding -->
            
            <nav id="site-navigation" class="main-navigation" role="navigation">
    			<?php wp_nav_menu( array( 'theme_location' => 'primary', 'menu_id' => 'primary-menu' ) ); ?>
    		</nav><!-- #site-navigation -->
            
            <div id="mobile-header">
			    <a id="responsive-menu-button" href="#site-navigation"><?php esc_html_e( 'Menu', 'benevolent-pro' ); ?></a>
			</div>
            
        </div>
        
    </div><!-- .header-bottom -->
    
</header><!-- #masthead -->